#include "grace_model.h"
#include "../base/cppfunctor.h"
#include <cmath>

using namespace cppfunct;

class Polynomial {
 public:
 Polynomial(std::vector<scalar> coeff) : coeff(coeff){}
    scalar value(scalar t) const {
      scalar val;
      for (int i=0;i<int(coeff.size());i++)
       val+=coeff.at(i)*pow(t,i);
      return val;
    }
 private :
 std::vector<scalar> coeff;
};

int main() {


scalar const dt=1./100.0;

GraceModel graph(dt, //time step
                 0.1, //time update plot
                 0.0, //time init
                 50.0, //time end
                 "grace test", //title
                 700, //grace height
                 1000); // grace witdh




std::vector<Function<scalar (scalar)> > vector_functs;
vector_functs.push_back(function<scalar (scalar) >(cos));
vector_functs.push_back(3+5*arg<1, scalar>());
vector_functs.push_back(bind_arg<2>(function<scalar (scalar,scalar) >(pow),constant(2)));
//vector_functs.push_back(pow(arg<1, scalar>(), 3.));

std::vector<scalar> poly_coeff;
poly_coeff.push_back(0.0);
poly_coeff.push_back(0.0);
poly_coeff.push_back(1.0);

Polynomial polynomial(poly_coeff);
vector_functs.push_back(method(&polynomial,&Polynomial::value));
graph.add_graph("sin - cos", vector_functs);
graph.add_graph("label", vector_functs);

graph.initialise();                
                
while (true)
{
 graph.run();
} 
 
}

