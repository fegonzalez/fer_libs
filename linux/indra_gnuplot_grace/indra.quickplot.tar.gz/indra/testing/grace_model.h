#ifndef _GRACE_MODEL_HEADER_H
#define _GRACE_MODEL_HEADER_H

#include <string>
#include <vector>
#include "../base/cppfunctor.h"
#include "../base/model.h"
#include "../base/pointer_policy.h"
#include "grplot.h"

class GraceModel : public Model {

 public :

  struct GraceModelProperties{
    std::string x_label;
    std::string y_label;
    scalar x_label_size;
    scalar y_label_size;
    std::vector<std::string>  plot_color;
    std::vector<scalar> plot_line_width;

    GraceModelProperties();

  };

  GraceModel(scalar dt,
             scalar time_update=0.1,
             scalar time_init=0.0,
             scalar time_end=100.0,
             std::string char_title="",
             int chart_height=700,
             int chart_width=1000);

  ~GraceModel();

 void add_graph(std::string label,
                std::vector< cppfunct::Function<scalar (scalar time)> >,
                GraceModelProperties=GraceModelProperties());

 void initialise_model();
 void model();

 scalar get_t() const { return time;}
  
 int get_size() const;
 pointer_type(GraceModelProperties const) get_graphproperties(int zero_index_graph) const;
 void save_ps_file(std::string ps_filename) ;
 
 private :
  pointer_type(grPlotting::grChart) chart;

  scalar dt;

  std::vector<GraceModelProperties> graphproperties;
  std::vector< std::vector< cppfunct::Function<scalar (scalar)> > > plots;
  
  int chart_height;
  int chart_width;
  std::string chart_title;

  scalar time_init;
  scalar time_end;
  scalar time_update;
  scalar time;
  scalar time_plot;

};


#endif
