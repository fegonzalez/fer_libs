
#include "../testing/grplot.h"
#include "../base/table.h"

#include <iostream>
#include <list>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using std::list;
using std::string;
using std::cout;
using std::endl;


class HeaderReader : 
  public Functor_1<std::vector<std::string>, std::ifstream *> {
public:
  std::vector<std::string> operator()(std::ifstream * const & file) const {
    std::string line;
    std::vector<std::string> var_name_vector;
    for(int line_number=0;line_number<0;line_number++) {
      getline(*file, line);
    }
    getline(*file, line);
    std::istringstream line_iss(line);
    std::string var_name;
    while(line_iss) {
      line_iss >> var_name;
      if (not line_iss)
	continue;
      var_name_vector.push_back(var_name);
    }
    getline(*file, line);
    return var_name_vector;
  }

};

int main(int argc, char *argv[]) {

 std::string time_column="time";
 if(argc>3) time_column=argv[3];
 scalar dt_plot=0.1;
 string color_plot="red";
 int page_width=960;
 int page_height=800;
 float plot_line_width=1.5;
 float plot_char_size=.5;
 bool save_plot=false;
 bool exit_at_end=false;
 string prefix_when_saving="";

 std::list<string> plot_variables;

 if(argc<=1) {

  cout << "\nPlotting \n\nusage : \n quickplot <data_file> <file_with_list_test>  \n" << endl;
  return 1;

 } 
 if (argc>1) {

  if(argc>2) {

  std::list<std::string> input_list;

  //open test list
  std::ifstream file(argv[2]);

  if (!file.is_open())
    std::cerr << "ERROR: THE FILE CANNOT BE OPENED: " << argv[2] << std::endl;

  std::string test_string;
  //loop in test list
  while (file) {
  
  getline(file, test_string);

    if(test_string.find_first_not_of(" \t\r")==std::string::npos
       || test_string.size()==0
       || test_string[test_string.find_first_not_of(" \t\r")]=='#')
      continue;

   plot_variables.push_back(test_string);

  }
 } // end list file

 //setting up enviroment
  //grplot setting up
 int size_plot=int(plot_variables.size()); 
 if(size_plot<=0) return 1;
 
 grPlotting::grChart graph("", size_plot);
  if(size_plot <=4)  graph.arrange_graphs(size_plot,1); 
  else  {
    if(2*int(float(size_plot)/2.0)==size_plot)
     graph.arrange_graphs(int(float(size_plot)/2.0),2);
    else graph.arrange_graphs(int(float(size_plot)/2.0)+1,2);
   }

  char command_string_1[256];
  sprintf(command_string_1,"DEVICE \"X11\" PAGE SIZE %4d,%4d",page_width,page_height);
  graph.send_command(command_string_1);

  std::string command_string="TITLE \"";
  command_string+=argv[1];
  command_string+="\"";
  graph.send_command(command_string.c_str());
  graph.send_command("TITLE SIZE 1.");

  //Load datamaps
  HeaderReader read_header;
  DataTimeHistoryFile parent_file(argv[1],&read_header);
  std::vector<Table_1D_linear *> tablas;

 Table_1D_linear *time_table;
  if(!parent_file.is_variable_file(time_column.c_str())) {
     std::cout << "Variable " << time_column.c_str() << " not found in data file\n";
     return 1;
   }
 scalar const * nodes = parent_file.get(time_column.c_str());
 scalar const * values  = parent_file.get(time_column.c_str());
 int data_size = parent_file.get_lenght(time_column.c_str()); 
 time_table = new Table_1D_linear( new Data_1D(nodes, values, data_size),Table_1D::limit);

 for (std::list<std::string>::const_iterator scan=plot_variables.begin(),
           end=plot_variables.end();scan!=end;++scan) {
   if(!parent_file.is_variable_file(*scan)) {
     std::cout << "Variable "<< *scan << " not found in data file\n";
     continue;
   }

   Table_1D_linear *table_temp;
   scalar const * nodes = parent_file.get(time_column.c_str());
   scalar const * values  = parent_file.get((*scan).c_str());
   int data_size = parent_file.get_lenght(time_column.c_str()); 
   table_temp = new Table_1D_linear( new Data_1D(nodes, values, data_size),Table_1D::limit);
   tablas.push_back(table_temp);
 }
  
   scalar time_init=time_table->first_node();
   scalar time_end=time_table->last_node();       
   scalar value_double=0;

      scalar time=time_init;
      while (time <  time_end ) {

       value_double=0.0;

        int index_graph=0;
       //loop inside plots
       for (std::list<std::string>::const_iterator scan=plot_variables.begin(),
           end=plot_variables.end();scan!=end;++scan) {

           value_double=tablas.at(index_graph)->function(time);;

          graph[index_graph].set_y_axis_label(*scan);
          graph[index_graph].set_x_axis_label("");
          graph[index_graph].set_y_axis_label_size(plot_char_size);
          graph[index_graph].set_x_axis_label_size(plot_char_size);
          graph[index_graph].set_plot_line_color(0,color_plot);
          graph[index_graph].set_plot_line_width(0,plot_line_width);

         if(std::isnan(value_double) || std::isinf(value_double)) value_double=0.0;
          graph[index_graph] << time
                        << value_double
                        << grPlotting::endl; 
          
          index_graph++;
       }

     //update
     for(int i=0;i<size_plot;i++) graph[i].draw(true);
                  
     time+=dt_plot;

     }

   graph.redraw(); 

   if(save_plot) { 
    graph << "hardcopy device \"PostScript\"";
 
    std::string print;
    std::string title_string;

    title_string+=prefix_when_saving;
    title_string+="_";
    title_string+=argv[1];
    title_string+=".ps";

    print = "print to device";
    graph <<  print.c_str();
    print = "print to \"" + title_string + "\"";

    graph << print.c_str();

    graph << "print";

   }

   if(exit_at_end) graph << "exit";

    }

} //end main

