#include "grace_model.h"
#include <cstdio>
#include <time.h>

namespace {
 std::string get_date() {
  char cptime[50];
  time_t now = time(NULL);
  strftime(cptime, 50, "%b. %d, %Y", localtime(&now));
  std::string strTime = cptime;
  return strTime;
}

}

GraceModel::GraceModelProperties::GraceModelProperties() :
                                    x_label(""),
                                    y_label("LABEL_Y"),
                                    x_label_size(.5f),
                                    y_label_size(.5f){
                                     
}

GraceModel::GraceModel(scalar dt,
		       scalar time_update,
                       scalar time_init,
                       scalar time_end,
                       std::string chart_title,
		       int chart_height,
                       int chart_width)
			:
                        chart(0),
                        dt(dt),
                        chart_height(chart_height),
                        chart_width(chart_width),
                        chart_title(chart_title),
                        time_init(time_init),
                        time_end(time_end),
                        time_update(time_update),
                        time(time_init),
                        time_plot(0.0){
                        
}

GraceModel::~GraceModel() {
  release_pointer(chart);
}

void GraceModel::add_graph(std::string label,
                            std::vector< cppfunct::Function<scalar (scalar)> > plot_arg,
                            GraceModelProperties graph_p) {

  graph_p.y_label=label;
  graphproperties.push_back(graph_p);

  plots.push_back(plot_arg);

return;
}

pointer_type(GraceModel::GraceModelProperties const) GraceModel::get_graphproperties(int zero_index_graph) const {
  return &graphproperties.at(zero_index_graph);
}

void GraceModel::initialise_model() {

   time=time_init;
   time_plot=0.0;

   if(is_nonnull(chart)) {release_and_reset_pointer(chart);reset_pointer(chart);}

   int n_plots=get_size();
   chart=new_pointer(grPlotting::grChart("", n_plots));
   if(n_plots <=4)  chart->arrange_graphs(n_plots,1);
   else  {
    if(2*int(float(n_plots)/2.0)==n_plots)
     chart->arrange_graphs(int(float(n_plots)/2.0),2);
     else chart->arrange_graphs(int(float(n_plots)/2.0)+1,2);
    }

   //Page setup
  char command_string_1[256];
  sprintf(command_string_1,"DEVICE \"X11\" PAGE SIZE %4d,%4d",chart_width,chart_height);
  chart->send_command(command_string_1);

  //title
  std::string command_string="TITLE \"";
  command_string+=chart_title;
  command_string+="\\n";
  command_string+="\\- ";
  command_string+="\\- ";
  command_string+=get_date();
  command_string+="\"";
  chart->send_command(command_string.c_str());

  chart->send_command("TITLE SIZE 1.");

  for(int i=0;i<n_plots;i++) (*chart)[i].set_x_axis_label(graphproperties.at(i).x_label);
  for(int i=0;i<n_plots;i++) (*chart)[i].set_y_axis_label(graphproperties.at(i).y_label);
  for(int i=0;i<n_plots;i++) (*chart)[i].set_x_axis_label_size(float(graphproperties.at(i).x_label_size));
  for(int i=0;i<n_plots;i++) (*chart)[i].set_y_axis_label_size(float(graphproperties.at(i).y_label_size));
  
  for(int i=0;i<n_plots;i++) {
   for(int j=0;j<int(graphproperties.at(i).plot_color.size());j++) 
       (*chart)[i].set_plot_line_color(j,graphproperties.at(i).plot_color.at(j));
   for(int j=0;j<int(graphproperties.at(i).plot_line_width.size());j++) 
     (*chart)[i].set_plot_line_width(j,float(graphproperties.at(i).plot_line_width.at(j)));  
  }

  return;
}

void GraceModel::model()  {

   if(time > time_end) return;

   time+=dt;
   time_plot+=dt;
   if(time_plot > time_update) {
    time_plot=0.0;

    for(int i=0;i< get_size();i++) {
      (*chart)[i] << time;
      for(int j=0;j<int(plots.at(i).size());j++)
       (*chart)[i] << plots.at(i).at(j)(time);
      (*chart)[i] << grPlotting::endl;
    }
    for(int i=0;i<get_size();i++) (*chart)[i].draw(true);
    chart->redraw();

   }
return;
}

int GraceModel::get_size() const {
 return int(plots.size());
}

void GraceModel::save_ps_file(std::string ps_filename)  {

   (*chart) << "hardcopy device \"PostScript\"";

   std::string print;
   std::string title_string;

   title_string+=ps_filename;

   print = "print to device";
   (*chart) <<  print.c_str();
   print = "print to \"" + title_string + "\"";

   (*chart) << print.c_str();

   (*chart) << "print";

return;
}
