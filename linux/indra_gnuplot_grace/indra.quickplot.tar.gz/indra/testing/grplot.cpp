#include "grplot.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
#define BUFSIZE 512

using std::cin;
using std::cout;
using std::cerr;
using std::ios;
using std::ifstream;

namespace grPlotting {


	  grGraph::grGraph(unsigned int number):graph_number(number),linemax(0),newline(true){
	       GracePrintf("g%d hidden false",graph_number);
	  }

	  grGraph& grGraph::operator << (const char* command){
	       GracePrintf("with g%d",graph_number);
	       GracePrintf("%s",command);
	       return(*this);
	  }

	  grGraph& grGraph::operator << (const double& variable){
	       if(newline){
		    data.push_back(std::vector<double>());
		    data[data.size()-1].push_back(variable);
		    newline=false;
	       }
	       else{
		    data[data.size()-1].push_back(variable);
	       }

	       return(*this);
	  }

	  void grGraph::operator << (void (*func)(grGraph&)){
	       func(*this);
	  }

	  void grGraph::plot_manual (int set,
                                     const double &x,
                                     const double &y,
                                     bool autoscale_){

              GracePrintf("g%d.s%d point %f,%f",graph_number,set,x,y);
              if(autoscale_) autoscale();
	       return;
	  }


	  void grGraph::clear(void){

	       for(unsigned int i=0;i<linemax;i++){
    	          GracePrintf("kill g%d.s%d ",graph_number,i);
	       }
	       linemax=0;

	  }

	  void grGraph::draw(bool bautoscale){

	    if ( data.empty() == false ){
	       unsigned int lasttime=data.size();
	       unsigned int lastline=data[0].size();
	       if(lastline>linemax){
		    linemax=lastline;
	       }
	       for(unsigned int i=0;i<lasttime;i++){
		    for(unsigned int j=1;j<lastline;j++){
			 GracePrintf("g%d.s%d point %f,%f",graph_number,j-1,data[i][0],data[i][j]);
		    }
	       }
	       for(unsigned int i=0;i<lasttime;i++){
		    data[i].clear();
	       }
	       data.clear();
	    }
           if( bautoscale)  autoscale();
	  }


	  void grGraph::draw(bool bautoscale_x,bool bautoscale_y){

	    if ( data.empty() == false ){
	       unsigned int lasttime=data.size();
	       unsigned int lastline=data[0].size();
	       if(lastline>linemax){
		    linemax=lastline;
	       }
	       for(unsigned int i=0;i<lasttime;i++){
		    for(unsigned int j=1;j<lastline;j++){
			 GracePrintf("g%d.s%d point %f,%f",graph_number,j-1,data[i][0],data[i][j]);
		    }
	       }
	       for(unsigned int i=0;i<lasttime;i++){
		    data[i].clear();
	       }
	       data.clear();
	    }
           if( bautoscale_x)  autoscale_x();
           if( bautoscale_y)  autoscale_y();
	  }


        void grGraph::send_command(const char* command){
	       (*this) << command;
	  }

	void grGraph::set_graph_label(char *title) {

           sprintf(buffer,"title \"%s\"",title);
           (*this) << buffer;
        }

	void grGraph::set_graph_sublabel(char *subtitle) {

           sprintf(buffer,"subtitle \"%s\"",subtitle);
           (*this) << buffer;
        }

        void grGraph::autoscale(void) {
            (*this) << "autoscale";
        }

        void grGraph::autoscale_x(void) {
            (*this) << "autoscale xaxes";
        }

        void grGraph::autoscale_y(void) {
            (*this) << "autoscale yaxes";
        }

        void grGraph::autoticks(void) {
            (*this) << "autoticks";
        }


        void grGraph::show_minor_lines_x(bool value){

          sprintf(buffer,"xaxis tick minor linestyle 3 ");
           (*this) << buffer;

           if(value) {
           sprintf(buffer,"xaxis tick minor grid on ");
           (*this) << buffer;
           }
          else {

           sprintf(buffer,"xaxis tick minor grid off ");
           (*this) << buffer;

          }

        }

        void grGraph::show_major_lines_x(bool value){

           sprintf(buffer,"xaxis tick major linestyle 3 ");
           (*this) << buffer;
           
           if(value) {
           sprintf(buffer,"xaxis tick major grid on ");
           (*this) << buffer;
           }
          else {

           sprintf(buffer,"xaxis tick major grid off ");
           (*this) << buffer;

          }

        }

        void grGraph::show_minor_lines_y(bool value){

           sprintf(buffer,"yaxis tick minor linestyle 3 ");
           (*this) << buffer;

           if(value) {
           sprintf(buffer,"yaxis tick minor grid on ");
           (*this) << buffer;
           }
          else {

           sprintf(buffer,"yaxis tick minor grid off ");
           (*this) << buffer;

          }

        }

        void grGraph::set_x_axis_minor_grid_color(const std::string & label) {
          sprintf(buffer,"xaxis tick minor color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_y_axis_minor_grid_color(const std::string & label) {
          sprintf(buffer,"yaxis tick minor color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_x_axis_major_grid_color(const std::string & label) {
          sprintf(buffer,"xaxis tick major color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_y_axis_major_grid_color(const std::string & label) {
          sprintf(buffer,"yaxis tick major color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::show_major_lines_y(bool value){

           sprintf(buffer,"yaxis tick major linestyle 3 ");
           (*this) << buffer;

           if(value) {
           sprintf(buffer,"yaxis tick major grid on ");
           (*this) << buffer;
           }
          else {

           sprintf(buffer,"yaxis tick major grid off ");
           (*this) << buffer;

          }

        }

       void grGraph::set_x_axis_label(const std::string & label) {

           sprintf(buffer,"xaxis label \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_fill_color(const std::string &label) {
           sprintf(buffer,"frame background color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_fill_pattern(const int pattern) {
           sprintf(buffer,"frame background pattern %d",pattern);
           (*this) << buffer;
        }

        void grGraph::set_x_axis_label_color(const std::string &label) {
           sprintf(buffer,"xaxis label color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_x_axis_label_font(int font) {
           sprintf(buffer,"xaxis label font %d",font);
           (*this) << buffer;
        }

        void grGraph::set_y_axis_label_color(const std::string &label) {
           sprintf(buffer,"yaxis label color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_y_axis_label_font(int font) {
           sprintf(buffer,"yaxis label font %d",font);
           (*this) << buffer;
        }

        void grGraph::set_x_axis_minor_tick_color(const std::string &label) {
           sprintf(buffer,"xaxis tick minor color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_x_axis_major_tick_color(const std::string &label) {
           sprintf(buffer,"xaxis tick major color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_y_axis_minor_tick_color(const std::string &label) {
           sprintf(buffer,"yaxis tick minor color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_y_axis_major_tick_color(const std::string &label) {
           sprintf(buffer,"yaxis tick major color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_x_axis_tick_label_color(const std::string &label) {
           sprintf(buffer,"xaxis ticklabel color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_y_axis_tick_label_color(const std::string &label) {
           sprintf(buffer,"yaxis ticklabel color \"%s\"",label.c_str());
           (*this) << buffer;
        }

        void grGraph::set_frame_color(const std::string &label) {
           sprintf(buffer,"frame color \"%s\"",label.c_str());
           (*this) << buffer;
        }

       void grGraph::set_x_axis_label_size(float size) {

           sprintf(buffer,"xaxis label char size %f",size);
           (*this) << buffer;
           sprintf(buffer,"xaxis ticklabel char size %f",size);
           (*this) << buffer;
        }

       void grGraph::set_y_axis_label(const std::string & label) {

           sprintf(buffer,"yaxis label \"%s\"",label.c_str());
           (*this) << buffer;

          }

        void set_x_axis_tick_label_enable(bool value);
        void set_y_axis_tick_label_enable(bool value);

       void grGraph::set_x_axis_tick_label_enable(bool enable) {

           if(!enable)
           sprintf(buffer,"xaxis ticklabel off");
           else
           sprintf(buffer,"xaxis ticklabel on");

           (*this) << buffer;
        }

       void grGraph::set_y_axis_tick_label_enable(bool enable) {

           if(!enable)
           sprintf(buffer,"yaxis ticklabel off");
           else
           sprintf(buffer,"yaxis ticklabel on");

           (*this) << buffer;
        }


       void grGraph::set_y_axis_label_size(float size) {

           sprintf(buffer,"yaxis label char size %f",size);
           (*this) << buffer;
           sprintf(buffer,"yaxis ticklabel char size %f",size);
           (*this) << buffer;
        }


        void grGraph::set_x_axis_xmin(float value) {

           sprintf(buffer,"world xmin %f",value);
           (*this) << buffer;
        }

        void grGraph::set_x_axis_xmax(float value) {

           sprintf(buffer,"world xmax %f",value);
           (*this) << buffer;
        }

        void grGraph::set_y_axis_ymin(float value) {

           sprintf(buffer,"world ymin %f",value);
           (*this) << buffer;
        }

        void grGraph::set_y_axis_ymax(float value) {

           sprintf(buffer,"world ymax %f",value);
           (*this) << buffer;
        }

       void grGraph::set_y_axis_minor_tick(float value) {

           sprintf(buffer,"yaxis tick minor %f",value);
           (*this) << buffer;
        }

       void grGraph::set_y_axis_major_tick(float value) {

           sprintf(buffer,"yaxis tick major %f",value);
           (*this) << buffer;
        }

       void grGraph::set_x_axis_minor_tick(float value) {

           sprintf(buffer,"xaxis tick minor %f",value);
           (*this) << buffer;
        }

       void grGraph::set_x_axis_major_tick(float value) {

           sprintf(buffer,"xaxis tick major %f",value);
           (*this) << buffer;
        }

       void grGraph::set_plot_line_show(int nPlot,bool show) {

              if(!show) sprintf(buffer,"s%d line type 0",nPlot);
              else sprintf(buffer,"s%d line type 1",nPlot);
             (*this) << buffer;
        }

        void grGraph::set_plot_line_width(int nPlot,float witdh) {

           sprintf(buffer,"s%d line linewidth %f",nPlot,witdh);
           (*this) << buffer;
        }

        void grGraph::set_plot_line_style(int nPlot,int style) {

           sprintf(buffer,"s%d line linestyle %d",nPlot,style);
           (*this) << buffer;
          }

        void grGraph::set_plot_line_color(int nPlot,const std::string & color) {

           sprintf(buffer,"s%d line color \"%s\"",nPlot,color.c_str());
           (*this) << buffer;
          }

        void grGraph::set_plot_symbol_show(int nPlot,bool show) {
              if(!show) sprintf(buffer,"s%d symbol off",nPlot);
              else sprintf(buffer,"s%d symbol on",nPlot);
           (*this) << buffer;
          }


        void grGraph::set_plot_symbol_width(int nPlot,float witdh) {

           sprintf(buffer,"s%d symbol size %f",nPlot,witdh);
           (*this) << buffer;
          }

        void grGraph::set_plot_symbol_style(int nPlot,int style) {

           sprintf(buffer,"s%d symbol %d",nPlot,style);
           (*this) << buffer;
          }

        void grGraph::set_plot_symbol_color(int nPlot,const std::string & color) {
           sprintf(buffer,"s%d symbol color \"%s\"",nPlot,color.c_str());
           (*this) << buffer;
          }


        void grGraph::translate_x(int nPlot,float value) {
           sprintf(buffer,"s%d.x = s%d.x + %f",nPlot,nPlot,value);
           (*this) << buffer;
          }

        void grGraph::translate_y(int nPlot,float value) {
           sprintf(buffer,"s%d.y = s%d.y + %f",nPlot,nPlot,value);
           (*this) << buffer;
          }

        void grGraph::scale_x(int nPlot,float value) {
           sprintf(buffer,"s%d.x = s%d.x * %f",nPlot,nPlot,value);
           (*this) << buffer;
          }

        void grGraph::scale_y(int nPlot,float value) {
           sprintf(buffer,"s%d.y = s%d.y * %f",nPlot,nPlot,value);
           (*this) << buffer;
          }

        void grGraph::kill_data(int nPlot) {
    	   //GracePrintf("kill g%d.s%d ",graph_number,i);
//           sprintf(buffer,"s%d kill data",nPlot);
           sprintf(buffer,"kill s%d ",nPlot);
           (*this) << buffer;
          }

	  grChart::grChart(unsigned int size=0):max_graph_size(-1){
	       init("");
	       add(size);
               size_graphs=size;
	  }
	  grChart::grChart( const std::string &parameter_file = DEFAULTFILE,unsigned int size=0
                           ):max_graph_size(-1){
	       init(parameter_file);
	       add(size);
               size_graphs=size;
	  }

   	  void grChart::init(const std::string & parameter_file = "" ){
	       if ( parameter_file == ""){ // no parameter file
		    if(GraceOpen(GRACEBUFFER)==-1){
			 std::cerr << "Can't run Grace." << std::endl;
			 exit(-1);
		    }
	       } else {

                   char buf1[]="xmgrace -nosafe";
                   char buf2[]="-nosafe";
                   char buf3[]="-noask";
                   char buf4[]="-param";

                    if( GraceOpenVA(buf1,GRACEBUFFER , buf2, buf3,buf4, parameter_file.c_str(), NULL) == -1 ){
			 std::cerr << "Can't run Grace.(" << parameter_file << ")" << std::endl;
			 exit(-1);
		    }
	       }

	       GracePrintf("focus off");
	  }

        void grChart::plot_manual(int graph_,
                                  int set,
                                  const double& x,
                                  const double& y,
                                  bool autoscale_) {

              graph[graph_].plot_manual(set,x,y,autoscale_);

         return;
        }



	  void grChart::add(unsigned int size){
	       for(unsigned int i=0;i<size;i++){
		    max_graph_size++;
		    graph.push_back(grGraph(max_graph_size));
	       }
	  }

	  grChart& grChart::operator << (const char* command){
	       GracePrintf("%s",command);
	       return(*this);
	  }

	  grGraph& grChart::operator [] (unsigned int number){
	       return graph[number];
	  }

	  bool grChart::open(void){
	       return GraceIsOpen();
	  }

	  void grChart::redraw(void){
	       GracePrintf("redraw");
	  }

	  void grChart::autoscale(void){
               GracePrintf("autoscale");
	  }

          void grChart::send_command(const char* command){
	       GracePrintf(command);
	  }

          void grChart::arrange_graphs(int nRows,int nCols) {
		GracePrintf("arrange(%d, %d, 0.14, 0.15, 0.2, OFF, OFF, OFF, ON)",nRows,nCols);

              if(size_graphs<nCols*nRows)
		GracePrintf("kill g%d",nCols*nRows-1);
          }

          void endl(grGraph& graph){
	    graph.newline=true;
           }

     void read_command_file(const std::string &filename){
	  ifstream ifs (filename.c_str(), ios::in);
	  if (ifs.fail()){
	       std::cerr << "Error(load commands): unable to open file(" << filename << ")" << std::endl;
	       exit(1);
	  }
	  char buffer[BUFSIZE];
	  while (!ifs.eof()){
	       ifs.getline(buffer, BUFSIZE);
	       GraceCommand(buffer);
	  }
	  ifs.close();
     }

     void grGraph::load_commands(const std::string & filename){
	  GracePrintf("with g%d",graph_number);
	  read_command_file(filename);
     }


     void grChart::load_commands(const std::string & filename){
	  read_command_file(filename);
     }

    void grChart::clear() {

     for(int i=0;i<int(graph.size());i++) {
           graph[i].clear();
       }

 }

    void grChart::set_x_axis_tick_label_enable(bool value) {

     for(int i=0;i<int(graph.size());i++) {

           graph[i].set_x_axis_tick_label_enable(value);
       }

}

    void grChart::set_y_axis_tick_label_enable(bool value) {

     for(int i=0;i<int(graph.size());i++) {
           graph[i].set_y_axis_tick_label_enable(value);
       }

}

}
