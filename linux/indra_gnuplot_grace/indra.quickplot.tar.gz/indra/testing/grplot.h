/*
grPlotting namespace enables the functionality to use the XY plotter grace using C++. 

It requires grace instalation  (download grace or grace6, XY plotting tool ) 

It includes two main classes, 

  grChart : is the main page that can includes as many graphs as the user wants. 
  grGraph : each graph included in grChart 
  

//Sample using grPlot

  //Object creation
  grPlotting::grChart graph("", 3);  // parameters file ("" if unknown ) and number of graphs)
  
  //Arrange the graph in the page, 3 graphs in rows
  graph.arrange_graphs(3,1);

  //Labels of the axis 
  graph[0].set_x_axis_label("X");
  graph[1].set_x_axis_label("X");

  graph[0].set_y_axis_label("Y=2*X");
  graph[1].set_y_axis_label("Y=(2*X)²");

  //Plot properties
  graph[0].set_plot_line_color(0,"red");
  graph[1].set_plot_line_color(0,"blue");

  graph[0].set_plot_line_width(0,2.);
  graph[1].set_plot_line_width(0,2.);

  //Putting data in the graphs
  float x=0,y=0;
  while(x<2.) {
 
    x+=.01;
    y=2*x;
 
    graph[0] << x << y << grPlotting::endl;
    graph[1] << x << y*y << grPlotting::endl;
  
   for(int i=0 ;i< n_plots ; i++) graph[i].draw(true);
    graph.redraw();
  }

  In grChart and in grGraph all the functionality of grace plotter can be used through the operator <<, 
  that sends a grace command to each object.  Anyway, some common functionality has been implemented with functions. 

  More implementation will be required.

  grChart includes methods to configure the page, and to set and update the graphs
  grGraph included methods to set graphical properties to the graph



*/
#ifndef __GRPLOTTING_H
#define __GRPLOTTING_H

#include <string>
#include <vector>
#include "grace_np.h"

namespace grPlotting {
   const std::string DEFAULTFILE("default.par");
   const int GRACEBUFFER=2048;
   
   class grGraph{
   private:

       unsigned int graph_number;
       unsigned int linemax;
       bool newline;
       std::vector<std::vector<double> > data;
       char buffer[512];		

     public:
	grGraph(unsigned int number);

	grGraph& operator << (const char* command);
	grGraph& operator << (const double& variable);
	void operator << (void (*func)(grGraph&));

	friend void endl(grGraph&);	  

        void clear(void);
	void draw(bool bautoscale);
	void draw(bool bautoscale_x,bool bautoscale_y);

	void draw_manual(bool bautoscale);
	void draw_manual(bool bautoscale_x,bool bautoscale_y);


       	void load_commands(const std::string & filename);
        void send_command(const char* command);
	
        void set_graph_label(char *title);
	void set_graph_sublabel(char *subtitle);

        void autoscale(void);
        void autoscale_x(void);
        void autoscale_y(void);

        void autoticks(void);

        void show_minor_lines_x(bool value);
        void show_major_lines_x(bool value);
        void show_minor_lines_y(bool value);
        void show_major_lines_y(bool value);

        void set_frame_color(const std::string &label);
        void set_fill_color(const std::string &label);
        void set_fill_pattern(const int pattern);

        void set_x_axis_label(const std::string & label);
        void set_x_axis_label_color(const std::string & label);
        void set_x_axis_label_font(int font);
        void set_y_axis_label_color(const std::string & label);
        void set_y_axis_label_font(int font);
        void set_x_axis_label_size(float size);
        void set_y_axis_label(const std::string & label);
        void set_y_axis_label_size(float size);
        void set_x_axis_xmin(float value);
        void set_x_axis_xmax(float value);
        void set_y_axis_ymin(float value);
        void set_y_axis_ymax(float value);
        void set_y_axis_minor_tick(float value);
        void set_y_axis_major_tick(float value);
        void set_x_axis_minor_tick(float value);
        void set_x_axis_major_tick(float value);
        void set_x_axis_minor_tick_color(const std::string & label);
        void set_x_axis_major_tick_color(const std::string & label);
        void set_y_axis_minor_tick_color(const std::string & label);
        void set_y_axis_major_tick_color(const std::string & label);

        void set_x_axis_tick_label_color(const std::string & label);
        void set_y_axis_tick_label_color(const std::string & label);

        void set_x_axis_minor_grid_color(const std::string & label);
        void set_x_axis_major_grid_color(const std::string & label);

        void set_y_axis_minor_grid_color(const std::string & label);
        void set_y_axis_major_grid_color(const std::string & label);

        void set_x_axis_tick_label_enable(bool value);
        void set_y_axis_tick_label_enable(bool value);

        void set_plot_line_show(int nPlot,bool show);
        void set_plot_line_width(int nPlot,float witdh);
        void set_plot_line_style(int nPlot,int style);
        void set_plot_line_color(int nPlot,const std::string & color);

        void set_plot_symbol_show(int nPlot,bool show);
        void set_plot_symbol_width(int nPlot,float witdh);
        void set_plot_symbol_style(int nPlot,int style);
        void set_plot_symbol_color(int nPlot,const std::string & color);
  
        void translate_x(int nPlot,float value);
        void translate_y(int nPlot,float value);

        void scale_x(int nPlot,float value);
        void scale_y(int nPlot,float value);
        
        void plot_manual(int nPlot,const double& x,const double& y,bool autoscale); 

        void kill_data(int nPlot);    

     };
     
     class grChart{
     private:
       std::vector<grGraph> graph;
       int max_graph_size;
       void init(const std::string & parameter_file);
       int size_graphs;

     public:
	  grChart(unsigned int size);
	  grChart( const std::string &parameter_file,unsigned int size);
	  
	  virtual ~grChart (){GraceClosePipe();}
	  
	  void add(unsigned int size);
	  
	  grChart& operator << (const char* command);
	  grGraph& operator [] (unsigned int number);
	  
	  bool open(void);
          void clear();
  
	  void load_commands(const std::string & filename);
  
	  void redraw(void);
	  void autoscale(void);
          void send_command(const char* command);
          void arrange_graphs(int nRows,int nCols);

          void set_x_axis_tick_label_enable(bool value);
          void set_y_axis_tick_label_enable(bool value);
  
          void close(void) {GraceClosePipe();}

         void plot_manual(int graph,int set,const double& x,const double& y,bool autoscale);  


     };
     
     void endl(grGraph&);
     
}

#endif



