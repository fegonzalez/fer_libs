#include "compval.h"
#include <iostream>
#include <cmath>

double pi_factor=1.5;

double adulterated_pi() { return pi_factor*M_PI; }

ComputedValue<double> pi(adulterated_pi);

double triple(double const &x) { return 3.*x; }

int main() {
  std::cout << pi << std::endl;
  if (pi<M_PI*.9)
    std::cout << "too low" << std::endl;
  else if (pi>M_PI*1.1)
    std::cout << "too high" << std::endl;
  std::cout << triple(pi) << std::endl;

  pi_factor=.75;
  std::cout << pi << std::endl;
  if (pi<M_PI*.9)
    std::cout << "too low" << std::endl;
  else if (pi>M_PI*1.1)
    std::cout << "too high" << std::endl;
  std::cout << triple(pi) << std::endl;
}
