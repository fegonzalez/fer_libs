
#include "mathfilter.h"

#include <assert.h>

/* Filter ********************************************************************/

MathFilter::~MathFilter() 
{
}

scalar MathFilter::limit_filter(scalar x, scalar lower_limit, scalar upper_limit) {
    scalar value = this->filter(x);
    if (value <= lower_limit) {
        value = lower_limit;
        this->initialise(x, lower_limit);
    }
    else if (value>=upper_limit) {
        value = upper_limit;
        this->initialise(x, upper_limit);
    }
    return value;
}

scalar MathFilter::limit_abs_filter(scalar x, scalar limit) {
    scalar limit_abs = fabs(limit);
    return limit_filter(x, -limit_abs, limit_abs);
}

Tustin22::Tustin22(scalar dt, scalar a2, scalar a1, scalar a0,
		   scalar b2, scalar b1, scalar b0):
  MathFilter(dt),
  A0(0.0),A1(0.0),A2(0.0),B0(0.0),B1(0.0),B2(0.0),
  y_k(0.0), y_k1(0.0), x_k(0.0), x_k1(0.0)
{
  set_coefficients(a2,a1,a0,
		   b2,b1,b0);
};

void Tustin22::set_coefficients(scalar a2, scalar a1, scalar a0,
				scalar b2, scalar b1, scalar b0)
{
  // Calculate A0,A1,A2,B0,B1,B2:
  A2 = (a0*Dt*Dt) + (2*a1*Dt) + (4*a2) ;
  A1 = (2*a0*Dt*Dt) + (-2*a1*Dt) + (-8*a2) ;
  A0 = (a0*Dt*Dt) + (4*a2) ; 

  B2 = (b0*Dt*Dt) + (2*b1*Dt) + (4*b2) ;
  B1 = (2*b0*Dt*Dt) + (-2*b1*Dt) + (-8*b2) ;
  B0 = (b0*Dt*Dt) + (4*b2) ; 

};
  
void Tustin22::initialise(scalar x, scalar y)
{
  x_k = x_k1 = x;
  output = y_k = y_k1 = y;
  
};
  
scalar Tustin22::filter(scalar x)
{
  // Update state
  scalar const x_k2=x_k1;
  x_k1=x_k;
  x_k=x;

  scalar const y_k2=y_k1;
  y_k1 = y_k;

  // Calculate output
  assert( fabs(B2) > 1E-6 );

  output = y_k = (1/B2) * ( (-B1* y_k1) + (-B0* y_k2) + 
			    (A2* x_k) +(A1* x_k1) + (A0* x_k2) );

  return output;
};



Tustin44::Tustin44(scalar dt, scalar a4, scalar a3,scalar a2, scalar a1, scalar a0,
		   scalar b4, scalar b3,scalar b2, scalar b1, scalar b0):
  MathFilter(dt),
  A0(0.0),A1(0.0),A2(0.0),A3(0.0),A4(0.0),B0(0.0),B1(0.0),B2(0.0),B3(0.0),B4(0.0),
  y_k(0.0), y_k1(0.0), x_k(0.0), x_k1(0.0)
{
  set_coefficients(a4,a3,a2,a1,a0,
		   b4,b3,b2,b1,b0);
};
   
void Tustin44::set_coefficients(scalar a4, scalar a3,scalar a2, scalar a1, scalar a0,
				scalar b4, scalar b3,scalar b2, scalar b1, scalar b0)
{
  // Calculate A0,A1,A2,A3,A4,B0,B1,B2,B3,B4:
  A4 = (a0*pow(Dt,4.0)) + (2*a1*pow(Dt,3.0)) + (4*a2*pow(Dt,2.0)) + (8*a3*Dt) + (16*a4) ;
  A3 = (4*a0*pow(Dt,4.0)) + (4*a1*pow(Dt,3.0)) + (-16*a3*Dt) + (-64*a4) ;
  A2 = (6*a0*pow(Dt,4.0)) + (-8*a2*pow(Dt,2.0)) + (96*a4) ;
  A1 = (4*a0*pow(Dt,4.0)) + (-4*a1*pow(Dt,3.0)) + (16*a3*Dt) + (-64*a4) ;
  A0 = (a0*pow(Dt,4.0)) + (-2*a1*pow(Dt,3.0)) + (4*a2*pow(Dt,2.0)) + (-8*a3*Dt) + (16*a4) ;

  B4 = (b0*pow(Dt,4.0)) + (2*b1*pow(Dt,3.0)) + (4*b2*pow(Dt,2.0)) + (8*b3*Dt) + (16*b4) ;
  B3 = (4*b0*pow(Dt,4.0)) + (4*b1*pow(Dt,3.0)) + (-16*b3*Dt) + (-64*b4) ;
  B2 = (6*b0*pow(Dt,4.0)) + (-8*b2*pow(Dt,2.0)) + (96*b4) ;
  B1 = (4*b0*pow(Dt,4.0)) + (-4*b1*pow(Dt,3.0)) + (16*b3*Dt) + (-64*b4) ;
  B0 = (b0*pow(Dt,4.0)) + (-2*b1*pow(Dt,3.0)) + (4*b2*pow(Dt,2.0)) + (-8*b3*Dt) + (16*b4) ;

};

void Tustin44::initialise(scalar x, scalar y)
{
  x_k = x_k1 = x_k2 = x_k3 = x;
  output = y_k = y_k1 = y_k2 = y_k3 = y;

};
  
scalar Tustin44::filter(scalar x)
{
  // Update state
  scalar const x_k4=x_k3;
  x_k3=x_k2;
  x_k2=x_k1;
  x_k1=x_k;
  x_k=x;

  scalar const y_k4=y_k3;
  y_k3=y_k2;
  y_k2=y_k1;
  y_k1=y_k;

  // Calculate output
  assert( fabs(B4) > 1E-6 );

  output = y_k = (1/B4) * ( (-B3*y_k1) + (-B2*y_k2) + (-B1*y_k3) + (-B0*y_k4) + 
			    (A4*x_k) + (A3*x_k1) + (A2*x_k2) + (A1*x_k3) +(A0*x_k4) );


  return output;
};

