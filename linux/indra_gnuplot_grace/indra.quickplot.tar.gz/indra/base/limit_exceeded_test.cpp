#include <iostream>
#include "limit_exceeded.h"

using namespace std;

// Class for testing
GraphLimit* p_graphLimit = 0;
GraphLimitTimer* p_graphLimitTimer = 0;
ConstantLimitTimer* p_constantLimitTimer = 0;
LowerConstantLimitTimer* p_lowerConstantLimitTimer = 0;
UpperConstantLimit* p_upperConstantLimit = 0;
LowerConstantLimit* p_lowerConstantLimit = 0;

// Global imposed limit to be referenced by a pointer
scalar globalLimit = 5.;

// Execution time
scalar const stepTime = 0.1; // 100 (ms)


// Creates the necesesary points array
// to build the GraphLimitClass

void CreateGraph(Point* points)
{

  //Initializing points of Graph
  //      |
  //      |        C**********D           A(1,0)
  //      |       *            *          B(1,1)
  //      |     *               *         C(2,2)
  //      |    *                 *        D(3,2)
  //      |   B                   E       E(4,1)
  //      |   *                   *       F(4,0)
  //      |   *                   *
  //     -|---A-------------------F-----
  //      |
  points[0].SetX(1.0);  points[0].SetY(0.0); //Point A
  points[1].SetX(1.0);  points[1].SetY(1.0); //Point B
  points[2].SetX(2.0);  points[2].SetY(2.0); //Point C
  points[3].SetX(3.0);  points[3].SetY(2.0); //Point D
  points[4].SetX(4.0);  points[4].SetY(1.0); //Point E
  points[5].SetX(4.0);  points[5].SetY(0.0); //Point F

}

//Creating objects for test
void CreateObjects()
{
  // Creating an area to build the GraphLimit objects
  int numberOfPoints = 6;
  Point* pointsList = new Point[numberOfPoints];
  CreateGraph(pointsList);

  // Creating a GraphLimit object
  p_graphLimit = new GraphLimit(numberOfPoints, pointsList);

  // Creating a GraphLimitTimer object
  scalar const maxTime = 2.0; // Max time that the graph limits can be exceeded
  p_graphLimitTimer = new GraphLimitTimer(numberOfPoints, pointsList, maxTime, stepTime);

  //Creating a ConstantLimitTimer object
  scalar limit = 2;
  p_constantLimitTimer = new ConstantLimitTimer(limit, maxTime, stepTime);

  //Creating a LowerConstantLimitTimer object
  p_lowerConstantLimitTimer = new LowerConstantLimitTimer(limit, maxTime, stepTime);

  //Creating an upperConstantLimit object
  p_upperConstantLimit = new UpperConstantLimit(&globalLimit) ;

  //Creating a lowerConstantLimit object
  p_lowerConstantLimit = new LowerConstantLimit(&globalLimit);

}

// Deleting objects
void DeleteObjects()
{
  delete p_graphLimit;
  delete p_graphLimitTimer;
  delete p_constantLimitTimer;
  delete p_lowerConstantLimitTimer;
  delete p_lowerConstantLimit;
  delete p_upperConstantLimit;
}


//****************** BEGIN TG_GraphLimit********************************************


void TC_PointsIn()
{
  //Points included in the area to test
  int const pointsToTest = 6;
  Point inputPoints[pointsToTest];
  inputPoints[0].SetX(1.2); inputPoints[0].SetY(0.8);// test point 1 (1.2,0.8)
  inputPoints[1].SetX(1.9); inputPoints[1].SetY(1.7);// test point 2 (1.9,1.7)
  inputPoints[2].SetX(2.5); inputPoints[2].SetY(1.9);// test point 3 (2.5,1.9)
  inputPoints[3].SetX(2.8); inputPoints[3].SetY(0.5);// test point 3 (2.8,0.5)
  inputPoints[4].SetX(3.5); inputPoints[4].SetY(0.5);// test point 3 (3.5,0.5)
  inputPoints[5].SetX(3.7); inputPoints[5].SetY(0.8);// test point 3 (3.7,0.8)

  cout << endl << "<------------- Test GraphLimit - Points IN -------------->" << endl << endl;

  try
    {
      for (int i=0; i < pointsToTest; i++)
	{
	  // Setting  inputs & Printing Outputs
	  cout<<"Point: ("<<inputPoints[i].GetX()<<","<<inputPoints[i].GetY()<<") - ";
	  if(p_graphLimit->CheckPoint(inputPoints[i])) cout<<"IN"<<endl;
	  else cout<<"FAIL"<<endl;
	}
    }
  catch( ...)
    {
      cout << "++++ ERROR in TC_PointsIn() ++++" << endl;
    }
}

void TC_PointsOut()
{
  //Points included in the area to test
  int const pointsToTest = 6;
  Point outputPoints[pointsToTest];
  outputPoints[0].SetX(0.0); outputPoints[0].SetY(0.0);// test point 1 (0.0,0.0)
  outputPoints[1].SetX(0.5); outputPoints[1].SetY(0.1);// test point 2 (0.5,0.1)
  outputPoints[2].SetX(-2.0); outputPoints[2].SetY(0.5);// test point 3 (-2.0,0.5)
  outputPoints[3].SetX(2.0); outputPoints[3].SetY(3.0);// test point 3 (2.0,3.0)
  outputPoints[4].SetX(3.5); outputPoints[4].SetY(3.5);// test point 3 (3.0,3.5)
  outputPoints[5].SetX(4.5); outputPoints[5].SetY(0.5);// test point 3 (4.5,0.5)

  cout << endl << "<------------- Test GraphLimit - Points OUT -------------->" << endl << endl;

  try
    {
      for (int i=0; i < pointsToTest; i++)
	{
	  // Setting  inputs & Printing Outputs
	  cout<<"Point: ("<<outputPoints[i].GetX()<<","<<outputPoints[i].GetY()<<") - ";
	  if(p_graphLimit->CheckPoint(outputPoints[i])==false) cout<<"OUT"<<endl;
	  else cout<<"FAIL"<<endl;
	}
    }
  catch( ...)
    {
      cout << "++++ ERROR in TC_PointsOut() ++++" << endl;
    }
}

void TG_GraphLimitTest( void )
{
  cout<<"********************* TESTING GraphLimit **********************"<<endl;
  //Testing a list of points placed inside of the defined graph
  TC_PointsIn();
  //Testing a list of points placed outside of the defined graph
  TC_PointsOut();
  //TC_PointsOut();
}
//** END TG_GraphLimitTest ****************************************************

//** BEGIN TG_GraphLimitTimerTest***************************************************

void TC_PointsOutTime()
{
  Point pointOutside(1.1,2.0);
  Point pointInside(2.0,1.0);

  cout << endl << "<------------- Test GraphLimitTimer - Points OUT -------------->" << endl << endl;
  cout <<"Poviding a point out of the limit. The test result shall be 1 until the time interva limit is expired."<<endl;
  cout<<"-------------------------------------------------------------------------------------------------------"<<endl;

  for(scalar time=0.0;time<3;time+=stepTime)
    {
      cout<<"Timer: "<<time<<" - Test: "<<p_graphLimitTimer->CheckPointInTime(pointOutside)<<endl;
    }

  cout <<"Poviding a point inside the limit. The test result shall be 1."<<endl;
  cout<<"---------------------------------------------------------------"<<endl;
  cout<<"Point inside the GraphLimit.- Test: "<<p_graphLimitTimer->CheckPointInTime(pointInside)<<endl<<endl;

  cout <<"Poviding a value out of the limit. The test result shall be 1 until the time interva limit is expired."<<endl;
  cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
  for(scalar time=0.0;time<3;time+=stepTime)
    {
      cout<<"Timer: "<<time<<" - Test: "<<p_graphLimitTimer->CheckPointInTime(pointOutside)<<endl;
    }
}


void TG_GraphLimitTimerTest(void)
{
  cout<<"********************* TESTING GraphLimitTimer **********************"<<endl;
  TC_PointsOutTime();
}
//** END TG_GraphLimitTimerTest ***********************************************

//** BEGIN TG_ConstantLimitTimerTest***************************************************

void TC_ValueOutTime()
{
  scalar valueOutOfRange = 5;
  scalar valueInRange = 1;


 cout << endl << "<------------- Test ConstantLimitTimer - Points OUT -------------->" << endl << endl;
 cout <<"Poviding a value out of the limit. The test result shall be 1 until the time interva limit is expired."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
 for(scalar time=0.0;time<3;time+=stepTime)
    {
      cout<<"Timer: "<<time<<" - Test: "<<p_constantLimitTimer->CheckValueInTime(valueOutOfRange)<<endl;
    }

 cout <<"Poviding a value inside the limit. The test result shall be 1."<<endl;
 cout<<"---------------------------------------------------------------"<<endl;

 cout<<"Test: "<<p_constantLimitTimer->CheckValueInTime(valueInRange)<<endl<<endl;
 cout <<"Poviding a value out of the limit. The test result shall be 1 until the time interva limit is expired."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
  for(scalar time=0.0;time<3;time+=stepTime)
    {
      cout<<"Timer: "<<time<<" - Test: "<<p_constantLimitTimer->CheckValueInTime(valueOutOfRange)<<endl;
    }
}

void TG_ConstantLimitTimerTest(void)
{
  cout<<"********************* TESTING ConstantLimitTimer **********************"<<endl;
  TC_ValueOutTime();
}

//** END TG_ConstantLimitTimerTest ***********************************************




//** BEGIN TG_LowerConstantLimitTimerTest***************************************************

void TC_ValueOutTimeLowerConstantLimitTimer()
{
  scalar valueOutOfRange = -5;
  scalar valueInRange = 10;


 cout << endl << "<----------- Test LowerConstantLimitTimer - Points OUT ------------->" << endl << endl;
 cout <<"Poviding a value out of the limit. The test result shall be 1 until the time interva limit is expired."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
 for(scalar time=0.0;time<3;time+=stepTime)
    {
      cout<<"Timer: "<<time<<" - Test: "<<p_lowerConstantLimitTimer->CheckValueInTime(valueOutOfRange)<<endl;
    }

 cout <<"Poviding a value inside the limit. The test result shall be 1."<<endl;
 cout<<"---------------------------------------------------------------"<<endl;

 cout<<"Test: "<<p_lowerConstantLimitTimer->CheckValueInTime(valueInRange)<<endl<<endl;
 cout <<"Poviding a value out of the limit. The test result shall be 1 until the time interva limit is expired."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
  for(scalar time=0.0;time<3;time+=stepTime)
    {
      cout<<"Timer: "<<time<<" - Test: "<<p_lowerConstantLimitTimer->CheckValueInTime(valueOutOfRange)<<endl;
    }
}

void TG_LowerConstantLimitTimerTest(void)
{
  cout<<"******************* TESTING LowerConstantLimitTimer ********************"<<endl;
  TC_ValueOutTimeLowerConstantLimitTimer();
}

//** END TG_ConstantLimitTimerTest ***********************************************

//** BEGIN TG_ConstantLimit. Limit by reference ***************************************************


void TC_UpperConstantLimitByReference()
{

 cout << endl << "<----------- Test UpperConstantLimit -------------->" << endl << endl;
 // The global limit is set to 5
 globalLimit = 5.;
 cout <<"Setting the global limit... globalLimit = "<<globalLimit<<endl;
 cout <<"Poviding values to check from 0 to 10."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
 for(scalar valueToCheck=0.0;valueToCheck<10;valueToCheck++)
    {
      cout<<"Checkin value: "<<valueToCheck<<" - Test: "<<p_upperConstantLimit->CheckValue(valueToCheck)<<endl;
    }

 // The global limit is set to 2
 globalLimit = 2.;
 cout<<endl;
 cout <<"Setting the global limit... globalLimit = "<<globalLimit<<endl;
 cout <<"Poviding values to check from 0 to 10."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
 for(scalar valueToCheck=0.0;valueToCheck<10;valueToCheck++)
    {
      cout<<"Checkin value: "<<valueToCheck<<" - Test: "<<p_upperConstantLimit->CheckValue(valueToCheck)<<endl;
    }
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;

}

void TC_LowerConstantLimitByReference()
{

 cout << endl << "<----------- Test LowerConstantLimit -------------->" << endl << endl;
 // The global limit is set to 5
 globalLimit = 5.;
 cout <<"Setting the global limit... globalLimit = "<<globalLimit<<endl;
 cout <<"Poviding values to check from 0 to 10."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
 for(scalar valueToCheck=0.0;valueToCheck<10;valueToCheck++)
    {
      cout<<"Checkin value: "<<valueToCheck<<" - Test: "<<p_lowerConstantLimit->CheckValue(valueToCheck)<<endl;
    }

 // The global limit is set to 2
 globalLimit = 2.;
 cout<<endl;
 cout <<"Setting the global limit... globalLimit = "<<globalLimit<<endl;
 cout <<"Poviding values to check from 0 to 10."<<endl;
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;
 for(scalar valueToCheck=0.0;valueToCheck<10;valueToCheck++)
    {
      cout<<"Checkin value: "<<valueToCheck<<" - Test: "<<p_lowerConstantLimit->CheckValue(valueToCheck)<<endl;
    }
 cout<<"-------------------------------------------------------------------------------------------------------"<<endl;

}


void TG_ConstantLimitTest(void)
{
  cout<<"******************* TESTING upperConstantLimit ********************"<<endl;
  TC_UpperConstantLimitByReference();
  TC_LowerConstantLimitByReference();
}


//** END TG_ConstantLimitTest. Limit by reference ***********************************************


//*****************************************************************************


int main(void)
{
  CreateObjects();

  TG_GraphLimitTest();

  TG_GraphLimitTimerTest();

  TG_ConstantLimitTimerTest();

  TG_LowerConstantLimitTimerTest();

  TG_ConstantLimitTest();

  DeleteObjects();
}
