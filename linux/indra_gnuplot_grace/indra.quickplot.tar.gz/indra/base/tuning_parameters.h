#ifndef TUNING_PARAMETERS_HEADER_
#define TUNING_PARAMETERS_HEADER_

#include "../base/scalar.h"
#include <map>
#include <string>

class TuningParameters {
 public:
  TuningParameters(std::string set_of_parameters_name);

  void add_item(std::string parameter_name,
		scalar parameter_value);
  bool find(std::string parameter_name);
  scalar &get_parameter(std::string parameter_name, scalar default_value);
  scalar &get_parameter(std::string parameter_name);
  std::string get_set_of_parameters_name() const;
  void set_parameter(std::string parameter_name, scalar new_value);

  std::map<std::string,scalar>::const_iterator begin();
  std::map<std::string,scalar>::const_iterator end();

 private:
  std::string const name;
  std::map<std::string, scalar>  set_of_parameters;
};

std::ostream &operator<<(std::ostream &os, TuningParameters set_of_parameters);
std::istream &operator>>(std::istream &is, TuningParameters &set_of_parameters);

#endif
