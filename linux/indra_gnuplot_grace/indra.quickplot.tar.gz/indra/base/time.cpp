#include "time.h"

TimeManagement *time_management=0;
