#include <stdio.h>
#include "curve2d.h"
#include <iostream>
#include <iomanip>

using std::cout;
using std::endl;

int main()
{

  cout << std::setprecision(3) << std::fixed;
//curves
	ControlPoints control_points;
	Polycurve2d polycurve;
	Spline2d spline;
	Bezied2d bezier;

//List of control points
	control_points.add_controlpoint ( 0.f,0.f );
	control_points.add_controlpoint ( 5.f,.7f );
	control_points.add_controlpoint ( 7.5f,1.f );
	control_points.add_controlpoint ( 10.f,0.f );

//Loop to fill remain curves
	for ( int i=0;i<control_points.get_size();i++ )
	{
		float x,y;
		control_points.get_at ( &x,&y,i );
		polycurve.add_controlpoint ( x,y );
		spline.add_controlpoint ( x,y );
		bezier.add_controlpoint ( x,y );
	}

//printing control points

//printing with adimensional arc parameter
	cout << "# arc   polycurve   spline   bezier" << endl;
	float arc=0;
	float x,y;
	while ( arc<=1.0 )
	{
		//cout << arc*spline.get_lenght() << " ";
		polycurve.get_xY ( &x,&y,arc,false );
		cout << x << " ";
		cout << y << " ";
		spline.get_xY ( &x,&y,arc );
		cout << y << " ";
                bezier.get_xY(&x,&y,arc);
		cout << y << endl;

		arc+=0.005f;
	}
	cout <<  endl << endl;

return 0;
}
