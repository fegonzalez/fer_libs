#include "paramfile.h"
#include <fstream>

using namespace std;

namespace {
  string const whitespace=" \t\r";

  bool syntactically_empty_line(string const &line_string) {
    return (line_string.find_first_not_of(whitespace)==string::npos
            || line_string.size()==0
            || line_string[line_string.find_first_not_of(whitespace)]=='#');
            // because of the previous condition, size()>=1
  }

}

/* ParameterFile *************************************************************/

ParameterFile::ParameterFile(string file_name)
  : file_name(file_name) {
  ifstream in(file_name.c_str());
  if(not in.is_open())
	  throw "file "+file_name+" not found";
  while (in) {
    string line;
    getline(in, line);
    if (not syntactically_empty_line(line)) {
      typedef string::size_type index;

      index name_begin=line.find_first_not_of(whitespace);
      index name_end=line.find_first_of(whitespace, name_begin);

      string name(line, name_begin, name_end-name_begin);
      if (exists(name))
        throw "parameter "+name+" declared twice in "+file_name;

      index value_begin=line.find_first_not_of(whitespace, name_end);
      string value(line, value_begin);

      map_name_value[name]=value;
    }
  }
}

bool ParameterFile::exists(string parameter_name) const {
  return map_name_value.find(parameter_name)!=map_name_value.end();
}

std::ostream &operator<<(std::ostream &os, ParameterFile const &pf) {
  for (map<string, string>::const_iterator scan=pf.map_name_value.begin();
       scan!=pf.map_name_value.end();
       ++scan)
    os << scan->first << " " << scan->second << endl;
  return os;
}
