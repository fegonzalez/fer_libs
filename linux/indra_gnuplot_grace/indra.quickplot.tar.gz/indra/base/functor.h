#ifndef BASE_FUNCTOR_HEADER_
#define BASE_FUNCTOR_HEADER_

#include "pointer_policy.h"

/* These are abstract base classes representing functions.  A functor is an
 * object that behaves as a function, by offering an operator()().  These
 * functors can be passed as arguments of another object's method or a
 * function.  For instance, a function that performs some aerodynamic
 * computations related to given airfoils can need to know the airfoil's lift
 * curve (lift as a function of angle-of-attack); it this case, it will accept
 * a Functor_1 argument that provides this curve; the Functor_1 may be
 * implemented as a linear curve, a table-driven function, or in whatever form
 * the data are available in.  Thanks to functors, the usage of a function is
 * separated from its implementation. */

template <class Ret>
class Functor_0 { // functor with no arguments
public:
  virtual ~Functor_0() { };
  virtual Ret operator()() const=0;
  // operator: function with no arguments
  Ret function() const
  { return operator()(); } // alias
};

template <class Ret>
class Functor_0_Object {
public:
  Functor_0_Object(Functor_0<Ret> const *f)
    : f(f) { }
  ~Functor_0_Object() { delete f; }
  Ret operator()() const { return (*f)(); }
private:
  Functor_0<Ret> const *const f;
};

template <class Ret>
class Constant_0  // constant functor with no arguments
  : public Functor_0<Ret> {
public:
  Constant_0(Ret const value) : value(value) { }
  Ret operator()() const { return value; }
private:
  Ret const value;
};

template <class Ret>
pointer_type(Functor_0<Ret>) new_constant (Ret c) {
 return new_pointer(Constant_0<Ret>(c));
}

template <class Ret>
class Assignable_0
  : public Functor_0<Ret> {
public:
  void set(Ret value_) { value=value_;}
  Assignable_0(Ret value) : value(value) {}
  Assignable_0(void) : value(0.0) {}
  Ret operator()() const { return value; }
private:
  Ret value;
};

template <class Ret, class RetRealType=Ret>
class VariableRepeater // variable repeater 0-argument functor
  : public Functor_0<Ret> {
public:
  VariableRepeater(RetRealType const *variable) : variable(variable) { }
  Ret operator()() const { return *variable; }
private:
  RetRealType const* const variable;
};

template <class Ret>
pointer_type(Functor_0<Ret> const) new_variable_repeater(Ret const *var) {
  return new_pointer(VariableRepeater<Ret>(var));
}

template <class Ret, class Source>
class ConsultorRepeater // consultor repeater 0-argument functor
  : public Functor_0<Ret> {
public:
  typedef Ret (Source::*Consultor)() const;
  ConsultorRepeater(Source const *source, Consultor consultor)
    : source(source), consultor(consultor) { }
  Ret operator()() const { return (source->*consultor)(); }
private:
  Source const *const source;
  Consultor const consultor;
};

template <class Ret, class Arg1=Ret>
class Functor_1 { // functor with one argument
public:
  virtual ~Functor_1() { };
  virtual Ret operator()(Arg1 const &) const=0;
  // operator: function with one argument
  Ret function(Arg1 const &a1) const
  { return operator()(a1); } // alias
};

template <class Ret, class Arg1=Ret>
class Functor_1_Object {
public:
  Functor_1_Object(Functor_1<Ret, Arg1> const *f)
    : f(f) { }
  ~Functor_1_Object() { delete f; }
  Ret operator()(Arg1 const &a1) const { return (*f)(a1); }
private:
  Functor_1<Ret, Arg1> const *const f;
};

template <class Ret, class Arg1=Ret>
class Constant_1  // constant functor with no arguments
  : public Functor_1<Ret, Arg1> {
public:
  Constant_1(Ret const value) : value(value) { }
  Ret operator()(Arg1 const &) const { return value; }
private:
  Ret const value;
};

template <class Ret, class Arg1=Ret, class RetRealType=Ret>
class VariableRepeater_1
  : public Functor_1<Ret, Arg1> {
public:
public:
  VariableRepeater_1(RetRealType const *variable) : variable(variable) { }
  Ret operator()(Arg1 const &) const { return *variable; }
private:
  RetRealType const* const variable;
};

template <class Ret, class Source>
class Method_0_Repeater // method repeater 0-argument functor
  : public Functor_0<Ret> {
 public:
  typedef Ret (Source::*Consultor)(); // FIXME: should be const
  Method_0_Repeater(Source *source, Consultor consultor)
    : source(source), consultor(consultor) { }
  Ret operator()() const { return (source->*consultor)(); }
private:
  Source *const source; // FIXME: should be const
  Consultor const consultor;
};

template <class Ret, class Source>
class Method_0_Repeater_const // method repeater 0-argument functor
  : public Functor_0<Ret> {
 public:
  typedef Ret (Source::*Consultor)() const;
  Method_0_Repeater_const(Source const *source, Consultor consultor)
    : source(source), consultor(consultor) { }
  Ret operator()() const { return (source->*consultor)(); }
private:
  Source const *const source;
  Consultor const consultor;
};

template <class Ret, class Source>
pointer_type(Functor_0<Ret> const) new_method(Source const *source,Ret (Source::*consultor)() const) {
 return new_pointer(Method_0_Repeater_const<Ret,Source>(source,consultor));
}

template <class Ret, class Source>
class Functor_1_Method_0_Repeater_const
  : public Functor_1<Ret,Source> {
 public:
  typedef Ret (Source::*Consultor)() const;
  Functor_1_Method_0_Repeater_const(Consultor consultor)
    :  consultor(consultor) { }
  Ret operator()(Source const &source ) const { return (source.*consultor)(); }
private:
  Consultor const consultor;
};

template <class Ret, class Source>
pointer_type(Functor_1<Ret,Source> const) new_method(Ret (Source::*consultor)() const) {
 return new_pointer(Functor_1_Method_0_Repeater_const<Ret,Source>(consultor));
}

template <class Ret, class Arg1, class Source>
class Method_1_Repeater // method repeater 1-argument functor
  : public Functor_1<Ret, Arg1> {
public:
  typedef Ret (Source::*Consultor)(Arg1); // FIXME: should be const
  Method_1_Repeater(Source *source, Consultor consultor)
    : source(source), consultor(consultor) { }
  Ret operator()(Arg1 const &a1) const { return (source->*consultor)(a1); }
private:
  Source *const source; // FIXME: should be const
  Consultor const consultor;
};

template <class Ret, class Arg1, class Source>
class Method_1_Repeater_const // method repeater 1-argument functor
  : public Functor_1<Ret, Arg1> {
public:
  typedef Ret (Source::*Consultor)(Arg1) const;
  Method_1_Repeater_const(Source const *source, Consultor consultor)
    : source(source), consultor(consultor) { }
  Ret operator()(Arg1 const &a1) const { return (source->*consultor)(a1); }
private:
  Source const *const source;
  Consultor const consultor;
};

template <class Ret, class Arg1, class Source>
pointer_type(Functor_1<Ret,Arg1> const) new_method(Source const *source,Ret (Source::*consultor)(Arg1) const) {
 return new_pointer(Method_1_Repeater_const<Ret,Arg1,Source>(source,consultor));
}

template <class Ret, class Arg1=Ret>
class Ramp_1
  : public Functor_1<Ret, Arg1> {
public:
  Ramp_1(Ret x1, Arg1 y1, Ret x2, Arg1 y2)
    : x1(x1), y1(y1), x2(x2), y2(y2) { }
  Ret operator()(Arg1 const &x) const { return ramp(x, x1, y1, x2, y2); }
private:
  Ret const x1;
  Arg1 const y1;
  Ret const x2;
  Arg1 const y2;
};

template <class Ret, class Arg1=Ret, class Arg2=Arg1>
class Functor_2 { // functor with two arguments
public:
  virtual ~Functor_2() { };
  virtual Ret operator()(Arg1 const&, Arg2 const&) const=0;
  // operator: function with two arguments
  Ret function(Arg1 const &a1,
               Arg2 const &a2) const
  { return operator()(a1, a2); } // alias
};

template <class Ret, class Arg1=Ret, class Arg2=Arg1>
class Functor_2_Object {
public:
  Functor_2_Object(Functor_2<Ret, Arg1, Arg2> const *f)
    : f(f) { }
  ~Functor_2_Object() { delete f; }
  Ret operator()(Arg1 const &a1, Arg2 const &a2) const { return (*f)(a1, a2); }
private:
  Functor_2<Ret, Arg1, Arg2> const *const f;
};

template <class Ret, class Arg1=Ret, class Arg2=Arg1, class Arg3=Arg1>
class Functor_3 { // functor with three arguments
public:
  virtual ~Functor_3() { };
  virtual Ret operator()(Arg1 const&, Arg2 const&, Arg3 const& ) const=0;
  // operator: function with three arguments
  Ret function(Arg1 const &a1,
               Arg2 const &a2,
               Arg3 const &a3) const
  { return operator()(a1, a2, a3); } // alias
};

template <class Ret, class Arg1=Ret, class Arg2=Arg1, class Arg3=Arg1>
class Functor_3_Object {
public:
  Functor_3_Object(Functor_3<Ret, Arg1, Arg2, Arg3> const *f)
    : f(f) { }
  ~Functor_3_Object() { delete f; }
  Ret operator()(Arg1 const &a1, Arg2 const &a2, Arg3 const &a3) const
    { return (*f)(a1, a2, a3); }
private:
  Functor_3<Ret, Arg1, Arg2, Arg3> const *const f;
};

template <class Ret,class Arg1=Ret>
class Bind_Functor_1 : public Functor_0<Ret> {
public:
  Bind_Functor_1(pointer_type(Functor_1<Ret,Arg1> const) f,
                 pointer_type(Functor_0<Arg1> const) g) :
                     f(f),
                     g(g){}

  Ret operator()() const {return (*f)((*g)());}
private :
 pointer_type(Functor_1<Ret,Arg1> const)  const f;
 pointer_type(Functor_0<Arg1> const ) const g;
};

template <class Ret,class Arg1>
pointer_type(Functor_0<Ret> const) new_bind(pointer_type(Functor_1<Ret,Arg1> const) f,
                                            pointer_type(Functor_0<Arg1> const) g) {
return new_pointer(Bind_Functor_1<Ret,Arg1>(f,g));
}

#endif
