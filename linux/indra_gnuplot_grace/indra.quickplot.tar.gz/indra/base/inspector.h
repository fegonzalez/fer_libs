#ifndef INSPECTOR_HEADER_
#define INSPECTOR_HEADER_

#include <string>
#include <list>
#include <map>
#include <iostream>
#include <iomanip>

class BaseValueInspector;

class BaseValueMonitor {
public:
  virtual ~BaseValueMonitor() { }
  struct ValueNameClash { };
  // a ValueNameClash exception must be thrown if there is already a published
  // value with the same name
  virtual void publish(std::string value_name,
                       BaseValueInspector *value_inspector)=0;
};

// A BaseValueInspector is a value inspector in charge of inspecting a value.
// When passed an output stream through the output_value() method, it sends the
// value through the output stream.  The BaseValueInspector class is abstract.
// Its output_value() method must be implemented by working subclasses.  See
// ValueInspector below for a whole family of templated derived classes,
// corresponding to values of concrete types.
class BaseValueInspector {
public:
  virtual ~BaseValueInspector() { }
  virtual void output_value(std::ostream &os) const=0;
  virtual void input_value(std::istream &is) const=0;
};

class ReadOnlyBaseValueInspector
  : public BaseValueInspector {
public:
  void input_value(std::istream &is) const {  is.setstate(std::ios::failbit); }
};

// Default value inspectors for all types that can be directly output to an
// output stream.  See the new_value_inspector() function below.
template <typename Type>
class VariableInspector
  : public BaseValueInspector {
public:
  VariableInspector(Type *variable) : variable(variable) { }
  void output_value(std::ostream &os) const { os << *variable; }
  void input_value(std::istream &is) const { is >> *variable; }
private:
  Type *const variable;
};

template <typename Type>
class VariableInspector<Type const>
  : public ReadOnlyBaseValueInspector {
public:
  VariableInspector(Type const *variable) : variable(variable) { }
  void output_value(std::ostream &os) const { os << *variable; }
private:
  Type const *const variable;
};

// The new_value_inspector() function creates a default value inspector for the
// variable corresponding to the pointer supplied, with the right type, and
// returns a pointer to the value inspector, so that it can be used for
// publishing the variable to a ValueMonitor.
template <typename Type>
VariableInspector<Type> *new_variable_inspector(Type *variable)
{ return new VariableInspector<Type>(variable); }

// Value inspector for argument-less functions.
template <typename Type>
class FunctionInspector
  : public ReadOnlyBaseValueInspector {
public:
  typedef Type (FunctionType)();
  FunctionInspector(FunctionType function) : function(function) { }
  void output_value(std::ostream &os) const { os << function(); }
private:
  FunctionType *const function;
};

// Helper creator function.
template <typename Type>
FunctionInspector<Type>
*new_function_inspector(Type (function)())
{ return new FunctionInspector<Type>(function); }

// Value inspector for argument-less methods;
template <typename Type, typename ObjectType>
class MethodInspector
  : public ReadOnlyBaseValueInspector {
public:
  typedef Type (ObjectType::*MethodType)() const;
  MethodInspector(ObjectType const *object, MethodType method)
    : object(object), method(method) { }
  void output_value(std::ostream &os) const { os << (object->*method)(); }
private:
  ObjectType const *const object;
  MethodType const method;
};

// Helper creator function.
template <typename Type, typename ObjectType>
MethodInspector<Type, ObjectType>
*new_method_inspector(ObjectType const *object,
                      Type (ObjectType::*method)() const)
{ return new MethodInspector<Type, ObjectType>(object, method); }

#endif //INSPECTOR_HEADER_
