#ifndef INDRA_BASE_METAPROG_HEADER_
#define INDRA_BASE_METAPROG_HEADER_

// type "NoQualifier<T>::Result" is type "T" without any qualifier it may have;
// thus,
//
//     "NoQualifier<double>::Result" is "double
//
//     "NoQualifier<double const>::Result" is double

template <typename T>
struct NoQualifier {
  typedef T Result;
};

template <typename T>
struct NoQualifier<T const> {
  typedef T Result;
};

#endif
