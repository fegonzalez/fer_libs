#ifndef _EDGE_DETECTORS_CLASS_H_
#define _EDGE_DETECTORS_CLASS_H_

#include "model.h"

// -----------------------------------------------------
//                EDGE DETECTOR
// -----------------------------------------------------


//            __________           
//           ||        ||        
//    Rising /\        \/  Falling               
//     Edge  /\        \/  Edge
//    _______||        ||__________
//
//


// Edge Detector
class Edge_Detector: public Model
{

 public:
  // Constructor without malfunction asociated.
  Edge_Detector(bool const *input_signal);
  
  // Constructor with malfunction. The malfuction state is checked before evaluate the input signal.
  Edge_Detector(bool const *input_signal, bool const *malfunction);

  // Destructor
  virtual ~Edge_Detector(){}

  // Return true when a falling edge has been detected in the current cycle.
  bool EdgeDetected (void) const {return edge_detected;}
  
  // Converts the push button in a switch
  bool State (void) const {return state;}
  
  bool InputSignal(void) const { return *input_signal;}
  
  // Reset pushButton
  void initialise_model(void);
  
 protected:
  bool const *input_signal;
  bool const *malfunction;
  bool previous_input;
  bool edge_detected;
  bool state;   

};


// -----------------------------------------------------
//               RISING EDGE DETECTOR
// -----------------------------------------------------
// 
//            _______         ______  
//           ||      ||      ||     ||
//           /\      \/      /\     \/      
//           /\      \/      /\     \/  Input Signal
//    _______||      ||______||     ||____
//
//           _                _
//          | |              | |
//          | |              | |
//          | |              | |        EdgeDetected
//   _______| |______________| |_________
//
//           ________________
//          |                | 
//          |                | 
//          |                |         State
//   _______|                |___________  

// Rising edge detector.
class  Rising_Edge_Detector : public Edge_Detector
{
 public:
  
  // Constructor without malfunction asociated.
  Rising_Edge_Detector(bool const *input_signal);
  // Constructor with malfunction. The malfuction state is checked before evaluate the input signal.
  Rising_Edge_Detector(bool const *input_signal, bool const *malfunction);
  
  // Destructor
  ~Rising_Edge_Detector(){}
 
  // The state is set to 'true' when a rising edge is detected. 
  // This function only shall be executed one time each cycle.
  void model();  

};


// -----------------------------------------------------
//               FALLING EDGE DETECTOR
// -----------------------------------------------------
// 
//            _______         ______  
//           ||      ||      ||     ||
//           /\      \/      /\     \/      
//           /\      \/      /\     \/  Input Signal
//    _______||      ||______||     ||____
//
//                   _              _
//                  | |            | |
//                  | |            | |
//                  | |            | |  EdgeDetected
//   _______________| |____________| |_________
//
//                   ________________
//                  |                | 
//                  |                | 
//                  |                |  State
//   _______________|                |___________  


// Falling edge detector.
class  Falling_Edge_Detector : public Edge_Detector
{
 public:
  
  // Constructor without malfunction asociated.
  Falling_Edge_Detector(bool const *input_signal);
  // Constructor with malfunction. The malfuction state is checked before evaluate the input signal.
  Falling_Edge_Detector(bool const *input_signal, bool const *malfunction);
  
  // Destructor
  ~Falling_Edge_Detector(){}
 
  // The state is set to 'true' when a falling edge is detected. 
  // This function only shall be executed one time each cycle.
  void model();

};

#endif
