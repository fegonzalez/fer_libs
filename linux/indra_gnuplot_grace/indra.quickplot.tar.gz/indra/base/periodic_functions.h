#ifndef _PERIODIC_FUNCTIONS_H
#define _PERIODIC_FUNCTIONS_H

#include "../base/base.h"
#include "../base/curve2d.h"
#include <string>

class PeriodicFunctions {

 public :
  PeriodicFunctions(int spline_resolution,
                    int spline_peaks_dete_resolution,
                    scalar spline_peaks_minimum_offset_);
  PeriodicFunctions(void);
//  ~PeriodicFunctions();

 //create
 void add_point(scalar x,scalar y);
 void reset_points(void);
 void crop(scalar t0,scalar tf,int mode); //0_off_1_begin_2_end_3_both
 void mean_line_mode(int mode); // 0 point - 1 linear - 2 poly2 - 3 exp

 //update
 void compute();

 //results
 scalar get_period(void);
 scalar get_w(void);

 scalar get_t12(void);
 scalar get_n(void);
 scalar get_damping_ratio(void);


 //curves
 scalar get_spline(scalar t);
 scalar get_amplitude(scalar t);

 scalar get_mean(scalar t);

 scalar get_mean_line(scalar t);
 scalar get_mean_exponential_line(scalar t);
 scalar get_mean_poly_2(scalar t);

 ControlPoints *get_peaks(void);

 void report(scalar dt);
 void report(std::string filename,scalar dt);


 private :
 ControlPoints points;
 Spline2d spline;
 ControlPoints peaks;
 int spline_res;
 scalar period;
 scalar t12;
 scalar amp_C;
 scalar amp_lambda;
 int crop_mode;
 scalar crop_begin;
 scalar crop_end;
 int spline_peaks_detection_res;
 scalar spline_peaks_minimum_offset;

 scalar t0;
 scalar tf;
 float m_am_line;
 float b_am_line;
 scalar n;
 scalar w;
 scalar damping;
 scalar mean_exp_line_C;
 scalar mean_exp_lambda;
 float polyfit_x0,polyfit_x1,polyfit_x2;
 int mean_line_m; // 0 point - 1 linear - 2 poly2 - 3 exp
};






#endif
