#ifndef BASE_SOLID_HEADER_
#define BASE_SOLID_HEADER_

#include "model.h"
#include "geometry.h"
#include "integration.h"
#include "cppfunctor.h"
#include "base.h"
#include "subscription.h"
#include "pointer_policy.h"

#include <iostream>

#include <list>
#include <string>

/* This package defines rigid solid characteristcs: mass distribution, actions
 * (sliding force vectors), and solid kinematics. */

class Reference_0;

/* Mass **********************************************************************/

/* The class SolidMass represents a mass distribution.  SolidMass objects can
 * be created, added, and referred to any reference point.  The data managed by
 * SolidMass are those needed to compute the motion of a rigid solid: total
 * mass (0th-order moment), and 1st and 2nd order moments.
 *
 * A SolidMass object is expressed in a given reference, with respect to the
 * reference origin.  The method relative_to() returns a new SolidMass
 * representing the same mass distribution but referred to the point specified
 * by the argument to the method; this new reference point is expressend in the
 * same reference as the original SolidMass, and becomes the new origin of the
 * reference in which the new SolidMass is expressed.
 *
 * Analogously, the method placed_at() returns a new SolidMass corresponding to
 * the same mass distribution displaced by a vector specified by the argument
 * to the method; through this displacement, the reference point of the
 * original SolidMass is moved to the specified point. */
class SolidMass {
 public:
   SolidMass() :
      m_(0), Mx_(0), My_(0), Mz_(0),
      Jxx_(0), Jyy_(0), Jzz_(0), Jyz_(0), Jzx_(0), Jxy_(0) { }; // no mass
   SolidMass(scalar m, scalar Mx, scalar My, scalar Mz,
             scalar Jxx, scalar Jyy, scalar Jzz,
             scalar Jyz, scalar Jzx, scalar Jxy) :
     m_(m), Mx_(Mx), My_(My), Mz_(Mz),
     Jxx_(Jxx), Jyy_(Jyy), Jzz_(Jzz), Jyz_(Jyz), Jzx_(Jzx), Jxy_(Jxy) { };
  // 'm' is the total mass; 'Mx', 'My', and 'Mz' are the 1st-order moments in
  // the three axes; 'Jxx', 'Jyy', 'Jzz', 'Jyz', 'Jzx', and 'Jxy' are the
  // 2nd-order moments in the three axes (these are not the elements of the
  // inertia tensor)

   scalar mass() const { return m_; }; // mass
   Vector cg() const { return 1./m_*Vector(Mx_, My_, Mz_); }; // centre of
                                                              // gravity
   SolidMass relative_to(Vector r) const; // refer to the point 'r', usually
                                          // the c.g.
   SolidMass placed_at(Vector r) const; // move by 'r'
   Matrix cginertia() const; // inertia tensor relative to the c.g.
   Matrix invcginertia() const; // cginertia() inverse
   Matrix absinertia() const;
   Matrix invabsinertia() const;
   SolidMass &operator+=(SolidMass const &a);

 private:
   friend std::ostream &operator<<(std::ostream &os, SolidMass a);
   friend SolidMass operator+(SolidMass a, SolidMass b);
   friend SolidMass operator*(scalar k, SolidMass a);

   scalar m_;
   scalar Mx_, My_, Mz_;
   scalar Jxx_, Jyy_, Jzz_, Jyz_, Jzx_, Jxy_;
};

std::ostream &operator<<(std::ostream &os, SolidMass a);
std::istream &operator>>(std::istream &is, SolidMass &a);

SolidMass operator+(SolidMass a, SolidMass b); // addition
SolidMass operator*(scalar k, SolidMass a); // multiplication by a scalar
SolidMass operator*(SolidMass a, scalar k); // multiplication by a scalar
SolidMass operator/(SolidMass a, scalar k); // division by a scalar

SolidMass point_mass(scalar m); // create a SolidMass for a point mass

// create a SolidMass with c.g. at (0, 0, 0), and given total mass and inertia
// tensor elements
SolidMass inertia_mass(scalar m,
                       scalar Ix, scalar Iy, scalar Iz,
                       scalar Iyz, scalar Izx, scalar Ixy);

SolidMass uniform_sphere_mass(scalar m,
                              scalar radius);

SolidMass hollow_sphere_mass(scalar m,
                             scalar radius);

SolidMass instant_solid_mass(scalar mass,
                             Vector cg,
                             SolidMass basic);

/* SolidAction ***************************************************************/

/* The class SolidAction represents a pair of force and moment with respect to
 * a given point.  Actions can be added, referred to other points, an applied
 * onto other points. */

class SolidAction {
 public:
   SolidAction() : F_(), M_() { }; // null action: null force and moment
   SolidAction(Vector F, Vector M) : F_(F), M_(M) { };
   Vector force() const { return F_; }; // get the force
   Vector moment() const { return M_; }; // get the moment
   SolidAction relative_to(Vector r) const; // return the action referred to
                                            // the given point
   SolidAction placed_at(Vector r) const; // return the action applied at the
                                          // given point
   SolidAction &operator+=(SolidAction a) { F_+=a.F_; M_+=a.M_; return *this; }
 private:
   Vector F_;
   Vector M_;
};

std::ostream &operator<<(std::ostream &os, SolidAction a);

SolidAction operator+(SolidAction a, SolidAction b); // sum
SolidAction operator-(SolidAction a, SolidAction b); // subtraction
SolidAction operator*(scalar k, SolidAction a); // multiplication by a scalar
SolidAction operator*(SolidAction a, scalar k); // multiplication by a scalar
SolidAction operator/(SolidAction a, scalar k); // division by a scalar

SolidAction force(Vector F); // create a pure-force action
SolidAction moment(Vector M); // create a pure-moment action

SolidAction from_relative_to__zombie (pointer_type (SolidAction) solid_action,
                                                            pointer_type (Reference_0) from,
                                                            pointer_type (Reference_0) to); // SolidAction expressed in "from" axis changed to expressed in "to" axis
                                                                                                         // (change the reference axis but NOT the aplication point)
                                                                                                         // zombie means that this operator does not seem to be usefull, otherwise remove the "zombie" tag
SolidAction from_reduced_to (pointer_type (SolidAction) solid_action,
                                               pointer_type (Reference_0) from,
                                               pointer_type (Reference_0) to); // SolidAction reduced at the origin of "from" expressed in "from" axis
                                                                                                         // changed to reduced at the origin of "to" expressed in "to" axis

/* SolidAcceleration *********************************************************/

/* The class SolidAcceleration represents a pair of linear and angular
 * accelerations.  Since its usage is very limited, its interface is much
 * simpler than that of SolidAction, but it can be enlarged if necessary. */

class SolidAcceleration {
public:
  SolidAcceleration() : linear_(), angular_() { } // null acceleration
  SolidAcceleration(Vector linear, Vector angular)
    : linear_(linear), angular_(angular) { }
  Vector linear() const { return linear_; }
  Vector angular() const { return angular_; }
  SolidAcceleration &operator+=(SolidAcceleration a)
  { linear_+=a.linear_; angular_+=a.angular_; return *this; }
private:
  Vector linear_;
  Vector angular_;
};

SolidAcceleration operator+(SolidAcceleration a, SolidAcceleration b); // sum

/* SolidVelocity *********************************************************/

/* The class SolidVelocity represents a pair of linear and angular
 * velocities.  Since its usage is very limited, its interface is much
 * simpler than that of SolidAction, but it can be enlarged if necessary. */

class SolidVelocity {
public:
  SolidVelocity() : linear_(), angular_() { } // null acceleration
  SolidVelocity(Vector linear, Vector angular)
    : linear_(linear), angular_(angular) { }
  Vector linear() const { return linear_; }
  Vector angular() const { return angular_; }
  SolidVelocity &operator+=(SolidVelocity a)
  { linear_+=a.linear_; angular_+=a.angular_; return *this; }
private:
  Vector linear_;
  Vector angular_;
};

SolidVelocity operator+(SolidVelocity a, SolidVelocity b); // sum


/* Reference_0 **************************************************************/

/* Reference_0 class implements zero-order rigid solid kinematics, that is,
 * zero-order kinematic relationships between coordinate (reference) systems.
 * Zero-order relationship means that only zero-order position derivatives are
 * involved (i.e. positions only, not velocities and/or accelerations)
 *
 * A Reference_0 class represents a displacement (composed of
 * a reference point shift ('origin') and a rotation ('attitude')) from another
 * parent Reference_0. If this parent Reference_0 is not specified for
 * a Reference_0 class, then it is considered to be expressed from an absolute
 * reference.
 *
 * Whenever a method is used in which there are data expressed in a
 * Reference_0 different than 'this', if not specified they are expressed in
 * the absolute reference. Names for these methods are composed with the suffix
 * '_abs'.
 *
 * Reference_0 honours the tick system implemented in "base.h".  Therefore,
 * after a method has been invoked on a Reference_0, the effect of a new
 * "set_parent()" or "set_abs()" will not be visible until the function
 * "new_step()" declared in "base.h" has not been invoked. */

class Reference_0 { // for position magnitudes only (not velocities)
 public:
   Reference_0(Reference_0 *parent_=0); // 'parent' is the parent Reference_0
                                         // from which 'this' is expressed

   void set_parent(Vector origin_parent, Quaternion attitude_parent);
     // 'origin' shift and 'attitude' rotation with regard to parent
   void set_abs(Vector origin_abs, Quaternion attitude_abs,
		Reference_0 *ref_abs=0);
     // 'origin' shift and 'attitude' rotation with regard to another
     // Reference_0

   Vector origin_parent() const;
     // gets 'origin' shift with regard to parent
   Vector origin_abs(Reference_0 *ref_abs=0) const;
     // gets 'origin' shift with regard to 'ref_abs'
   Quaternion attitude_parent() const;
     // gets 'attitude' rotation with regard to parent
   Quaternion attitude_abs(Reference_0 *ref_abs=0) const;
     // gets 'attitude' rotation with regard to 'ref_abs'

   Vector point_rel_to_parent(Vector point_rel) const;
     // point expressed in 'this' coordinates converted to parent
   Vector point_parent_to_rel(Vector point_parent) const;
     // point expressed in parent coordinates converted to 'this'
   Vector point_rel_to_abs(Vector point_rel, Reference_0 *ref_abs=0) const;
     // point expressed in 'this' coordinates converted to 'ref_abs'
   Vector point_abs_to_rel(Vector point_abs, Reference_0 *ref_abs=0) const;
     // point expressed in 'ref_abs' coordinates converted to 'this'

   Vector vector_rel_to_parent(Vector vector_rel) const;
     // vector expressed in 'this' coordinates converted to parent
   Vector vector_parent_to_rel(Vector vector_parent) const;
     // vector expressed in parent coordinates converted to 'this'
   Vector vector_rel_to_abs(Vector vector_rel, Reference_0 *ref_abs=0) const;
     // vector expressed in 'this' coordinates converted to 'ref_abs'
   Vector vector_abs_to_rel(Vector vector_abs, Reference_0 *ref_abs=0) const;
     // vector expressed in 'ref_abs' coordinates converted to 'this'

   Quaternion quaternion_rel_to_parent(Quaternion quaternion_rel) const;
     // quaternion expressed in 'this' coordinates converted to parent
   Quaternion quaternion_parent_to_rel(Quaternion quaternion_parent) const;
     // quaternion expressed in parent coordinates converted to 'this'
   Quaternion quaternion_rel_to_abs(Quaternion quaternion_rel,
				   Reference_0 *ref_abs=0) const;
     // quaternion expressed in 'this' coordinates converted to 'ref_abs'
   Quaternion quaternion_abs_to_rel(Quaternion quaternion_abs,
				   Reference_0 *ref_abs=0) const;
     // quaternion expressed in 'ref_abs' coordinates converted to 'this'


   void initializeReference_0();

   void display_variables(std::string prefixed);
   void record_play();

 private:
   Reference_0 *parent;
   Vector origin; // with regard to parent
   Quaternion attitude; // with regard to parent

   // Following methods and variables implement a cache system to avoid
   // repeated recursion; position and attitude are kept with regard to
   // absolute reference; they are only valid for the simulation tick
   // in which they were calculated (tick_cache_0); they are updated if
   // called back later.
   // It is not allowed to change a reference by set_parent or set_abs
   // after calculating the cache in the same simulation tick (an assert()
   // will be posted) to prevent any change in a reference affecting
   // all subsequent references in a reference chain (which should require
   // to check not only the own cache tick but all cache ticks in references
   // upward in the chain); for those cases in which this is needed (like
   // integrating a solid motion, with all actions expressed in relative
   // coordinates and then the motion is updated) erase_cache_0() should be
   // called before updating the reference
   void check_abs_0() const; // calls calculate_abs_0() if necessary
   void calculate_abs_0() const; // calculates *_abs_cache and updates
                               // tick_cache_0
   mutable integer tick_cache_0; // tick in which cache was calculated
   mutable Vector origin_abs_cache; // with regard to absolute reference
   mutable Quaternion attitude_abs_cache; // with regard to absolute reference
 protected:
   void erase_cache_0() const; // allows to update the reference
};

/* Reference_1 **************************************************************/

/* The class Reference_1 is similar to Reference_0 class, but considers
 * first order kinematics, that is handles also velocities (linear and angular)
 * Reference_1 is a class derived from Reference_0, so it inherits all its
 * capabilities and also provides first order specific ones.
 *
 * Reference_1 honours the tick system implemented in "base.h"; see
 * Reference_0. */


class Reference_1 // positional magnitudes and first order derivatives
: public Reference_0 {
 public:
   Reference_1(Reference_1 *parent_=0);

   void set_parent(Vector origin_parent, Quaternion attitude_parent,
		  Vector velocity_parent, Vector velocity_angular_parent);
   void set_abs(Vector origin_abs, Quaternion attitude_abs,
		Vector velocity_abs, Vector velocity_angular_abs,
		Reference_1 *ref_abs=0);

   Vector velocity_origin_parent() const;
     // gets 'origin' velocity with regard to parent
   Vector velocity_origin_abs(Reference_1 *ref_abs=0) const;
     // gets 'origin' velocity with regard to 'ref_abs'
   Vector velocity_angular_parent() const;
     // gets angular velocity with regard to parent
   Vector velocity_angular_abs(Reference_1 *ref_abs=0) const;
     // gets angular velocity with regard to 'ref_abs'

   Vector velocity_rel_to_parent(Vector point_rel,
				Vector velocity_rel=Vector()) const;
     // velocity expressed in 'this' coordinates converted to parent
   Vector velocity_parent_to_rel(Vector point_rel,
				Vector velocity_parent=Vector()) const;
     // velocity expressed in parent coordinates converted to 'this'
   Vector velocity_rel_to_abs(Vector point_rel,
			      Vector velocity_rel=Vector(),
			      Reference_1 *ref_abs=0) const;
     // velocity expressed in 'this' coordinates converted to 'ref_abs'
   Vector velocity_abs_to_rel(Vector point_rel,
			      Vector velocity_abs=Vector(),
			      Reference_1 *ref_abs=0) const;
     // velocity expressed in 'ref_abs' coordinates converted to 'this'

   void initializeReference_1();

   void display_variables(std::string prefixed);
   void record_play();

private:
   Reference_1 const *const parent;

   Vector velocity_origin; // with regard to parent
   Vector velocity_angular; // with regard to parent
   // following methods and variables are analogous to those of Reference_0
   void check_abs_1() const;
   void calculate_abs_1() const;
   mutable integer tick_cache_1;
   mutable Vector velocity_origin_abs_cache; // with regard to absolute
                                              // reference
   mutable Vector velocity_angular_abs_cache; // with regard to absolute
                                               // reference
 protected:
   void erase_cache_1() const;
};

/* Solid ********************************************************************/

/* The class Solid implements the equations of motion of a rigid solid.
 * The rigid solid is composed of a Reference_1 class with a mass distribution
 * represented by a SolidMass object. The integrating procedures to be used for
 * integration of motion are supplied to the constructor. The Solid can be set
 * fixed (in which case  linear and angular accelerations are nulled before
 * integration), for debugging purposes or for model validation. */

class ModelSolidMass {
public:
  virtual ~ModelSolidMass() { }
  virtual SolidMass solid_mass() const=0;
};

class ModelSolidAction {
public:
  virtual ~ModelSolidAction() { }
  virtual SolidAction solid_action() const=0;
};

class ModelSolidAcceleration {
public:
  virtual ~ModelSolidAcceleration() { }
  virtual SolidAcceleration solid_acceleration() const=0;
};

class ModelSolidAddedVelocity {
public:
  virtual ~ModelSolidAddedVelocity() { }
  virtual SolidVelocity solid_added_velocity() const=0;
};

class Solid
: public Reference_1,
  public Model,
  public Subscriptable<Solid, ModelSolidMass const>,
  public Subscriptable<Solid, ModelSolidAction const>,
  public Subscriptable<Solid, ModelSolidAcceleration const>,
  public Subscriptable<Solid, ModelSolidAddedVelocity const> {
 public:
   Solid(pointer_type(Integrator<Vector>) ace_vel,
         pointer_type(Integrator<Vector>) vel_pos,
         pointer_type(Integrator<Vector>) aceang_velang,
         pointer_type(Integrator<Quaternion>) velang_att,
         Reference_1 *reference=0,
         bool fixed=false);
   ~Solid() {
     release_pointer(ace_vel_);
     release_pointer(vel_pos_);
     release_pointer(aceang_velang_);
     release_pointer(velang_att_);
   }
   typedef std::pair<bool, Vector> LimVector;
   void set_ace_limit(cppfunct::Function<LimVector (Vector)> const &f);
   void set_vel_limit(cppfunct::Function<LimVector (Vector)> const &f);
   void set_aceang_limit(cppfunct::Function<LimVector (Vector)> const &f);
   void set_velang_limit(cppfunct::Function<LimVector (Vector)> const &f);

   void initialize(Vector pos_abs_0, Vector vel_abs_0,
		Quaternion att_abs_0, Vector velang_rel_0=Vector());
   void cg_initialize(Vector pos_abs_0, Vector vel_abs_0,
		   Quaternion att_abs_0, Vector velang_rel_0=Vector());
   void model(); // integrates position and attittude

private:
  typedef Subscriptable<Solid, ModelSolidMass const>
    SubscriptableSolidMass;
  typedef Subscriptable<Solid, ModelSolidAction const>
    SubscriptableSolidAction;
  typedef Subscriptable<Solid, ModelSolidAcceleration const>
    SubscriptableSolidAcceleration;
  typedef Subscriptable<Solid, ModelSolidAddedVelocity const>
    SubscriptableSolidAddedVelocity;

public:
  typedef SubscriptableSolidMass::Handle HandleSolidMass;
  typedef SubscriptableSolidAction::Handle HandleSolidAction;
  typedef SubscriptableSolidAcceleration::Handle HandleSolidAcceleration;
  typedef SubscriptableSolidAddedVelocity::Handle HandleSolidAddedVelocity;

  HandleSolidMass
  subscribe_SolidMass(pointer_type(ModelSolidMass const) mm)
  { return SubscriptableSolidMass::subscribe(mm); }
  void cancel_SolidMass(HandleSolidMass hm)
  { SubscriptableSolidMass::unsubscribe(hm); }
  SolidMass total_SolidMass() const;

  // Action in relative coordinates (force and moment), with regard to solid
  // reference point
  HandleSolidAction
  subscribe_SolidAction(pointer_type(ModelSolidAction const) ma)
  { return SubscriptableSolidAction::subscribe(ma); }
  void cancel_SolidAction(HandleSolidAction ha)
  { SubscriptableSolidAction::unsubscribe(ha); }
  SolidAction total_SolidAction() const;
  bool is_any_SolidAction_subscribed() const;

  // Acceleration, linear in absolute coordinates and angular in relative
  // coordinates, with regard to solid reference cg
  HandleSolidAcceleration
  subscribe_SolidAcceleration(pointer_type(ModelSolidAcceleration const) ma)
  { return SubscriptableSolidAcceleration::subscribe(ma); }
  void cancel_SolidAcceleration(HandleSolidAcceleration ha)
  { SubscriptableSolidAcceleration::unsubscribe(ha); }
  SolidAcceleration total_SolidAcceleration() const;

  // Added Velocity
  // Linear velocity in absolute coordinates and
  // angular velocity relative to solid reference
  HandleSolidAddedVelocity
  subscribe_SolidAddedVelocity(pointer_type(ModelSolidAddedVelocity const) ma)
  { return SubscriptableSolidAddedVelocity::subscribe(ma); }
  void cancel_SolidAddedVelocity(HandleSolidAddedVelocity ha)
  { SubscriptableSolidAddedVelocity::unsubscribe(ha); }
  SolidVelocity total_SolidAddedVelocity() const;

   void initializeSolid(); // Inicialize the solid

   Vector point_to_rel(Vector point_abs) const;
   Vector point_to_abs(Vector point_rel) const;
   Vector vector_to_rel(Vector vector_abs) const;
   Vector vector_to_abs(Vector vector_rel) const;
   Quaternion quaternion_to_rel(Quaternion quaternion_abs) const;
   Quaternion quaternion_to_abs(Quaternion quaternion_rel) const;

   Vector vel_abs(Vector point_rel) const; // velocity of a point of the solid

   Vector cg_rel() const;

   Vector cg_pos_abs;   // in absolute coordinates
   Vector cg_vel_abs;   // in absolute coordinates
   Vector cg_vel_rel;   // in relative coordinates
   Vector cg_ace_abs;   // in absolute coordinates
   Vector cg_ace_rel;   // in relative coordinates
   Quaternion att_abs;  // in absolute coordinates
   Vector velang_rel;   // in relative coordinates
   Vector velang_abs;   // in absolute coordinates
   Vector aceang_rel;   // in relative coordinates
   Vector aceang_abs;   // in absolute coordinates
   Vector orig_pos_abs; // in absolute coordinates
   Vector orig_vel_abs; // in absolute coordinates

   Vector accel_but_SolidAcceleration_abs;
   Vector accel_but_SolidAcceleration_rel;

   void fix_solid(bool fixed);  //to set the solid fixed

   void display_variables(std::string prefixed);
   void record_play();

private:
   pointer_type(Integrator<Vector>) ace_vel_;
   pointer_type(Integrator<Vector>) vel_pos_;
   pointer_type(Integrator<Vector>) aceang_velang_;
   pointer_type(Integrator<Quaternion>) velang_att_;
   bool Fixed;
   void calculate_orig(); // position and velocity of relative coordinates
                        // reference point
   void calculate_accelerations(); // calculaes linear and angular accelerations,
                                 // done in model()
   cppfunct::Function<LimVector (Vector)>
     ace_lim, vel_lim, aceang_lim, velang_lim;
};

extern cppfunct::Function<Solid::LimVector (Vector)>
function_norm_limit_vector(scalar max_norm);

class ModelSolidMassConstant
  : public ModelSolidMass {
public:
  ModelSolidMassConstant(SolidMass value) : value(value) { }
  SolidMass solid_mass() const { return value; }
private:
  SolidMass const value;
};

class ModelSolidMassAsignable
  : public ModelSolidMass {
public:
  ModelSolidMassAsignable() : value() { }
  SolidMass solid_mass() const { return value; }
  void set(SolidMass new_value) { value=new_value; }
private:
  SolidMass value;
};

template <typename Ret> class Functor_0;

class ModelSolidMassFunctor_0
  : public ModelSolidMass {
public:
  ModelSolidMassFunctor_0(pointer_type(Functor_0<SolidMass> const ) sm);
  SolidMass solid_mass() const;
private:
  pointer_type(Functor_0<SolidMass> const) const sm;
};

class ModelSolidActionAsignable
  : public ModelSolidAction {
public:
  ModelSolidActionAsignable() : value() { }
  SolidAction solid_action() const { return value; }
  void set(SolidAction new_value) { value=new_value; }
private:
  SolidAction value;
};

#endif
