#include "regression.h"
#include <iostream>

using std::cout;
using std::endl;

using namespace Regression;
using namespace Algebra;

void linear_regression_line()
{

  //(X): 7.2 6.7 17.0 12.5 6.3 23.9 6.0 10.2
  //(Y): 4.2 4.9 7.0 6.2 3.8 7.6 4.4 5.4 

  Vector<double,8> y;
  Matrix<double,8,1> X;

  X(0)(0)=7.2 ,X(1)(0)=6.7, X(2)(0)=17.0 ,X(3)(0)=12.5 ,X(4)(0)=6.3 ;
  X(5)(0)=23.9 ,X(6)(0)=6.0 ,X(7)(0)=10.2;


  y(0)=4.2, y(1)=4.9, y(2)=7.0, y(3)=6.2, y(4)=3.8;
  y(5)=7.6, y(6)=4.4, y(7)=5.4 ;

  cout << "Linear regression Coeficients:"
       << "Y= A + B*x   "
       << endl; 
  cout << least_squares(y,X).coefficient 
       << "R2: "<<least_squares(y,X).R2()
       << " SSE: "<<least_squares(y,X).SSE()
       << " SST: "<<least_squares(y,X).SST()
       
       << endl;



}


void linear_regression_plane()
{
  Vector<double,13> y;
  Matrix<double,13,3> x;

  // Example
  //y x x x
  y(0)=25.5, x(0)(0)=1.74, x(0)(1)=5.30, x(0)(2) = 10.80;
  y(1)=31.2, x(1)(0)=6.32, x(1)(1)=5.42, x(1)(2) = 9.40 ;
  y(2)=25.9, x(2)(0)=6.22, x(2)(1)=8.41, x(2)(2) =  7.20;
  y(3)=38.4, x(3)(0)=10.52, x(3)(1)=4.63, x(3)(2) =  8.50;

  y(4)=18.4, x(4)(0)=1.19, x(4)(1)=11.6, x(4)(2) =  9.40;
  y(5)=26.7, x(5)(0)=1.22, x(5)(1)=5.85, x(5)(2) =  9.9;
  y(6)=26.4, x(6)(0)=4.10, x(6)(1)=6.62, x(6)(2) =  8.00;
  y(7)=25.9, x(7)(0)=6.32, x(7)(1)=8.720, x(7)(2) =  9.1;

  y(8)=32.0, x(8)(0)=4.08, x(8)(1)=4.42, x(8)(2) =  8.7;
  y(9)=25.2, x(9)(0)=4.15, x(9)(1)=7.60, x(9)(2) =  9.2;
  y(10)=39.7, x(10)(0)=10.15, x(10)(1)=4.83, x(10)(2) =  9.4;
  y(11)=35.7, x(11)(0)=1.72, x(11)(1)=3.120, x(11)(2) =  7.60;
  y(12)=26.5, x(12)(0)=1.70, x(12)(1)=5.300, x(12)(2) =  8.2;

  /*
    Solution:
    y = b0 + b1*x1 + b2*x2 + b3*x3;      where
    b0= 39.1574    b1= 1.0161    b2=-1.8616    b3=-0.3433
  */

  cout << "Linear regression Coeficients:"
       << "Y= BO + B1*x1 + B2*x2 + B3*x3 "
       << endl; 
  cout << least_squares(y,x).coefficient
       << "R2: "<< least_squares(y,x).R2()
       << " SSE: "<<least_squares(y,x).SSE()
       << " SST: "<<least_squares(y,x).SST()

       << endl;
  

}

void linear_regression_plane2()
{

  Vector<double,12> y;
  Matrix<double,12,2> x;

  // Example
  //y x x x
  x(0)(1)=98.70, y(0)=32.0, x(0)(0)=2.40 ;
  x(1)(1)=100.10, y(1)=43.0, x(1)(0)=2.20 ;
  x(2)(1)=100.10, y(2)=60.0, x(2)(0)=2.10 ;
  x(3)(1)=99.00, y(3)=75.00, x(3)(0)=3.60 ;

  x(4)(1)=97.0, y(4)=75.0, x(4)(0)=4.70  ;
  x(5)(1)=99.70, y(5)=75.0, x(5)(0)=3.90  ;
  x(6)(1)=101.10, y(6)=79.0, x(6)(0)=2.40  ;
  x(7)(1)=99.80, y(7)=80.0, x(7)(0)=4.000  ;

  x(8)(1)=100.20, y(8)=81.0, x(8)(0)=3.30  ;
  x(9)(1)=100.20, y(9)=99.0, x(9)(0)=4.70  ;
  x(10)(1)=100.0, y(10)=111.0, x(10)(0)=5.50  ;
  x(11)(1)=100.0, y(11)=111.0, x(11)(0)=4.600  ;

  cout << "Linear regression Coeficients:"
       << "Y= BO + B1*x1 + B2*x2 "
       << endl; 

  cout << least_squares(y,x).coefficient
       << "R2: "<< least_squares(y,x).R2()
       << " SSE: "<<least_squares(y,x).SSE()
       << " SST: "<<least_squares(y,x).SST()

       << endl;



}

int main()
{
  linear_regression_line();
  linear_regression_plane();
  linear_regression_plane2();
  
}
