#ifndef BASE_FACTORY_HEADER_
#define BASE_FACTORY_HEADER_

#include "../base/pointer_policy.h"

/* Factory is a convenience class used as a means to pass a way to construct
 * many objects of a kind, without knowing beforehand of which kind exactly.
 * Its typical use case is as follows: a class needs an unspecified number of
 * objects of a class that implements an abstract class, but you don't know how
 * many nor of which concrete type; in that case, what you give the class'
 * constructor is a factory (by pointer) templated on the abstract class; when
 * you instantiate the class, you pass it a pointer to a newly created factory
 * for the concrete type. */
namespace BaseFactory {

  struct NoArgument { };

  template <typename Type, typename Argument=NoArgument>
  class Factory {
  public:
    virtual ~Factory() { }
    virtual pointer_type(Type) create_new(Argument const &) const=0;

  };

  template <typename Type>
  class Factory<Type, NoArgument> {
  public:
    virtual ~Factory() { }
    virtual pointer_type(Type) create_new() const=0;

  };

};

#endif
