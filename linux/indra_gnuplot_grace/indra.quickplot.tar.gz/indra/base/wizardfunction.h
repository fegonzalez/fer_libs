#ifndef WIZARD_FUNCTION_HEADER_
#define WIZARD_FUNCTION_HEADER_

#include "functor.h"
#include "scalar.h"
#include "base.h"

//Functor that defines a constant function
class Constant : public Functor_1<scalar> {
public:
    Constant(scalar y) : y(y) {}
    scalar operator() (scalar const &x) const { (void) x; return y; }
private:
    scalar y;
};

//Functor that defines a linear function
class Line : public Functor_1<scalar> {
public:
    Line(scalar x_0, scalar y_0, scalar slope)
        : x_0(x_0), y_0(y_0), slope(slope) { }
    static Line *new_by_points(scalar x1, scalar y1, scalar x2, scalar y2);
    static Line *new_by_pointer_points(scalar const *x1,scalar const *y1,
				       scalar const *x2,scalar const *y2);
    static Line *new_by_pointers(scalar const *x_0,scalar const *y_0,
				 scalar const *slope);
    
    scalar operator()(scalar const &x) const;
private:
    scalar x_0, y_0, slope;
};

//Fucntor that defines a quadratic function
class Quadratic : public Functor_1<scalar> {
public:
    Quadratic(scalar A, scalar B, scalar C)
        : A(A), B(B), C(C) {}
    static Quadratic *new_by_points(scalar x1, scalar y1,
                                    scalar x2, scalar y2,
                                    scalar x3, scalar y3);
    scalar operator()(scalar const &x) const;
private:
    scalar A,B,C;
};

//Functor that defines an exponential function
class Exponential : public Functor_1<scalar> {
public:
    Exponential(scalar y0, scalar A, scalar B)
        : y0(y0),A(A),B(B) {}
    static Exponential *new_by_points(scalar x1, scalar y1,
                                      scalar x2, scalar y2,
                                      scalar x3, scalar y3);

    scalar operator()(scalar const &x) const;
private:
    scalar y0,A,B;
};

#endif
