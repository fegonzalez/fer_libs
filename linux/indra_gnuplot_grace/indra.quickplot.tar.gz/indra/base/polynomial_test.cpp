
#include "scalar.h"
#include "polynomial.h"

#include <iostream>
using namespace std;

using namespace Function;


int main() 
{
  
    Algebra::GeneralVector<scalar,3> cx2;
    cx2(0) = 0.0;
    cx2(1) = 0.0;
    cx2(2) = 1.0;
    Polynomial<scalar,2> x2(cx2);


    Algebra::GeneralVector<scalar,4> cx3;
    cx3(0) = 1.0;
    cx3(1) = 0.0;
    cx3(2) = 0.0;
    cx3(3) = 1.0;
    Polynomial<scalar,3> x3(cx3);


    scalar x= -2.0;
    scalar delta_x = 0.10;

    while (x <= 2.1)
      {
	cout << x << "  " << x2(x) << "  " << x2.dPdx(x)
 	     << "  " << x3(x) << "  " << x3.dPdx(x) 
	     << endl;
	x = x +  delta_x;
      }
    
    
};
