#ifndef INTROSPECTION_HEADER_
#define INTROSPECTION_HEADER_


#include <list>
#include <map>
#include <string>


namespace HierarchyIntrospection
{


  template< typename T>
  class Dictionary
  {
  public:

    typedef std::map<std::string, T *> Map;

    bool declare(std::string name,T *component)
    {
      dictionary_map[name]=component; 
      return true;
    }

    void undeclare(std::string name)
    {
      dictionary_map.erase(name);      
    }

    T *get(std::string name)
    {
      return dictionary_map.find(name)->second;
    }

    std::list<std::string> get_list() const 
    {
      std::list<std::string> result;

      for(typename Map::const_iterator scan=dictionary_map.begin();
	  scan!=dictionary_map.end();++scan)
	{
	  result.push_back(scan->first);
	}

      return result;
    }

    static Dictionary &singleton()
    {
      static Dictionary *const one=new Dictionary;
      return *one;
    }


  private:
   
    Dictionary(){} // private constructor for the singleton
    Map dictionary_map;

  };




}

# endif
