#ifndef PIECE_FUNCTION_HEADER_
#define PIECE_FUNCTION_HEADER_

#include "functor.h"
#include "scalar.h"
#include <map>

//This class allows to add functions in a specified range in order to cover a
//big range of values. Functions are stored by means of
//add_function method. Once functions are added, the operator() returns a value
//according to the point you want to get and the ranges of each function.
//In order to use this feature, you should define several Functor_1 functors
//and one PieceFunction_1 function. Then, you should add the functors to the
//piece function. In this point, you can use the piece function like a normal
//function. In a range between two ranges defined, the function interpolates
//linearly between near functors. If the argument is lower than the most low
//range, or is higher than the highest range, the function limits to value at
//the range ends.
class PieceFunction_1 : public Functor_1<scalar> {
public:
    ~PieceFunction_1() { };

    typedef std::map<scalar, Functor_1<scalar> *> FunctionCtr;

    void add_function(scalar min, scalar max,
                                Functor_1<scalar> *new_function);
    scalar operator()(scalar const &value) const;
private:
    FunctionCtr function_container_1;
    FunctionCtr function_container_2;
};

#endif
