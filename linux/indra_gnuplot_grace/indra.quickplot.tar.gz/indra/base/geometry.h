#ifndef BASE_GEOMETRY_HEADER_
#define BASE_GEOMETRY_HEADER_

#include "base.h"
#include <iostream>

class Quaternion;

/* container classes *********************************************************/

struct psithetaphi { scalar psi, theta, phi; };
struct der_psithetaphi { scalar der_psi, der_theta, der_phi; };
struct psitheta { scalar psi, theta; };
struct thetaphi { scalar theta, phi; };
struct alphabeta { scalar alpha, beta; };

std::ostream &operator<<(std::ostream &os, psithetaphi ptp);
std::ostream &operator<<(std::ostream &os, psitheta pt);
std::ostream &operator<<(std::ostream &os, thetaphi tp);
std::ostream &operator<<(std::ostream &os, alphabeta ab);

/* Vector ********************************************************************/

/* Vector represents a three-component vector. */
class Vector {
public:
  typedef Vector DerivativeType;
  Vector() : _x(0), _y(0), _z(0) { }; // null vector by default
  Vector(scalar x, scalar y, scalar z) : _x(x), _y(y), _z(z) { };
  scalar x() const { return _x; } ; // 'x' coordinate
  scalar y() const { return _y; } ; // 'y' coordinate
  scalar z() const { return _z; } ; // 'z' coordinate
  inline Vector &operator+=(Vector a); // increment
  inline Vector &operator-=(Vector a); //decrement

  // get the rotation that brings the vector (1, 0, 0) alligned with the vector
  // on which the consultor is invoked; the rotation consists of an angle psi
  // around the 'z' axis, followed by an angle theta around the rotated 'y'
  // axis
  inline void getpsitheta(scalar &psi, scalar &theta) const;
  inline psitheta getpsitheta() const;

  // get the rotation that brings the vector (0, 0, 1) alligned with the vector
  // on which the consultor is invoked; the rotation consists of an angle theta
  // around the 'y' axis, followed by an angle phi around the rotated 'x' axis
  inline thetaphi getthetaphi() const;

  inline alphabeta getalphabeta() const;
protected:
   scalar _x, _y, _z;
};

// stream operators
std::ostream &operator<<(std::ostream &os, Vector a);
std::istream &operator>>(std::istream &is, Vector &a);

inline Vector operator-(Vector a); // unary minus
inline Vector operator*(scalar k, Vector a); // multiplication by a scalar
inline Vector operator*(Vector a, scalar k); // multiplicaci�n by a scalar
inline Vector operator/(Vector a, scalar k); // division by a scalar
inline Vector operator+(Vector a, Vector b); // sum
inline Vector operator-(Vector a, Vector b); // subtraction
inline Vector operator*(Vector a, Vector b); // cross product
inline scalar scalprod(Vector a, Vector b); // escalar product
inline scalar norm(Vector a); // norm
inline Vector normalise(Vector a); // return the normalised vector
inline Vector vpsitheta(psitheta const &angles);
inline Vector vthetaphi(thetaphi const &angles);
inline Vector valphabeta(alphabeta const &angles);

/* Matrix ********************************************************************/

/* Matrix represents a squared three-by-three matrix.  It consists of three row
 * vectors.  Therefore, the element in row 'x' column 'y' in matrix 'A' is
 * expressed 'A.x().y()'. */
class Matrix {
public:
  typedef Matrix DerivativeType;
  Matrix() : _x(), _y(), _z() { } ; // null matrix by default
  Matrix(scalar a11, scalar a12, scalar a13,
	 scalar a21, scalar a22, scalar a23,
	 scalar a31, scalar a32, scalar a33) :
    _x(a11, a12, a13), _y(a21, a22, a23), _z(a31, a32, a33) { } ;
  Matrix(Vector r1, Vector r2, Vector r3) : _x(r1), _y(r2), _z(r3) { };
  Vector x() const { return _x; }; // row vector 'x'
  Vector y() const { return _y; }; // row vector 'y'
  Vector z() const { return _z; }; // row vector 'z'
  Vector colx() const { return Vector(_x.x(), _y.x(), _z.x()); };
  // column vector 'x'
  Vector coly() const { return Vector(_x.y(), _y.y(), _z.y()); };
  // column vector 'y'
  Vector colz() const { return Vector(_x.z(), _y.z(), _z.z()); };
  // column vector 'z'
  inline operator Quaternion() const; // converts a rotation matrix into the
                                      // corresponding quaternion
  inline void getpsithetaphi(scalar &psi, scalar &theta, scalar &phi) const;
    // gets from a rotation matrix the rotation angles psi, theta, and phi
private:
  Vector _x, _y, _z;
};

// stream operators
std::ostream &operator<<(std::ostream &os, Matrix a);
std::istream &operator>>(std::istream &is, Matrix &a);

inline Matrix operator-(Matrix a); // unary minus
inline Matrix operator*(scalar k, Matrix a); // multiplication by a scalar
inline Matrix operator*(Matrix a, scalar k); // multiplication by a scalar
inline Matrix operator/(Matrix a, scalar k); // division by a scalar
inline Matrix operator+(Matrix a, Matrix b); // sum
inline Matrix operator-(Matrix a, Matrix b); // subtraction
inline Matrix operator*(Matrix a, Matrix b); // matrix multiplication
inline Matrix trans(Matrix a); // transposed
inline scalar det(Matrix a); // determinant
inline Matrix inv(Matrix a); // inverse
inline Vector operator*(Matrix m, Vector v); // postmultiplication by a vector
inline Matrix mpsithetaphi(scalar psi, scalar theta, scalar phi);
  // rotation matrix construction from rotation angles psi, theta, and phi

/* Quaternion ****************************************************************/

struct axis_angle {
  axis_angle(Vector const &axis, scalar angle)
    : axis(axis), angle(angle) { }
  Vector axis;
  scalar angle;
};

std::ostream &operator<<(std::ostream &os, axis_angle aa);

/* Quaternion represents a unit norm quaternion, used to characterise a
 * rotation in three dimensions. */
class Quaternion {
public:
  typedef Vector DerivativeType;
  Quaternion() : _q0(1), _q1(0), _q2(0), _q3(0) { };
  Quaternion(scalar q0, scalar q1, scalar q2, scalar q3) :
    _q0(q0), _q1(q1), _q2(q2), _q3(q3) { normalise(); };
  inline Quaternion(Vector axis, scalar ang);
    // rotation of angle 'ang' around axis 'axis'
  scalar q0() const { return _q0; };
  scalar q1() const { return _q1; };
  scalar q2() const { return _q2; };
  scalar q3() const { return _q3; };
  inline operator Matrix() const;
  inline Quaternion &rot_rel(Vector omegadt); // add an infinitesimal rotation
                                              // expressed in relative
                                              // coordinates
  inline Quaternion &rot_abs(Vector omegadt); // add an infinitesimal rotation
                                              // expressed in absolute
                                              // coordinates
  inline Quaternion &operator+=(Vector omegadt) { return rot_rel(omegadt); };
    // synonymous with 'rot_rel' (relative coordinates); used for integration
  inline void getpsithetaphi(scalar &psi, scalar &theta, scalar &phi) const;
  inline psithetaphi getpsithetaphi() const;
  scalar get_psi() const; // get rotation angle psi
  scalar get_theta() const; // get rotation angle theta
  scalar get_phi() const; // get rotation angle phi
  axis_angle get_axis_angle() const;
private:
  scalar _q0, _q1, _q2, _q3;
  inline void normalise();
  inline scalar error() const; // return norm-1. used for corrections after rotations
};

// stream operators
std::ostream &operator<<(std::ostream &os, Quaternion a);
std::istream &operator>>(std::istream &is, Quaternion &a);

inline Vector operator*(Quaternion q, Vector a);
  // rotate the vector with the quaternion
inline Quaternion operator*(Quaternion a, Quaternion b); // composition
inline Quaternion inv(Quaternion a); // inverse
inline Quaternion qpsithetaphi(scalar psi, scalar theta, scalar phi);
  // quaternion construction from rotation angles psi, theta, and phi
inline Quaternion qpsithetaphi(psithetaphi const &angles);

inline der_psithetaphi der_euler(Quaternion attitude,
                                 Vector angular_velocity_relative);

struct PositionAttitude {
  PositionAttitude(Vector const &position, Quaternion const &attitude)
    : position(position), attitude(attitude) { }
  Vector position;
  Quaternion attitude;
};

#include "geometry.inl"

#endif
