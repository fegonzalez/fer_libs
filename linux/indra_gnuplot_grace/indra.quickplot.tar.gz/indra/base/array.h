#ifndef ARRAY_HEADER_
#define ARRAY_HEADER_

template <class Type, unsigned int array_size>
class array {
 public:
   array()
     {
	for (unsigned int i=0; i<array_size; i++)
	  data[i]=Type();
     };

   Type &operator[](unsigned int i)
     {
	if (i>=array_size)
	  throw "array index exceeded maximum";
	return data[i];
     };

   Type const &operator[](unsigned i) const
     { return static_cast<Type const &>(operator[](i)); };

   unsigned int size()
     { return array_size; };

 private:
   Type data[array_size];
};

template <class Type, unsigned int array_size_1, unsigned int array_size_2>
class array_2
: public ::array<array<Type, array_size_2>, array_size_1>
{
 public:
   unsigned int size_1()
     { return array_size_1; };
   unsigned int size_2()
     { return array_size_2; };
};


#endif
