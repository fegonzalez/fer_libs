#include "real_time.h"

namespace RealTime
{

  TimerTime TestClock::get_time() 
  {
    current_time.microseconds+=250000;
    if (current_time.microseconds>=1000000) {
      ++current_time.seconds;
      current_time.microseconds-=1000000;
    }
    return current_time;
  }

  TimerTime TestClock::current_time;





};
