#include <iostream>
#include "autodel.h"

late_auto_del_ptr<double> x;
late_auto_del_ptr<double const> y;

int main() {
  // FIXME: for the moment only checks compilation
}
