#ifndef ALGEBRA_HEADER_
#define ALGEBRA_HEADER_

#include <iostream>
#include <math.h>

namespace Algebra
{

  template <class T, int n>
  class GeneralVector {

  public:

    T operator() (int i) const
    {
      check_dimension(i);
      return v[i];
    }

    T& operator()(int i)
    {
      check_dimension(i);
      return v[i];
    }

    GeneralVector<T,n>& operator+=(GeneralVector<T,n> const &b)
    {
      for(int i=0; i <n; i++)
	{
	  (*this)(i)+=b(i);
	}
      return *this;
    }

    GeneralVector<T,n>& operator-=(GeneralVector<T,n> const &b)
    {
      for(int i=0; i <n; i++)
	{
	  (*this)(i)-=b(i);
	}
      return *this;
    }

    template <class U>
    GeneralVector<T,n>& operator*=(U const &k)
    {
      for(int i=0; i <n; i++)
	{
	  (*this)(i)*= k;
	}
      return *this;
    }



  private:

    void check_dimension(int ii) const
    {
      if(not ( (0 <= ii) and (ii< n))) throw ("Invalid dimension: ");
    }

    T v[n];
  };

  template <typename T>
  struct ScalarElement {
    typedef T Type;
  };

  template <typename T, int n>
  struct ScalarElement<GeneralVector<T, n> > {
    typedef typename ScalarElement<T>::Type Type;
  };

  /* GeneralVector *****************************************/
  template <class T, int n>
  std::ostream &operator<<(std::ostream &os, GeneralVector<T,n> const a)
  {
    for(int ii=0;ii<n; ii++)
      {
	os << a(ii) << " ";
      }

    return os;
  };

  template <class T, int n>
  std::istream &operator>>(std::istream &is,  GeneralVector<T,n> &a)
  {
    T data[n];

    for(int ii= 0; ii<n; ii++ )
      {
	is >> data[ii];
	a(ii) = data[ii];
      }

    

    return is;
  }



  template <class T_times_U, class T, class U, int m>
  T_times_U multiply(GeneralVector<T, m> const &a, GeneralVector<U, m> const &b)
  {
    T_times_U result = a(0)*b(0);
    for (int i=1; i<m; ++i)
      result+=a(i)*b(i);
    return result;
  }
  template <class T_times_U, class T, class U, int m, int n>
  T_times_U multiply_expand(GeneralVector<T, m> const &a,
			    GeneralVector<U, n> const &b)
  {
    T_times_U result;

    for (int i=0; i<m; ++i)
      {
	for (int j=0; j<n; ++j)
	  {
	    result(i)(j)= a(i)*b(j);
	  }
      }

    return result;
  }

  template <class T, int m>
  T operator*(GeneralVector<T, m> const &a, GeneralVector<T, m> const &b)
  {
    return multiply<T, T, T, m>(a, b);
  }

  template <class T, int m, int n>
  GeneralVector<T, n> operator*(GeneralVector<GeneralVector<T, m>, n> const &a,
				GeneralVector<T, m> const &b)
  {
    return multiply<GeneralVector<T, n>, GeneralVector<T, m>, T, m>(a, b);
  }




  /* Vector *****************************************/
  template <class T, int m>
  class Vector : public GeneralVector<T, m>
  {
  };

  /* Matrix *****************************************/
  template <class T, int m, int n>
  class Matrix : public GeneralVector<GeneralVector<T, n>, m>
  {
  };

  template <class T, int m, int n>
  Matrix<T, n, m> trans(Matrix<T, m, n> const &a)
  {
    Matrix<T,n,m> result;

    for (int ii = 0; ii<n; ii++)
      {
	for(int jj = 0; jj<m; jj++)
	  {
	    result(ii)(jj) = a(jj)(ii);
	  }
      }

    return result;
  }


  template <class T, int m, int n>
  GeneralVector<T, m> operator*(Matrix<T, m, n> const &a, GeneralVector<T, n> const &b) {
    return multiply<GeneralVector<T, m>, GeneralVector<T, m>, T, n>(trans(a), b);
  }

  template <class T, int m, int n, int p>
  Matrix<T, m, p> operator*(Matrix<T, m, n> const &a, Matrix<T, n, p> const &b) {

    return multiply_expand< Matrix<T, m, p>,
      GeneralVector<T, n>,GeneralVector<T, n>,
      m,p>(a,trans(b));
  }

  template <class T, int m>
  GeneralVector<T, m> operator+(GeneralVector<T, m> const &a,
				GeneralVector<T, m> const &b)
  {
    GeneralVector<T, m> result(a);
    result+=b;
    return result;
  }

  template <class T, int m>
  GeneralVector<T, m> operator-(GeneralVector<T, m> const &a,
				GeneralVector<T, m> const &b)
  {
    GeneralVector<T, m> result(a);
    result-=b;
    return result;
  }

  template <class T, int m>
  GeneralVector<T, m> operator-(GeneralVector<T, m> const &a) {
    GeneralVector<T, m> result;

    for (int ii=0; ii<m; ii++)
      result(ii)= -a(ii);
    return result;
  }

  template <class T, int m,int n>
  Matrix<T, m,n> operator-(Matrix<T, m,n> const &a) {
    Matrix<T, m,n> result;

    for (int ii=0; ii<m; ii++)
      {
	for(int jj=0; jj<n; jj++)
	  {
	    result(ii)(jj)= -a(ii)(jj);
	  }
      }
    return result;
  }

  template <class T, int m>
  GeneralVector<T, m> operator*(GeneralVector<T, m> const &a,
				typename ScalarElement<T>::Type const &k)
  {
    GeneralVector<T, m> result(a);
    result*=k;
    return result;
  }


  template <class T, int m>
  GeneralVector<T, m> operator*(typename ScalarElement<T>::Type const &k,
				GeneralVector<T, m> const &a)
  { return a*k; }



  template <class T, int n>
  Matrix<T, n, n> LU(Matrix<T, n, n>  A, T &d, Vector<int,n> &indx);

  template <class T, int n>
  Matrix<T, n, n> LU(Matrix<T, n, n>  A, T &d);

  template <class T, int n>
  Matrix<T, n, n> LU(Matrix<T, n, n>  A);

  template <class T, int n>
  T det(Matrix<T, n, n> const &A);


  template <class T, int n>
  Vector<T,n> solve(Matrix<T, n, n>  const &A, Vector<T,n> const &b);

  template <class T, int n,int m>
  Matrix<T,n,m> solve(Matrix<T, n, n>  const &A, Matrix<T,n,m> const &b);


  template <class T, int n>
  Matrix<T,n,n> inverse(Matrix<T, n, n>  const &A);



}

namespace Algebra {

  template <class T, int n>
  Matrix<T, n, n> LU(Matrix<T, n, n> A, T &d, Vector<int,n> &indx)
  {
    T const epsilon = 1.0e-40;
    T big;
    Vector<T,n> vv;
    int imax=0;
    d = 1.0;
    T temp;

    for(int ii=0; ii< n; ii++)
      {
	big = 0;

	for(int jj=0; jj<n; jj++)
	  {
	    if ( (temp=fabs(A(ii)(jj))) > big )
	      {
		big = temp;
	      }
	  }

	if( fabs(big) < epsilon)
	  {
	    throw (" Singular matrix in LU");
	  }

	vv(ii) = 1.0/big;
      }

    for(int kk=0; kk<n; kk++)
      {
	big = 0.0;

	for(int ii=kk; ii<n; ii++)
	  {
	    T temp = vv(ii)*fabs(A(ii)(kk));
	    if (temp > big)
	      {
		big = temp;
		imax =ii;
	      }
	  }

	if( kk != imax )
	  {
	    for ( int jj =0; jj<n; jj++)
	      {
		temp = A(imax)(jj);

		A(imax)(jj)=A(kk)(jj);
		A(kk)(jj) = temp;
	      }

	    d = -d;
	    vv(imax)=vv(kk);
	  }

	indx(kk)=imax;

	if(fabs(A(kk)(kk)) < epsilon) A(kk)(kk) = epsilon;

	for(int ii=kk+1; ii<n; ii++)
	  {
	    temp = A(ii)(kk) /= A(kk)(kk);

	    for(int jj=kk+1;jj<n;jj++)
	      {
		A(ii)(jj) -= temp*A(kk)(jj);
	      }

	  }

      }



    return A;
  }



  template <class T, int n>
  Matrix<T, n, n> LU(Matrix<T, n, n> A, T &d)
  {
    Vector<int,n> indx;

    for(int i=0;i<n;i++) indx(i)=0;

    return LU(A,d,indx);
  }

  template <class T, int n>
  Matrix<T, n, n> LU(Matrix<T, n, n> A)
  {
    T d=1;
    return LU(A,d);
  }

  template <class T, int n>
  T det(Matrix<T, n, n>  const &A)
  {
    T d=1;
    Matrix<T,n,n> lu=LU(A,d);
    T dd = d;

    for (int ii=0;ii<n;ii++)
      {
	dd *= lu(ii)(ii);
      }

    return dd;
  }

  template <class T, int n>
  Vector<T,n> solve(Matrix<T, n, n>  const &A, Vector<T,n> const &b)
  {
    Vector<T,n> x;
    int ii=0;
    T sum;
    int ip;

    // Calculate the LU
    T d=1;
    Vector<int,n> indx;
    for(int ii=0;ii<n;ii++) indx(ii)=0;

    Matrix<T,n,n> lu = LU(A,d,indx);


    for(int i=0; i<n;i++)
      {
	x(i)=b(i);
      }

    for(int i=0;i<n;i++)
      {
	ip=indx(i);
	sum = x(ip);

	x(ip)=x(i);

	if(ii != 0)
	  {
	    for(int j=ii-1;j<i;j++)
	      {
		sum -= lu(i)(j)*x(j);
	      }
	  }
	else if( fabs(sum) > 0.0)
	  {
	    ii=i+1;
	  }
	x(i)=sum;

      }


    for(int i=n-1;i>=0;i--)
      {
	sum=x(i);

	for(int j=i+1;j<n;j++)
	  {
	    sum -= lu(i)(j)*x(j);
	  }

	x(i)=sum/lu(i)(i);
      }


    return x;
  }


  template <class T, int n,int m>
  Matrix<T,n,m> solve(Matrix<T, n, n>  const &A, Matrix<T,n,m> const &b)
  {
    Matrix<T,n,n> result;
    Vector<T,n> xx;

    for(int j=0;j<m;j++)
      {
	for(int i=0;i<n;i++)
	  {
	    xx(i) = b(i)(j);
	  }

	Vector<T,n> col=solve(A,xx);

	for(int i=0;i<n;i++)
	  {
	    result(i)(j)=col(i);
	  }
      }

    return result;
  }


  template <class T, int n>
  Matrix<T,n,n> inverse(Matrix<T, n, n>  const &A)
  {
    // Unitary matrix
    Matrix<T,n,n> I;

    for(int i=0;i<n;i++)
      {
	for(int j=0;j<n;j++)
	  {
	    if(i==j)
	      {
		I(i)(j)= 1;
	      }
	    else
	      {
		I(i)(j)= 0;
	      }
	  }
      }

    return solve(A,I);
  }


}


#endif
