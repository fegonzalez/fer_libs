#ifndef INDRA_BASE_PUBLISH_HEADER_
#define INDRA_BASE_PUBLISH_HEADER_

#include "inspector.h"
#include "model.h"

// see "publishtest.cpp" for an example of use

class BaseValueInspector;

struct PublishMessage
  : public Model::Message {
  PublishMessage(pointer_type(BaseValueMonitor) value_monitor)
    : value_monitor(value_monitor) { }
  pointer_type(BaseValueMonitor) const value_monitor;
};

#endif
