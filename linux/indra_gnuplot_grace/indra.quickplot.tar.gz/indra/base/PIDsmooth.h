#ifndef PIDSMOOTH_HEADER_
#define PIDSMOOTH_HEADER_

#include "mathfilter.h"

// The PIDSmooth class implements a feedback control system in which the 
// evolution of the reference is softened, and the feedback error is 
// controlled by a PID.
// It is not a filter exactly because the integration doesn't need one
// input but two (the reference and the measure). Only the time 
// step 'dt' is needed for the construction, but before using it the 
// coefficients must be given by means of 'set_coefficients()' (see below
// for the meaning of each of them) and must be initialized with 'initialise'.
//
// The reference is softened by, first, passing through a derivative limiter 
// (it is ramped), and then through a critical second order filter. The 
// error which is passed through the PID filter is just the measure minus 
// the _smooth_ reference.
//
// The 'set_coefficients()' parameters are 'max_der_reference', which is the
// limit of the derivative of the reference (its absolute value is limited),
// 'critical_time', which is the characteristic time of the critical second
// order filter, and 'k', 't_f' and 't_D' which are the PID filter parameters.
//
// It's necessary to give the measure, the reference, and the PID filter
// output (which is named 'control') for the initialization. For integrating
// the control system, the current measure and reference are passed to the
// 'control()' method, and the method returns the value of the control variable
// (that is, the PID filter output).
//
// There is a group of 'accesors' for watching the values of the internal
// parameters of the control system:
// * 'get_last_measure()' returns the last value given to the parameter
//     'measure' of the 'control()' method
// * 'get_last_reference()' idem with the 'reference' parameter
// * 'get_last_control()' returns the last value returned by the 'control()' 
//     method
// * 'get_ramped_reference' returns the last value of the reference after 
//     passing through the derivative limitation (without having been passed
//     to the critical filter)
// * 'get_smooth_reference()' returns the last value of the reference
//     after passing through the derivative limitation and the critical filter.
//
// In order to syntonize the control system it's convenient to, first, adjust 
// the PID without softening the reference, until obtaining an optimum answer
// regarding the time for controlling a perturbation and then to set
// appropriate values for 'max_der_reference' and 'critical_time' for what
// the pilot expects. For adjusting the PID the 'set_smoothing()'method with
// 'false' argument can be invoked, that inhibits the reference softening;
// in order to return to the normal behaviour with reference softening 
// 'set_smoothing()' is invoked with 'true' argument.

class PIDSmooth {
public:
  PIDSmooth(scalar dt);
  void set_coefficients(scalar _max_der_reference, scalar critical_time,
			scalar k, scalar t_I, scalar t_D);
  void set_smoothing(bool _smoothing);
  void initialise(scalar measure, scalar reference, scalar control);
  scalar control(scalar measure, scalar reference);
  scalar get_last_measure() const { return last_measure; }
  scalar get_last_reference() const { return last_reference; }
  scalar get_ramped_reference() const { return ramped_reference; }
  scalar get_smooth_reference() const { return smooth_reference; }
  scalar get_last_control() const { return last_control; }
private:
  scalar const Dt;
  scalar max_der_reference;
  scalar last_measure;
  scalar last_reference, ramped_reference, smooth_reference;
  scalar last_control;
  bool smoothing;
  Tustin02 critical_filter;
  MMPZ_PID PID_filter;
};

#endif
