
#include "base.h"
//#include "Hkcon.h"
#include <cmath>
#include <cfloat>
#include <iostream>



unchecked_scalar simTime=0.;
// scalar const dt=1./50.;
integer tick=0;
// Change for <limits>
unchecked_scalar const sqrt_epsilon=sqrt(DBL_EPSILON);

void new_step()
{
   tick++;
}

scalar sin_over(scalar x)
{
   if (x<sqrt_epsilon && x>-sqrt_epsilon)
     return 1.-x*x/6.;
   else
     return sin(x)/x;
}

extern scalar round_to_1_decimal(scalar x)
{
  int numI;
  double aux;
 
  numI = (int)x;
 
  aux = (x - numI);
 
  if (aux <= 0.5)
    return ((double)numI);
  else
    return ((double)numI+1);

}


extern scalar round_to_the_n_decimal(scalar x, int n) 
{
  scalar const n_pow = pow(10.0,n);  
  return round_to_1_decimal(x*n_pow)/n_pow;
}
