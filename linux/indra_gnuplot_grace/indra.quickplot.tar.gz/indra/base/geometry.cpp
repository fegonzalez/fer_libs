#include "geometry.h"
#include <cmath>
using std::istream;
using std::ostream;

std::ostream &operator<<(std::ostream &os, psithetaphi ptp) {
  return os << ptp.psi << " " << ptp.theta << " " << ptp.phi;
}

std::ostream &operator<<(std::ostream &os, psitheta pt) {
  return os << pt.psi << " " << pt.theta;
}

std::ostream &operator<<(std::ostream &os, thetaphi tp) {
  return os << tp.theta << " " << tp.phi;
}

std::ostream &operator<<(std::ostream &os, alphabeta ab) {
  return os << ab.alpha << " " << ab.beta;
}

std::ostream &operator<<(std::ostream &os, axis_angle aa) {
  return os << aa.axis << "; " << aa.angle;
}


/* Vector ********************************************************************/

ostream &operator<<(ostream &os, Vector a)
{
   return os << a.x() << " " << a.y() << " " << a.z();
}

istream &operator>>(istream &is, Vector &a)
{
   scalar x, y, z;
   is >> x >> y >> z;
   a=Vector(x, y, z);
   return is;
}

/* Matrix ********************************************************************/

ostream &operator<<(ostream &os, Matrix a)
{
   return os << a.x() << " " << a.y() << " " << a.z();
}

istream &operator>>(istream &is, Matrix &a)
{
  Vector x, y, z;
  is >> x >> y >> z;
  a=Matrix(x,y,z);
  return is;
}

/* Quaternion ****************************************************************/

ostream &operator<<(ostream &os, Quaternion a)
{
   return os << a.q0() << " " << a.q1() << " "
                     << a.q2() << " " << a.q3();
}

istream &operator>>(istream &is, Quaternion &a)
{
   scalar q0, q1, q2, q3;
   is >> q0 >> q1 >> q2 >> q3;
   a=Quaternion(q0, q1, q2, q3);
   return is;
}

scalar Quaternion::get_psi(void) const
{
    scalar psi ;
    psi=arcsincos(2.*(_q1*_q2+_q0*_q3),
                  _q0*_q0+_q1*_q1-_q2*_q2-_q3*_q3);
    return psi;
}

scalar Quaternion::get_theta(void) const
{
    scalar theta=arcsin(2.*(_q0*_q2-_q1*_q3));
    return theta;
}

scalar Quaternion::get_phi(void) const
{
    scalar phi, theta, psi;
    theta=arcsin(2.*(_q0*_q2-_q1*_q3));
    psi=arcsincos(2.*(_q1*_q2+_q0*_q3),
                  _q0*_q0+_q1*_q1-_q2*_q2-_q3*_q3);
    scalar L22=_q0*_q0-_q1*_q1+_q2*_q2-_q3*_q3;
    scalar L13=2.*(_q1*_q3+_q0*_q2);
    if (theta<=0.)
        phi=-psi+arcsincos(2.*(_q0-_q2)*(_q3+_q1), L22-L13);
    else
        phi=+psi-arcsincos(2.*(_q0+_q2)*(_q3-_q1), L22+L13);
    if (phi>PI)
        phi-=2*PI;
    else if (phi<-PI)
        phi+=2*PI;
    return phi;
}
