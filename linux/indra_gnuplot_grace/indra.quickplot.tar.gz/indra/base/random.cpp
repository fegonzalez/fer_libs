#include "random.h"
#include "base.h"
#include <limits>
#include <cmath>

namespace {
  unsigned short int const a0=0xE66D;
  unsigned short int const a1=0xDEEC;
  unsigned short int const a2=0x0005;

  unsigned short int const c0=0x000B;
}

Rand48::Rand48(unsigned long int s) {
  set_seed(s);
}

Rand48::Rand48(State init_state)
  : state(init_state) {
}

void Rand48::advance() {
  unsigned long int const x0=(unsigned long int)(state.x0);
  unsigned long int const x1=(unsigned long int)(state.x1);
  unsigned long int const x2=(unsigned long int)(state.x2);

  unsigned long int a=a0*x0+c0;
  state.x0=(short unsigned int)(a&0xFFFF);

  a>>=16 ;

  /* although the next line may overflow we only need the top 16 bits
     in the following stage, so it does not matter */
  a+=a0*x1+a1*x0;
  state.x1=(short unsigned int)(a&0xFFFF);

  a>>=16;
  a+=a0*x2+a1*x1+a2*x0;
  state.x2=(short unsigned int)(a&0xFFFF);
}

void Rand48::set_seed(unsigned long int s) {
  if (s==0) {
    state.x0=0x330E;
    state.x1=0xABCD;
    state.x2=0x1234;
  }
  else {
    state.x0=0x330E;
    state.x1=(short unsigned int)(s&0xFFFF);
    state.x2=(short unsigned int)((s>>16)&0xFFFF);
  }
}

Rand48::State Rand48::get_state() const {
  return state;
}

void Rand48::set_state(State new_state) {
  state=new_state;
}

unsigned long int Rand48::get_unsigned_long_int() {
  advance();

  unsigned long int x2=(unsigned long int)(state.x2);
  unsigned long int x1=(unsigned long int)(state.x1);

  return (x2 << 16) + x1;
}

scalar Rand48::get_scalar_0_1() {
  advance();

  return (ldexp(scalar(state.x2), -16)
	  +ldexp(scalar(state.x1), -32)
	  +ldexp(scalar(state.x0), -48));
}

scalar Rand48::get_scalar(scalar y0, scalar y1) {
  return get_scalar_0_1()*(y1-y0)+y0;
}

scalar Rand48::get_scalar_normal_0_mean_1_standard_deviation() {
  // Box-Muller algorithm (see
  // http://en.wikipedia.org/wiki/Box-Muller_transform)

  // the argument to log() is limited to min() just in case in order to avoid
  // an arithmetic error computing the logarithm of zero; last time I checked,
  // it was OK to have min() for double, and it gave a maximum result of
  // 37.6403; we use 1.-get_scalar_0_1() instead of get_scalar_0_1() in order
  // to match the range expected by the algorithm (0 not included, 1 included)

  // we only generate one random number instead of the two that the algorithm
  // can deliver; this is done for simplicity, at the cost of execution
  // efficiency
  return
    sqrt(-2.*log(maximum(1.-get_scalar_0_1(),
                         std::numeric_limits<scalar>::min())))
    *cos(2*PI*get_scalar_0_1());
}

scalar Rand48::get_scalar_normal(scalar mean, scalar standard_deviation) {
  return
    mean+standard_deviation*get_scalar_normal_0_mean_1_standard_deviation();
}
