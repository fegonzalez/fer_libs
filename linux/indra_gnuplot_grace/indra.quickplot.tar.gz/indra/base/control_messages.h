

#if !defined(_CONTROLMESSAGES_)
#define _CONTROLMESSAGES_
using namespace std;

namespace ControlMessages{

template <typename DataStruct>
class MessageControl
{
public:

  MessageControl(float _limit=2.0 , float _dt=.0):
    counter(0),status(0),message(0),timeOutLimit(_limit),TOcounter(0.0),DT(_dt),TIMEOUT(false),data() {};

  ~MessageControl(){};

  void connection(MessageControl const* external_message)
  {
      message=external_message;      
  }; 
  
  void write()
  {
     counter = (counter +1)%200000;
  };     

  bool read()
  {
    if(message==0)
     {
        return false;
     }
     
    if(message->counter != counter)
    {
               // copy data
               counter=message->counter;
               return true;
    }
    else
    {
          return false;
    }
           
  };


  bool get_message()
  {
      if(read())
      {
         TIMEOUT=false;
         TOcounter=.0;

         data=message->data;
         return true;
      }
      else
      {
         TOcounter+=DT;
         if (TOcounter>timeOutLimit) TIMEOUT=true;

         return false;    
      }
  };
  





private:

  unsigned int counter;
  bool status;
  MessageControl const* message;
  float timeOutLimit;
  float TOcounter;
  float DT;

public:
  bool TIMEOUT;
  DataStruct data;
};

};

#endif // !defined(_CONTROLMESSAGES_)
