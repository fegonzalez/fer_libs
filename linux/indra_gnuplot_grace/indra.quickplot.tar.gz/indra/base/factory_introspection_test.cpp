
#include <iostream>
#include <string>

#include "introspection.h"
#include "factory.h"
#include "string_cast.h"
#include "readval.h"

#include <fstream>
#include <cassert>

using namespace std;
using namespace HierarchyIntrospection;

namespace {

  class DictionaryContainer;

  class BasicComponent
  {
  public:

    BasicComponent(DictionaryContainer const* dic):dictionary(dic){}

    virtual ~BasicComponent(){}
    virtual double result() const=0;


    DictionaryContainer const* dictionary;

  };


  typedef std::map<std::string, pointer_type(BasicComponent const)> Map;
  class DictionaryContainer
  {
  public:

    DictionaryContainer(){};
    Map element;
    std::map<std::string, double> variable; // FIXME: this map can be out of the class

  };



  class ArgumentFactory
  {
  public:

    ArgumentFactory(DictionaryContainer const *dictionary,
		    std::map<std::string, double> *variable,
		    std::string name,std::string arguments)
      :dictionary(dictionary),
       variable(variable),
       name(name),arguments(arguments){}


    DictionaryContainer const *dictionary;
    std::map<std::string, double> *variable;
    std::string name;
    std::string arguments;

  };


  class TestFactory:
    public BaseFactory::Factory<BasicComponent,ArgumentFactory >
  {
  public:

    static TestFactory* concrete(std::string name)
    { return Dictionary<TestFactory>::singleton().get(name);}

  };


  class Source:
    public BasicComponent
  {
  public:

    Source(DictionaryContainer const* dic,
	   double const value):BasicComponent(dic),
			       value(value){};

    double result() const { return value;}

  private:

    double value;

  };



  class Adder
    : public BasicComponent
  {
  public:

    Adder(DictionaryContainer const* dic,
	  std::string x,std::string y):BasicComponent(dic),
				       x(x),y(y){};

    double result() const
    {
      Map::const_iterator scan1 = dictionary->element.find(x.c_str());
      Map::const_iterator scan2 = dictionary->element.find(y.c_str());

      assert(scan1 != dictionary->element.end() );
      assert(scan2 != dictionary->element.end() );

      return scan1->second->result() + scan2->second->result();

    }

  private:

    std::string x;
    std::string y;

  };


  class Variable
    : public BasicComponent
  {
  public:

    Variable(DictionaryContainer const* dic,
	     std::map<std::string, double> *var_dic_non_const,
	     std::string name,double const init_value):
      BasicComponent(dic),var_dic(var_dic_non_const),
      name(name),init_value(init_value)
    {
      (*var_dic_non_const)[name]=init_value;
      //var_dic->insert(var_dic->end(),name);
    }


    double result() const
    {
      std::map<std::string,double>::const_iterator scan =
	dictionary->variable.find(name.c_str());
      assert(scan != dictionary->variable.end() );

      return scan->second;
    }

  private:

    std::map<std::string, double> const *var_dic;
    std::string const name;
    double const init_value;
  };


  class SourceFactory: public TestFactory
    {
    public:

      pointer_type(BasicComponent) create_new(ArgumentFactory const &args) const
      {
	double val;
	istringstream iss(args.arguments);
	iss >> val;

	return new_pointer(Source(args.dictionary,val));
      }
      static bool declared;
    };

  bool SourceFactory::declared = Dictionary<TestFactory>::singleton().
  declare("source",new SourceFactory);



  class AdderFactory: public TestFactory
  {
  public:

    pointer_type(BasicComponent) create_new(ArgumentFactory const &args) const
    {
      std::string x,y;
      istringstream iss(args.arguments);
      iss >> x >> y;

      return new_pointer(Adder(args.dictionary,x,y));
    }

    static bool declared;
  };

  bool AdderFactory::declared = Dictionary<TestFactory>::singleton().
  declare("adder",new AdderFactory);


  class VariableFactory: public TestFactory
  {
  public:

    pointer_type(BasicComponent) create_new(ArgumentFactory const &args) const
    {
      double init_value;
      istringstream iss(args.arguments);
      iss >> init_value;

      return new_pointer(Variable(args.dictionary,
                                  args.variable,
                                  args.name,init_value));
    }

    static bool declared;

  };

  bool VariableFactory::declared = Dictionary<TestFactory>::singleton().
  declare("variable",new VariableFactory);



}



void  introspection_factory_test()
{

  cout<<"\n========================================================"<<endl;
  cout<<"=======           INTROSPECTION TEST FACTORIES    ======"<<endl;
  cout<<"========================================================"<<endl;


  std::string const file = "factory_components_test.txt";

  std::ifstream in(file.c_str());

  DictionaryContainer dictionary_container;

  while(in)
    {
      std::string line_string;
      getline(in,line_string);

      std::string::size_type line_begin=
	line_string.find_first_not_of(" \t");

      if ((line_begin==std::string::npos) or (line_string[line_begin]=='#'))
	continue;


      istringstream iss(line_string);
      std::string factory, name, arguments;
      iss >> factory >> name;
      getline(iss,arguments);


      dictionary_container.element[name]=TestFactory::concrete(factory)
	->create_new(ArgumentFactory(&dictionary_container,
				     &dictionary_container.variable,
				     name, arguments));

    }


  cout<< "Elements: " ;
  for(Map::const_iterator scan=dictionary_container.element.begin();
      scan!=dictionary_container.element.end();scan++)
    {
      cout << scan->first << " ";
    }
  cout << endl;


  cout<< "Elements result: " << endl;
  for(Map::iterator scan=dictionary_container.element.begin();
      scan!=dictionary_container.element.end();scan++)
    {
      cout << scan->first << " "<< scan->second->result() << endl;
    }
  cout << endl;


  cout << "Modified the variable: " << endl;
  dictionary_container.variable["x"] = 1.0;
  dictionary_container.variable["y"] = 10.0;
  dictionary_container.variable["z"] = -3.0;

  cout<< "Elements result: " << endl;
  for(Map::iterator scan=dictionary_container.element.begin();
      scan!=dictionary_container.element.end();scan++)
    {
      cout << scan->first << " "<< scan->second->result() << endl;
    }
  cout << endl;




  cout<<"\n========================================================"<<endl;
  cout<<"=======           FINISH TEST                     ======"<<endl;
  cout<<"========================================================"<<endl;

}




int main() {

  introspection_factory_test();


  cout<<"End of program "<< endl;
}
