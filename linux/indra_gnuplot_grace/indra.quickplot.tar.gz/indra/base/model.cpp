#include "model.h"

void Model::run() {
  run_but_do_not_show_state();
  show_state_after_having_computed_it();
}

void Model::initialise() {
  pre_initialise_model();
  for (iterator scan=begin(), scan_end=end();
       scan!=scan_end;
       ++scan)
    (*scan)->initialise();

  initialise_model();
}

scalar Model::get_t() const {
  return get_owner_node()->get_t();
}

scalar Model::get_dt() const {
  return get_owner_node()->get_dt();
}


void Model::run_but_do_not_show_state() {
  pre_model();

  for (iterator scan=begin(), scan_end=end();
       scan!=scan_end;
       ++scan)
    (*scan)->run_but_do_not_show_state();

  model();
}

void Model::show_state_after_having_computed_it() {
  for (iterator scan=begin(), scan_end=end();
       scan!=scan_end;
       ++scan)
    (*scan)->show_state_after_having_computed_it();

  show_state();
}

void Model::pass_message(Message const &message) {
  for (iterator scan=begin(), scan_end=end();
       scan!=scan_end;
       ++scan)
    (*scan)->pass_message(message);

  accept_message(message);
}
