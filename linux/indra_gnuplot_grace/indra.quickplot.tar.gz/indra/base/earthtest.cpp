#include "earth.h"
#include "base.h"
#include <iostream>
#include <iomanip>

using std::cout;
using std::endl;
using std::setprecision;
using std::fixed;

void check(lat_lon_alt lla1)
{
   cout << "lla1 = " << lla1 << endl;
   Vector ine2=WGS84.earth_to_inertial(lla1);
   cout << "ine2 = " << ine2 << endl;
   lat_lon_alt lla3=WGS84.inertial_to_earth(ine2);
   cout << "lla3 = " << lla3 << endl;
   Vector ine4=WGS84.earth_to_inertial(lla3);
   cout << "ine4 = " << ine4 << endl;
   cout << endl;
}


int main()
{
   cout << fixed << setprecision(3);
   check(lat_lon_alt(0, 0, 0));
   check(lat_lon_alt(90, 45, 120));
   check(lat_lon_alt(-40, 180, -200));
   check(lat_lon_alt(-60, -179, 2500));
   check(lat_lon_alt(-90, -145, 12000));

   lat_lon_alt l_l_a(-10, 120, 400);
   Quaternion r_h_l=ref_local_horizon(l_l_a);
   cout << "local horizon in " << l_l_a << " : " << endl
        << "    " << r_h_l << endl;
   scalar psi, theta, phi;
   r_h_l.getpsithetaphi(psi, theta, phi);
   cout << "psi = " << rad_to_deg(psi) << endl;
   cout << "theta = " << rad_to_deg(theta) << endl;
   cout << "phi = " << rad_to_deg(phi) << endl;
}
