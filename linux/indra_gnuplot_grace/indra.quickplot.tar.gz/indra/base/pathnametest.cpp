#include "pathname.h"
#include <iostream>

using std::endl;
using std::cout;

int main() {
  cout << "default policy:" << endl;
  cout << "  global_pathname(\"pathname.cpp\"): "
       << "\"" << global_pathname("pathname.cpp")
       << "\"" << endl;
  cout << "  global_pathname(\"pathname.xxx\"): ";
  try {
    global_pathname("pathname.xxx");
  }
  catch (...) {
    cout << "fails" << endl;
  }

  PathNamePolicy::global()=
    std::auto_ptr<PathNamePolicy>(new IdentityPathNamePolicy);
  cout << "identity policy:" << endl;
  cout << "  global_pathname(\"pathname.cpp\"): "
       << "\"" << global_pathname("pathname.cpp")
       << "\"" << endl;
  cout << "  global_pathname(\"pathname.xxx\"): ";
  try {
    global_pathname("pathname.xxx");
  }
  catch (...) {
    cout << "fails" << endl;
  }
  cout << "  global_pathname(\"/etc//hosts\"): "
       << "\"" << global_pathname("/etc//hosts")
       << "\"" << endl;

  PathNamePolicy::global()=
    std::auto_ptr<PathNamePolicy>(new PrefixPathNamePolicy("/etc"));
  cout << "prefix policy (prefix \"/etc\"):" << endl;
  cout << "  global_pathname(\"hosts\"): "
       << "\"" << global_pathname("hosts")
       << "\"" << endl;
  cout << "  global_pathname(\"pathname.cpp\"): ";
  try {
    global_pathname("pathname.cpp");
  }
  catch (...) {
    cout << "fails" << endl;
  }

  std::list<std::string> prefix_list;
  prefix_list.push_back("/etc");
  prefix_list.push_back(".");
  prefix_list.push_back("/nowhere");
  prefix_list.push_back("../base");
  PathNamePolicy::global()=
    std::auto_ptr<PathNamePolicy>(
      new AlternativePrefixPathNamePolicy(prefix_list));
  cout << "alternative policy "
          "(alternatives \"/etc\", \".\", \"/nowhere\", \"../base\"):" << endl;
  cout << "  global_pathname(\"pathname.cpp\"): "
       << "\"" << global_pathname("pathname.cpp")
       << "\"" << endl;
  cout << "  global_pathname(\"pathname.h\"): "
       << "\"" << global_pathname("pathname.h")
       << "\"" << endl;
  cout << "  global_pathname(\"../base/pathname.h\"): "
       << "\"" << global_pathname("../base/pathname.h")
       << "\"" << endl;
  cout << "  global_pathname(\"../base/nothing.xxx\"): ";
  try {
    global_pathname("../base/nothing.xxx");
  }
  catch (...) {
    cout << "fails" << endl;
  }
  cout << "  global_pathname(\"hosts\"): "
       << "\"" << global_pathname("hosts")
       << "\"" << endl;
}
