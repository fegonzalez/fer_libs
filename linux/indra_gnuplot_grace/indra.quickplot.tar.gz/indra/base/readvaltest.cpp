#include "readval.h"
#include "geometry.h"
#include <iostream>

using namespace std;

int main() {
  ReadValues readval("readvaltest.txt");

  cout << "foo: " << readval.value<scalar>("foo") << endl;
  cout << "bar: " << readval.value<Vector>("bar") << endl;
  cout << "2*foo: " << 2*readval.value<scalar>("foo") << endl;
  cout << "2*bar: " << 2*readval.value<Vector>("bar") << endl;

  cout << "trying to read nonexisting value \"not_there\"..." << endl;
  try {
    readval.value<scalar>("not_there");
  }
  catch (std::runtime_error const &error) {
    cout << "  catched exception: " << error.what() << endl;
  }
}
