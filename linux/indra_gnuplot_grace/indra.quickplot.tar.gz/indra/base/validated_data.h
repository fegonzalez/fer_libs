#ifndef _VALIDATED_DATA_H_
#define _VALIDATED_DATA_H_
#include <iostream>
#include <string>
#include "scalar.h"

namespace {
enum validation_cases { ISVALID, NOVALID, OTHER };
}

template <typename T>
struct validated_data 
{
public:
  validated_data(){};
  validated_data(T const &t, validation_cases validation): data(t), is_valid(validation) {}
  T data ;
  validation_cases is_valid ;
private:
template<typename U>
friend std::ostream &operator<< (std::ostream &os, validated_data<U> a);
template<typename V>
friend std::istream &operator>> (std::istream &is, validated_data<V> &a);
};

template <typename U>
std::ostream& operator<<(std::ostream &os,  validated_data<U> a)
{
 std::string cases;
 if (a.is_valid==ISVALID) cases="ISVALID";
 else if  (a.is_valid==NOVALID) cases="NOVALID";
 else if  (a.is_valid==OTHER) cases="OTHER";

   return os << a.data <<";"
             << cases ;
}
template<typename V>
std::istream &operator>>(std::istream &is, validated_data<V>&a)
{
   V data;
   validation_cases is_valid=NOVALID;
   std::string valid;

   is >> data >> valid ;
   if (valid=="ISVALID") is_valid=ISVALID;
   else if (valid=="NOVALID") is_valid=NOVALID;
   else if (valid=="OTHER") is_valid=OTHER;

   a=validated_data<V>(data,is_valid);
   return is;
}





#endif //_VALIDATED_DATA_H_
