#include "edge_detectors.h"
#include <iostream>
#include <cstdlib>

using namespace std;

// Global variables
bool signal = false;
bool malfunction = false;
int step = 0;


void initializeGlobalVariables(void)
{
  signal = false;
  malfunction = false;
  step = 0;
}


void printState(bool state, bool edge_detected)
{
  cout << "Malfunciton state: "<< malfunction << endl;
  cout << "Signal state: " << signal << endl;
  cout << "State: " << state << endl;
  cout << "Edge Detected: " << edge_detected  << endl << endl;

}


void Step(bool valueInputSignal, Edge_Detector *detector, bool expected_state, bool expected_edge_detector)
{
  step ++;

  signal = valueInputSignal;
  detector->run();

  bool state = detector->State();
  bool edge_detected = detector->EdgeDetected();



  if (state != expected_state)
    {
      cout << "Step : "<< step << endl;
      cout << "-----  " << endl;
      printState(state, edge_detected);
      cout << " State ERROR!! " << endl;
      exit (-1);
    }

  if (edge_detected != expected_edge_detector)
    {
      cout << "Step : "<< step << endl;
      cout << "-----  " << endl;
      printState(state, edge_detected);
      cout << " Edge Detection ERROR!! " << endl;
      exit (-1);
    }
}



// Test Group rising edge
//-------------------------
void  TC_RisingNoMalfucntion(void)
{
  initializeGlobalVariables();


  // With malfunction
  cout << "Rising Edge  WITHOUT MALFUNCTION  Test:  " << endl;;
  cout << "----------------------------------------" << endl;

  Rising_Edge_Detector *rising = new Rising_Edge_Detector(&signal);

  // Step 1
  Step (false, rising, false, false);
  // Step 2
  Step (true, rising, true, true);
  // Step 3
  Step (true, rising, true, false);
  // Step 4
  Step (true, rising, true, false);
  // Step 5
  Step (false, rising, true, false);
  // Step 6
  Step (false, rising, true, false);
  // Step 7
  Step (false, rising, true, false);
  // Step 8
  Step (true, rising, false, true);
  // Step 9
  Step (true, rising, false, false);
  // Step 10
  Step (false, rising, false, false);

  // The malfunction is activated. It shouldn't to affect.
  malfunction = true;
  // cout << "The malfunction is activated:       ";
  //  cout << "---------------------------- " << endl;

  // Step 11
  Step (false, rising, false, false);
  // Step 12
  Step (true, rising, true, true);
  // Step 13
  Step (true, rising, true, false);
  // Step 14
  Step (true, rising, true, false);
  // Step 15
  Step (false, rising, true, false);
  // Step 16
  Step (false, rising, true, false);
  // Step 17
  Step (false, rising, true, false);
  // Step 18
  Step (true, rising, false, true);
  // Step 19
  Step (true, rising, false, false);
  // Step 20
  Step (false, rising, false, false);

  cout << "Test OK!!" << endl << endl;

  delete rising;


}


void TC_RisingWithMalfucntion(void)
{
  initializeGlobalVariables();

  // With malfunction
  cout << "Rising Edge  WITH MALFUNCTION  Test" << endl;
  cout << "-----------------------------------------" << endl;

  Rising_Edge_Detector *rising = new Rising_Edge_Detector(&signal, &malfunction);

  // Step 1
  Step (false, rising, false, false);
  // Step 2
  Step (true, rising, true, true);
  // Step 3
  Step (true, rising, true, false);
  // Step 4
  Step (true, rising, true, false);
  // Step 5
  Step (false, rising, true, false);
  // Step 6
  Step (false, rising, true, false);
  // Step 7
  Step (false, rising, true, false);
  // Step 8
  Step (true, rising, false, true);
  // Step 9
  Step (true, rising, false, false);
  // Step 10
  Step (false, rising, false, false);



  // The malfunction is activated. It should to affect.
  malfunction = true;

  // Step 11
  Step (false, rising, false, false);
  // Step 12
  Step (true, rising, false, false);
  // Step 13
  Step (true, rising, false, false);
  // Step 14
  Step (true, rising, false, false);
  // Step 15
  Step (false, rising, false, false);
  // Step 16
  Step (false, rising, false, false);
  // Step 17
  Step (false, rising, false, false);
  // Step 18
  Step (true, rising, false, false);
  // Step 19
  Step (true, rising, false, false);
  // Step 20
  Step (false, rising, false, false);

  cout << "Test OK!!" << endl << endl;

  delete rising;
}

void TG_RisingEdge(void)
{

  TC_RisingNoMalfucntion();
  TC_RisingWithMalfucntion();

}


// Test Group falling edge
//-------------------------

void  TC_FallingNoMalfucntion(void)
{
  initializeGlobalVariables();

  // With malfunction
  cout << "Falling Edge  WITHOUT MALFUNCTION  Test" << endl;
  cout << "--------------------------------------------" << endl;

  Falling_Edge_Detector *falling = new Falling_Edge_Detector(&signal);

  // Step 1
  Step (false, falling, false, false);
  // Step 2
  Step (true, falling, false, false);
  // Step 3
  Step (true, falling, false, false);
  // Step 4
  Step (true, falling, false, false);
  // Step 5
  Step (false, falling, true, true);
  // Step 6
  Step (false, falling, true, false);
  // Step 7
  Step (false, falling, true, false);
  // Step 8
  Step (true, falling, true, false);
  // Step 9
  Step (true, falling, true, false);
  // Step 10
  Step (false, falling, false, true);



  // The malfunction is activated. It shouldn't to affect.
  malfunction = true;


  // Step 11
  Step (false, falling, false, false);
  // Step 12
  Step (true, falling, false, false);
  // Step 13
  Step (true, falling, false, false);
  // Step 14
  Step (true, falling, false, false);
  // Step 15
  Step (false, falling, true, true);
  // Step 16
  Step (false, falling, true, false);
  // Step 17
  Step (false, falling, true, false);
  // Step 18
  Step (true, falling, true, false);
  // Step 19
  Step (true, falling, true, false);
  // Step 20
  Step (false, falling, false, true);

  cout << "Test OK!!" << endl << endl;

  delete falling;
}


void TC_FallingWithMalfucntion(void)
{
  initializeGlobalVariables();

  // With malfunction
  cout << "Falling Edge  WITH MALFUNCTION  Test" << endl;
  cout << "-----------------------------------------" << endl;

  Falling_Edge_Detector *falling = new Falling_Edge_Detector(&signal, &malfunction);

  // Step 1
  Step (false, falling, false, false);
  // Step 2
  Step (true, falling, false, false);
  // Step 3
  Step (true, falling, false, false);
  // Step 4
  Step (true, falling, false, false);
  // Step 5
  Step (false, falling, true, true);
  // Step 6
  Step (false, falling, true, false);
  // Step 7
  Step (false, falling, true, false);
  // Step 8
  Step (true, falling, true, false);
  // Step 9
  Step (true, falling, true, false);
  // Step 10
  Step (false, falling, false, true);

  // The malfunction is activated. It should to affect.
  malfunction = true;

  // Step 11
  Step (false, falling, false, false);
  // Step 12
  Step (true, falling, false, false);
  // Step 13
  Step (true, falling, false, false);
  // Step 14
  Step (true, falling, false, false);
  // Step 15
  Step (false, falling, false, false);
  // Step 16
  Step (false, falling, false, false);
  // Step 17
  Step (false, falling, false, false);
  // Step 18
  Step (true, falling, false, false);
  // Step 19
  Step (true, falling, false, false);
  // Step 20
  Step (false, falling, false, false);

  cout << "Test OK!!" << endl << endl;


  delete falling;



}

void TG_FallingEdge(void)
{
  TC_FallingNoMalfucntion();
  TC_FallingWithMalfucntion();
}


int main (void)
{
  TG_RisingEdge();
  TG_FallingEdge();

  return (0);


}
