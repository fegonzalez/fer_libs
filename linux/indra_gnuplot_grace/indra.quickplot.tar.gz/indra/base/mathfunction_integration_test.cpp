#include "../base/base.h"
#include "../base/mathfunction_integration.h"
#include "../base/functor.h"
#include <iostream>

int main() {

 class SineFunction : public Functor_1<scalar> {
 scalar operator()(const scalar &x) const {
   return sin(x);
  }
 private :
 } sine_function;

 TrapeziumIntegral trapezium(0.,M_PI/2.,1000,&sine_function);
 SimpsonIntegral simpson(0.,M_PI/2.,100,&sine_function);

 std::cout.precision(2);

 std::cout  << std::fixed <<"Trapezium method , integral_sine [0,PI/2] = " << trapezium.integrate() << std::endl;
 std::cout  << std::fixed <<"Simpson method , integral_sine [0,PI/2] = " << simpson.integrate() << std::endl;

 std::cout  << std::fixed <<"Trapezium method , integral_sine [0,PI] = " << trapezium.integrate(0.,M_PI) << std::endl;
 std::cout  << std::fixed <<"Simpson method , integral_sine [0,PI] = " << simpson.integrate(0.,M_PI) << std::endl;

 std::cout  << std::fixed <<"Trapezium method , integral_sine [0,3*PI/2] = " << trapezium.integrate(0.,3*M_PI/2) << std::endl;
 std::cout  << std::fixed <<"Simpson method , integral_sine [0,3*PI/2] = " << simpson.integrate(0.,3*M_PI/2) << std::endl;

return 0;

}
