#ifndef INDRA_BASE_POINTER_POLICY_HEADER_
#define INDRA_BASE_POINTER_POLICY_HEADER_

// do not uncomment the next file; use rather a compiler option (see below)
// #define USE_SHARED_POINTERS_WHEN_AVAILABLE

/*
 * This file provides for a smooth transition from the usage of naked pointers
 * (regular C++ pointers, such as "Foo *foo_object") with no established
 * ownership semantics (i.e., it is never clear if an allocated object is owned
 * by the creator or by the user) to the usage of shared pointers (such as
 * "shared_ptr<Foo> foo_object"), where the ownership semantics is implicit,
 * and the life of allocated objects is controlled automatically, resulting in
 * clearer code, no explicit deallocation, and fewer errors related to memory
 * management.
 *
 * The naked-or-shared policy is controlled by the preprocessor variable
 * "USE_SHARED_POINTERS_WHEN_AVAILABLE" (see the commented-out definition
 * above).  When this variable is undefined, the naked pointer policy is in
 * place, which translates all "pointer_type" specifications and expressions to
 * naked pointer specifications and expressions.  When the variable is defined,
 * "pointer_type" specifications and expressions are translated to shared
 * pointer specifications and expressions in terms of "shared_ptr" (see
 * "shared_ptr.h").  The intended way to set the variable is not by modifying
 * this file, but by passing the variable definition to the compiler as an
 * option ("-DUSE_SHARED_POINTERS_WHEN_AVAILABLE" for "gcc").  By default,
 * until a good coverage and a consensus have been reached, the default policy
 * should be naked-pointer.
 *
 * In order to update a naked pointer to a shared pointer without breaking old
 * code, do the following:
 *
 *     * replace the naked pointer declaration or argument specification with a
 *       "pointer_type()" specification, using the following models:
 *
 *           "Foo *foo_object;"
 *               becomes "pointer_type(Foo) foo_object;"
 *
 *           "Foo const *foo_object;"
 *               becomes "pointer_type(Foo const) foo_object;"
 *
 *           "Foo *const foo_object;"
 *               becomes "pointer_type(Foo) const foo_object;"
 *
 *           "Foo const *const foo_object;"
 *               becomes "pointer_type(Foo const) const foo_object;"
 *
 *     * replace object allocation with a "new_pointer()" expression, using the
 *       following model:
 *
 *           "new Foo(arg1, arg2)"
 *               becomes "new_pointer(Foo(arg1, arg2))"
 *
 *     * replace existing explicit deallocation, if any, with a
 *       "release_pointer()" expression or with a "release_and_reset_pointer"
 *       expression, using the following models:
 *
 *           "delete foo_object;"
 *               becomes "release_pointer(foo_object);"
 *
 *           "delete foo_object; foo_object=0;"
 *               becomes "release_and_reset_pointer(foo_object);"
 *
 *       (note: with the naked-pointer policy, "release_pointer(foo_object)"
 *       zeroizes the pointer if the pointer is non-const);
 *
 *     * replace pointer zeroing with a "reset_pointer()" expression, using the
 *       following model:
 *
 *           "foo_object=0;" "foo_object=NULL;"
 *               becomes "reset_pointer(foo_object)"
 *
 *     * replace tests for pointer nonnullness with an "is_nonnull()"
 *       expression, using the following model:
 *
 *           "if (foo_object) { ... }"
 *               becomes "if (is_nonnull(foo_object)) { ... }"
 *
 *           "if (foo_object!=0) { ... }"
 *               becomes "if (is_nonnull(foo_object)) { ... }"
 *
 *           "if (foo_object==0) { ... }"
 *               becomes "if (not is_nonnull(foo_object)) { ... }"
 *
 *           "if (not foo_object) { ... }"
 *               becomes "if (not is_nonnull(foo_object)) { ... }"
 *
 *     * replace dynamic and static casts, using the following model:
 *
 *           "static_cast<Bar *>(foo_object)"
 *               becomes "pointer_static_cast(Bar)(foo_object)"
 *
 *           "dynamic_cast<Bar *>(foo_object)"
 *               becomes "pointer_dynamic_cast(Bar)(foo_object)"
 *
 *     * when the pointer "this" has to be used as a "pointer_type(...)",
 *       replace it with "this_pointer" (this yields a weak shared pointer to
 *       "this");
 *
 *     * when a null pointer is required, use for instance "null_pointer(Bar)",
 *       where "Bar" is the type of the resulting null pointer;
 *
 *     * replace pointers to stack variables or member variables, using the
 *       following model (this yields a weak shared pointer):
 *
 *           "foo.subscribe(&baz)"
 *               becomes "foo.subscribe(pointer_to(baz))"
 *
 *     * in the shared-pointer policy, if a shared pointer must be turned into
 *       a weak pointer (so that it is not taken into account to determined the
 *       life of the object pointed to), use the following syntax (which
 *       translates to no conversion in the naked-pointer policy):
 *
 *           "foo=weak_pointer(qux)"
 *
 * A new kind of pointer is obtained when "pointer_type" is replaced with
 * "zero_init_pointer_type".  For the shared-pointer policy
 * "zero_init_pointer_type" is identical to "pointer_type", but for the
 * naked-pointer policy, the resulting pointer is guaranteed to be initialised
 * to "0" unless explicitly initialised.
 *
 * After such a change, you should verify that nothing breaks with the
 * naked-pointer policy (including the whole "indra" repository and available
 * code using it with the naked-pointer policy), and that nothing breaks with
 * the shared-pointer policy (including the whole "indra" repository and
 * available code using it with the shared-pointer policy).
 *
 * If and when the naked-pointer policy becomes deprecated, the final goal of
 * having no explicit memory management code shall be attained by removing
 * unneeded "release_pointer()" expressions from the code, and optionally by
 * translating pointer specifications to direct uses of "shared_ptr" and
 * removing this file (which will then RIP at last, having fulfilled its
 * mission).
 *
 * Warning: none of this should be used for pointers to objects not explicitly
 * created with "new"; otherwise, there will be chaos.  For the same reason, it
 * is recommended that objects with behaviour or likely to be used by several
 * objects (that is, for instance, implementations of "Model", "Solid",
 * integrators, filters...) be declared as pointers and created with "new",
 * rather than on the stack or as part of container objects.
 */

#ifdef USE_SHARED_POINTERS_WHEN_AVAILABLE

#include "shared_ptr.h"
#define pointer_type(...) indra_lib::shared_ptr<__VA_ARGS__ >
#define zero_init_pointer_type(...) pointer_type(__VA_ARGS__)
#define new_pointer(...) (indra_lib::new_shared_ptr(new __VA_ARGS__))
#define release_pointer(...) (__VA_ARGS__).reset()
#define reset_pointer(...) (__VA_ARGS__).reset()
#define release_and_reset_pointer(...) (__VA_ARGS__).reset()
template <typename T>
bool is_nonnull(pointer_type(T) const &p) { return p.is_nonnull(); }
#define pointer_static_cast(...) indra_lib::shared_ptr<__VA_ARGS__>
#define pointer_dynamic_cast(...)                                       \
  indra_lib::shared_ptr_dynamic_cast<__VA_ARGS__>
#define this_pointer (indra_lib::weak_shared_ptr(this))
#define null_pointer(...) (indra_lib::shared_ptr<__VA_ARGS__>())
#define pointer_to(...) (indra_lib::weak_shared_ptr(&(__VA_ARGS__)))
#define weak_pointer(...) ((__VA_ARGS__).weak())

#else

#include "base.h"
#define pointer_type(...) __VA_ARGS__ *
#define zero_init_pointer_type(...) auto_init<__VA_ARGS__ *>
#define new_pointer(...) (new __VA_ARGS__)
namespace indra_lib {
  template <typename T>
  void zeroize_pointer_if_non_const(T *&t) { t=0; }
  template <typename T>
  void zeroize_pointer_if_non_const(T *const &) { }

  template <typename T>
  void zeroize_pointer_if_non_const(auto_init<T *> &t) { t=(T *)(0); }
  template <typename T>
  void zeroize_pointer_if_non_const(auto_init<T *const> &) { }

  template <typename T>
  void delete_pointer(T *t) { delete t; }
  template <typename T>
  void delete_pointer(auto_init<T *> const &t) { delete t.value(); }
}
#define release_pointer(...)                                            \
  ::indra_lib::delete_pointer(__VA_ARGS__)
#define reset_pointer(...)                                              \
  ::indra_lib::zeroize_pointer_if_non_const(__VA_ARGS__)
#define release_and_reset_pointer(...)                                  \
  do {                                                                  \
    release_pointer(__VA_ARGS__);                                       \
    reset_pointer(__VA_ARGS__);                                         \
  } while (false)
template <typename T>
bool is_nonnull(pointer_type(T) const &p) { return p!=0; }
template <typename T>
bool is_nonnull(auto_init<pointer_type(T)> const &p) { return p.value()!=0; }
#define pointer_static_cast(...) (__VA_ARGS__ *)
#define pointer_dynamic_cast(...) dynamic_cast<__VA_ARGS__ *>
#define this_pointer this
#define null_pointer(...) (0)
#define pointer_to(...) (&(__VA_ARGS__))
#define weak_pointer(...) (__VA_ARGS__)

#endif

#endif
