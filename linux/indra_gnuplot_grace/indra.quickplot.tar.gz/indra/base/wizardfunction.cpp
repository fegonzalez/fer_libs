#include "wizardfunction.h"
#include <math.h>

Line *Line::new_by_points(scalar x1, scalar y1, scalar x2, scalar y2) {
    return new Line(x1, y1, (y2-y1)/(x2-x1));
}
Line *Line::new_by_pointer_points(scalar const *x1,scalar const *y1,
				  scalar const *x2,scalar const *y2) {
  return new_by_points(*x1, *y1, *x2, *y2);
}
Line *Line::new_by_pointers(scalar const *x_0, scalar const *y_0,
			    scalar const *slope){
    return new Line(*x_0, *y_0, *slope);
}

scalar Line::operator()(scalar const &x) const {
    return y_0+slope*(x-x_0);
}

Quadratic *Quadratic::new_by_points(scalar x1, scalar y1,
                                    scalar x2, scalar y2,
                                    scalar x3, scalar y3) {
    scalar factor_0 = (square(x1)-square(x2))*(x2-x3)
        -(square(x2)-square(x3))*(x1-x2);
    if (fabs(factor_0)<0.001) throw "Points repeated";
    scalar factor_1 = (y1-y2)*(x2-x3)-(y2-y3)*(x1-x2);
    scalar A_0 = factor_1/factor_0;
    scalar B_0 = ((y1-y2)-A_0*(square(x1)-square(x2)))/(x1-x2); //There is not
                                                                //problem with
                                                                //division by
                                                                //zero because
                                                                //we have
                                                                //avoided the
                                                                //previous
                                                                //throw.
    scalar C_0 = y1-A_0*square(x1)-B_0*x1;
    return new Quadratic(A_0,B_0,C_0);
}

scalar Quadratic::operator()(scalar const &x) const {
    return A*square(x)+B*x+C;
}

Exponential *Exponential::new_by_points(scalar x1, scalar y1,
                                        scalar x2, scalar y2,
                                        scalar x3, scalar y3) {
    //Solve the problem by means of Newton's method
    if (fabs(x2-x3)<0.001) throw "Definition point repeated";
    scalar y0_0 = 0.0;
    scalar K_0=(x1-x2)/(x2-x3);
    scalar error;
    for (int i=0;i<100;i++) {
        scalar derivate = -pow(y3-y0_0,K_0-1.)*(y3-y0_0+K_0*(y1-y0_0))
            +(K_0+1.)*pow(y2-y0_0,K_0);
        scalar function = (y1-y0_0)*pow(y3-y0_0,K_0)-pow(y2-y0_0,K_0+1.);
        scalar derivate_sign = 1.0;
        if (derivate<0.0)
            derivate_sign = -1.0;
        if (fabs(derivate) < 0.01)
            derivate = 0.01 * derivate_sign;
        y0_0 = y0_0 - function/derivate;
        error=function;
    }
    if (fabs(error)>0.01) throw "Function not defined";
    if (fabs(y3-y0_0)<0.001) throw "Division by zero";
    scalar factor = (y2-y0_0)/(y3-y0_0);
    if (factor <= 0.0) throw "Function not real";
    scalar B_0 = log(factor)/(x2-x3);
    scalar A_0 = (y1-y0_0)/exp(B_0*x1);
    return new Exponential(y0_0,A_0,B_0);
}

scalar Exponential::operator()(scalar const &x) const {
    return y0+A*exp(B*x);
}
