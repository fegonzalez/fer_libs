#include "algebra_functor.h"

