#ifndef POLYNOMIAL_HEADER
#define POLYNOMIAL_HEADER

#include "functor.h"
#include "algebra.h"


namespace Function
{
  /* This class evaluate a polynomical function and its 
     derivative in a point x with the following arguments:
     
     T: type
     n: polynomical order
     c[n+1]: coeffients of the polynomic 

     y = c(0) +  c(1)*x  + c(2)*x^2 + ... + c(n)*x^n

  */
  template <typename T, int n>
  class Polynomial: public Functor_1<T>
  {
  public:

    Polynomial(Algebra::GeneralVector<T,n+1> const &cc):c(cc)
    {
    }
    
    ~Polynomial(){};

    T operator()(T const &x) const
    {
      T p=c(n+1-1);
      
      for(int j=n+1-2;j>=0;j--)
	{
	  p = (p*x) + c(j);
	}

      return p;
    }
    
    T dPdx(T const &x) const 
    {
      // n = polynomial order
      // m = n-1 derivative order      
      int const m = n-1;
      Algebra::GeneralVector<T,n> nc;
      for(int jj = 1; jj<n+1; jj++)
	{
	  nc(jj-1) = jj*c(jj);
	}
      
      Polynomial<T,m> dP(nc);
      return dP(x);

    }


  private:

    Algebra::GeneralVector<T,n+1> const &c;
  
  };

}

// **********************************************************
  
namespace Function
{


}



#endif
