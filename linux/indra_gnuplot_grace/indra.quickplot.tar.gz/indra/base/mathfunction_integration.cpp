#include "../base/mathfunction_integration.h"

scalar TrapeziumIntegral::integrate() {

 scalar dx=(x_end-x_init)/scalar(steps);
 scalar x=x_init;    
 scalar sum=(*function)(x)/2.0;
 for(int i=1;i<steps;i++) {
  x+=dx;
  sum+=(*function)(x);
 }
 sum+=(*function)(x_end)/2.0;
 integral=sum*dx;
 return integral;

}

scalar SimpsonIntegral::integrate() {

   if(2*int(float(steps)/2.0)!=steps) steps++;
    scalar dx=(x_end-x_init)/scalar(steps);
    scalar sum=(*function)(x_init);

   for(int i=1;i<int(scalar(steps)/2.);i++) {
     sum+=2.*(*function)(x_init + 2*i*dx);
   }

   for(int i=1;i<=int(scalar(steps)/2.);i++) {
    sum+=4.*(*function)(x_init + (2*i-1)*dx);
   }
   sum+=(*function)(x_end);
   integral=(sum*dx/3.0);

  return integral;
}



