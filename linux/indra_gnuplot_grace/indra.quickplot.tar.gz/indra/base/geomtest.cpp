#include "geometry.h"
#include "integration.h"
#include <iomanip>

using std::cout;
using std::endl;
using std::setprecision;
using std::fixed;

int main()
{

  cout << fixed << setprecision(3);
     {
	Vector a(1, 2, 3);
	Vector b(2, 3, 5);
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << "2 * a = " << 2*a << endl;
	cout << "a + b = " << a+b << endl;
	cout << "a - b = " << a-b << endl;
	cout << "a + (- b) = " << a+(-b) << endl;
	cout << "a * b = " << a*b << endl;
	cout << "a � b = " << scalprod(a,b) << endl;
	a+=b;
	cout << "a += b; a = " << a << endl;
	cout << endl;
     }
     {
	Matrix a(1, 2, 3, 4, 5, 6, 7, 8, 9);
	Matrix b(0, 1, 2, 1, 3, 4, 3, 5, 11);
	cout << "a = " << endl << a << endl;
	cout << "b = " << endl << b << endl;
	cout << "2 * a = " << endl << 2*a << endl;
	cout << "a + b = " << endl << a+b << endl;
	cout << "a - b = " << endl << a-b << endl;
	cout << "a + (- b) = " << endl << a+(-b) << endl;
	cout << "a * b = " << endl << a*b << endl;
	cout << "trans(b) = " << endl << trans(b) << endl;
	cout << "det(a) = " << det(a) << endl;
	cout << "det(b) = " << det(b) << endl;
	cout << "inv(b) = " << endl << inv(b) << endl;
	cout << "inv(b) * b = " << endl << inv(b)*b << endl;
	Vector v(2, 5, 3);
	cout << "v = " << v << endl;
	cout << "a * v = " << a*v << endl;
	cout << "rot = mpsithetaphi(.1, 1.2, 1.3)" << endl;
	Matrix rot = mpsithetaphi(.1, 1.2, 1.3);
	scalar psi, theta, phi;
	rot.getpsithetaphi(psi, theta, phi);
	cout << "psi = " << psi << endl;
	cout << "theta = " << theta << endl;
	cout << "phi = " << phi << endl;
	cout << endl;
     }
     {
	Quaternion p;
	cout << "p = mpsithetaphi(.1, .2, 1.3)" << endl;
	p = qpsithetaphi(.1, .2, 1.3);
	scalar psi, theta, phi;
	p.getpsithetaphi(psi, theta, phi);
	cout << "psi = " << psi << endl;
	cout << "theta = " << theta << endl;
	cout << "phi = " << phi << endl;
	cout << "Matrix(p) - mpsithetaphi(.1, .2, 1.3) = " << endl
	  << Matrix(p)-mpsithetaphi(.1, .2, 1.3) << endl;
	cout << endl;
	cout << "p = " << p << endl;
	cout << "Quaternion(Matrix(p)) = " << Quaternion(Matrix(p)) << endl;
	Vector v(3, -4, 9);
	cout << "v = " << v << endl;
	cout << "p * v = " << p * v << endl;
	cout << "Matrix(p) * v = " << Matrix(p)*v << endl;
	Quaternion q(Vector(2, 3, -5), .7);
	cout << "q = " << q << endl;
	cout << "p * (q * v) = " << p*(q*v) << endl;
	cout << "(p * q) * v = " << (p*q)*v << endl;
	cout << "p * inv(p) = " << p*inv(p) << endl;
	cout << "inv(p)*p = " << inv(p)*p << endl;
	Vector u=v/norm(v);
	Quaternion p0(p);
	scalar dt=1./100.;
	scalar omega=.75;
	TrapezialIntegrator<Quaternion> irp(dt);
	irp.initialise(u*omega, p);
	for (int i=0; i<100; i++)
	  irp.integrate(u*omega);
	p=irp;
	cout << "axis u = " << u << endl;
	cout << "omega = " << omega << endl;
	cout << "after one second of relative rotation at 100Hz,"
	        "with TrapezialIntegrator," << endl << "  p = " << p << endl;
	cout << "Quaternion(p0 * u, omega * 1.) * p0 = "
	  << (Quaternion(p0*u, omega*1.))*p0 << endl;
	p0=p;
	for (int i=0; i<100; i++)
	  p.rot_abs(u*omega*dt);
	cout << "axis u = " << u << endl;
	cout << "omega = " << omega << endl;
	cout << "after one second of absolute rotation at 100Hz,"
	  << endl << "  p = " << p << endl;
	cout << "Quaternion(u, omega * 1.) * p0 = "
	  << (Quaternion(u, omega*1.))*p0 << endl;
     }
     {
	Quaternion p;
	cout << "p = mpsithetaphi(-.1, .2, 3.1)" << endl;
	p = qpsithetaphi(-.1, .2, 3.1);
	scalar psi, theta, phi;
	p.getpsithetaphi(psi, theta, phi);
	cout << "psi = " << psi << endl;
	cout << "theta = " << theta << endl;
	cout << "phi = " << phi << endl;
     }
     {
       Quaternion p(Vector(3., 0, 4.), 1.7);
       cout << "p=(Vector(3., 0, 4.), 1.7)" << endl;
       cout << "axis_angle=" << p.get_axis_angle() << endl;
     }
     {
       psitheta pt={ 2.9, -.7 };
       cout << vpsitheta(pt).getpsitheta() << endl;

       thetaphi tp={ .7, -2.9 };
       cout << vthetaphi(tp).getthetaphi() << endl;
       thetaphi tp2={ .7, .3 };
       cout << vthetaphi(tp2).getthetaphi() << endl;

       alphabeta ab={ 2.9, -.7 };
       cout << valphabeta(ab).getalphabeta() << endl;
     }
}
