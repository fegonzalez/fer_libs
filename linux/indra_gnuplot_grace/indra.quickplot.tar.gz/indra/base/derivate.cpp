#include "derivate.h"

Derivate::~Derivate() {}
