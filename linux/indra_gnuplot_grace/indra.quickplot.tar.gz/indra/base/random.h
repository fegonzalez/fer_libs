#ifndef BSIM_RANDOM_HEADER_
#define BSIM_RANDOM_HEADER_

#include "scalar.h"

/* The following class is an adaptation of the 'rand48.c' file of the "GNU
 * Scientific Library". */

/* The Rand48 class is a random number generator. Its implementation is the
 * same as the implementation of the 'rand48' family from 'stdlib.h', but
 * it allows saving and recording (with RecPlay) the internal state of the
 * generator. This makes possible to reproduce sequences of random numbers
 * (from the same internal state, the same sequence of random numbers is
 * obtained). */

class Rand48 {
public:
  struct State {
    unsigned short int x0, x1, x2;
  };
  /* Constructor from the seed. If the seed is not given, it initializes with
   * the default value. */

  Rand48(unsigned long int s=0);

  /* Constructor from an internal state, obtained by means of get_state(). */

  Rand48(State init_state);

  /* It initializes the generator again with a given seed. If the seed is not
   * given, it initializes it again with a default value. */

  void set_seed(unsigned long int s=0);

  /* It obtains the internal state, for initializing again later in this state.
   * The state can be used in any instance of Rand48. */

  State get_state() const;

  /* It initializes the generator again with the given internal state. */

  void set_state(State new_state);

  /* It generates a random value of unsigned long int type. */

  unsigned long int get_unsigned_long_int();

  /* It generates a random scalar between 0 (included) and 1 (not included).
   * The result coincides with the one of 'drand48() of 'stdlib.h'. */

  scalar get_scalar_0_1();

  /* It generates a random scalar between 'y0' (included) and 'y1' (not
   * included). */

  scalar get_scalar(scalar y0, scalar y1);

  /* It generates a random int between 'y0' (included) and 'y1' (not
   * included) */

  int get_int(int y0, int y1) { return int(get_scalar(y0, y1)); }

  /* It generates a random scalar with a normal distribution, with 0 mean and
   * unit standard deviation. */
  scalar get_scalar_normal_0_mean_1_standard_deviation();

  /* It generates a random scalar with a normal distribution, with specified
   * mean and standard deviation. */
  scalar get_scalar_normal(scalar mean, scalar standard_deviation);

private:
  void advance();
  State state;
};

/* Use RandomGenerator instead of Rand48 (it's more descriptive). */

typedef Rand48 RandomGenerator;

#endif
