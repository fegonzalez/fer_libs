#include "base.h"
#include "array.h"
#include <cmath>
#include <iostream>
#include <cstring>

//Atencion: Sustituir los tipos por unos mejores, a saber, int16 y int32

template <unsigned int bits>
struct BitBasedType { };

template <>
struct BitBasedType<16> {
	typedef unsigned short int Type;
};

template <>
struct BitBasedType<32> {
	typedef unsigned long int Type;
};


/*Conversor decimal a binario*/
//ENTRADAS: value -> necesariamente positivo
//          binary_zone -> puntero a entero donde almacenar binario
//          sizeof_binary_zone -> tamaño de la zona anterior
inline void decimal_to_binary(int value,int *binary_zone,int sizeof_binary_zone){

  int j=0,res;

  for(j=0;j<sizeof_binary_zone;j++)
  	   binary_zone[j]=0;

  j=0;
  while(value>1){
      res = value % 2;
      if(j<sizeof_binary_zone)
         {
			if(res == 1)
			  binary_zone[j]=1;
         else
		  	  if(res == 0)
			     binary_zone[j]=0;
         }
      value = value / 2;
		j++;
      }
  if(j<sizeof_binary_zone)
     {
	  if(value==0)
		  binary_zone[j]=0;
     else
		  binary_zone[j]=1;
	  }

}


/*
Q-Notation (Qi.f)
i parte entera tendrá un formato de i+1 compemento a 2)
f parte fraccionaria tendrá f bits

Ejemplo para 16 bits: Q8.7
Bit      15    14  13  12  11  10  9  8  7   6   5   4    3    2    1     0
Valor    0      0   0   0   1   0  1  1  1   1   1   0    0    0    0     0
Escalar  -256 128  64  32  16   8  4  2  1 1/2 1/4 1/8 1/16 1/32 1/64 1/128
*/

template <unsigned int i_size,unsigned int f_size>
class QNotation{
public:
   QNotation(){}
   QNotation(scalar x){
		set_scalar_value(x);
	}
	QNotation(int *binary_zone,int size_binary_zone){
	  set_binary(binary_zone,size_binary_zone);

	}
	~QNotation(){}


//INPUT METHODS
 //Forzosamente el tamaño de la binary_zone debe ser al menos igual o mayor a la suma i_size+f_size+1 bajo riesgo de error
	  void set_binary(int *binary_zone,int size_binary_zone){
			 assert(size_binary_zone>=(int)(f_size+i_size+1));
			 unsigned int i;
			 for(i=0;i<i_size+1;i++)
					integer_zone[i]=binary_zone[i_size-i];
			 for(i=0;i<f_size;i++)
					fractional_zone[i]=binary_zone[i_size+1+i];

			 for(i=0;i<f_size+i_size+1;i++)
					qnotation[i]=binary_zone[i];

	}


   //    0   1   2    3    4    5     6 ...
   //  1/2 1/4 1/8 1/16 1/32 1/64 1/128 ...
   void set_fractional(scalar new_value){
	   if(new_value<0)new_value*=-1;
		new_value-=floor(new_value);
	   for(unsigned int i=0;i<f_size;i++)
		      if(new_value>=(1/(double)(1<<(i+1))))
			   {
				fractional_zone[i]=1;
		        new_value-=(1/(double)(1<<(i+1)));
				}
		   else
				fractional_zone[i]=0;

   }
   // 0 1 2 3  4  5  6   7    8
   // 1 2 4 8 16 32 64 128 -256
   void set_integer(scalar new_value){
		int integer_value;
		if(new_value<0)
			integer_value=(int)ceil(new_value);
      else
			integer_value=(int)floor(new_value);

		if(integer_value<0)
		   {
			integer_value+=(int)(1<<i_size);
			integer_zone[i_size]=1;
		   }
		else
			integer_zone[i_size]=0;

	  int binary_zone[i_size];
	  decimal_to_binary(integer_value,binary_zone,sizeof(binary_zone)/4);

	  for(unsigned int i=0;i<i_size;i++)
		  integer_zone[i]=binary_zone[i];
	}
   //    0   1  2  3  4  5  6  7  8    9  10  11   12   13   14    15
   // -256 128 64 32 16  8  4  2  1  1/2 1/4 1/8 1/16 1/32 1/64 1/128
	void set_qnotation(){
		//Rellenando la zona entera
      qnotation[0]=integer_zone[i_size];
      for(unsigned int i=1;i<i_size+1;i++)
			qnotation[i]=integer_zone[i_size-i];

		//Rellenando la zona fraccionaria
		for(unsigned int i=0;i<f_size;i++)
			qnotation[i_size+1+i]=fractional_zone[i];
	   }

	void set_scalar_value(scalar new_value){
	  set_integer(new_value);
	  set_fractional(new_value);
      set_qnotation();
	}


//OUTPUT METHODS
   integer get_integer(){
		integer result=0;
		for(unsigned int i=0;i<i_size;i++)
 		    result+=integer_zone[i]*(integer)(1<<i);
		result-=integer_zone[i_size]*(integer)(1<<i_size);

		return result;
      }

	scalar get_fractional(){
		scalar result=0;
	    for(unsigned int i=0;i<f_size;i++)
		   result+=fractional_zone[i]*(1/(double)(1<<(i+1)));
		return result;
	   }

   scalar get_scalar()
	   {return get_integer()+get_fractional();}

   typename BitBasedType<i_size+f_size+1>::Type get_bits() {
		unsigned int result=0;
		for(unsigned int i=0;i<i_size+f_size+1;i++)
			if(qnotation[i])
				result+=1 << (i_size+f_size-i);
		return typename BitBasedType<i_size+f_size+1>::Type(result);
	}


   //Devuelve el valor de la Qnotation en un tipo básico de 16 bits
   unsigned int get_16bits(){
		unsigned int result=0;
		for(unsigned int i=0;i<i_size+f_size+1;i++)
			if(qnotation[i])
			   result+=(unsigned int)(1<<(i_size+f_size-i));
		return result;
	}

   //Devuelve el valor de la Qnotation en un tipo básico de 32 bits
	unsigned long int get_32bits(){
		unsigned long int result=0;
		for(unsigned int i=0;i<i_size+f_size+1;i++)
			if(qnotation[i])
		       result+=(unsigned long int)(1<<(i_size+f_size-i));
		return result;
		}



   //Print private variables
   void print_integer(){
      for(unsigned int i=0;i<i_size+1;i++)
		  std:: cout << " " << integer_zone[i];}

   void print_fractional(){
      for(unsigned int i=0;i<f_size;i++)
  		  std:: cout << " " << fractional_zone[i];}

   void print(){
      for(unsigned int i=0;i<i_size+f_size+1;i++)
  		  std:: cout << " " << qnotation[i];	}

//Sobrecarga del operador igual (=)
	//asignar un "scalar" a un "QNotation"
	QNotation<i_size,f_size> &operator=(scalar x){
		*this=QNotation(x);
		return *this;
	}

	//asignar un "QNotation a un "scalar"
	//operator scalar() const{
	//	return this.get_scalar();
	//}

private:
//guarda la parte entera en el orden:       ejemplo 1 2 4 8 16 32 64 128 -256
   array<bool,i_size+1> integer_zone;
//guarda la parte fraccionaria en el orden: ejemplo 1/2 1/4 1/8 1/16 1/32 1/64 1/128
	array<bool,f_size> fractional_zone;
//guarda escalar en formato QNotation:      ejemplo -256 128 64 32 16 8 4 2 1 1/2 1/4 1/8 1/16 1/32 1/64 1/128
	array<bool,i_size+f_size+1> qnotation;
};
