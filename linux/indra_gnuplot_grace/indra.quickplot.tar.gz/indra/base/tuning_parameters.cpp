#include "tuning_parameters.h"

#include <iostream>
#include <stdexcept>
#include <cassert>

TuningParameters::TuningParameters(std::string set_of_parameters_name)
  : name(set_of_parameters_name) {
  set_of_parameters.clear();
}

void TuningParameters::add_item(std::string parameter_name,
				scalar parameter_value) {
  if(find(parameter_name))
    std::cerr << "ERROR: VARIABLE " << parameter_name
	      << " IS REPEATED" << std::endl;

  assert(not find(parameter_name));

  set_of_parameters.insert(make_pair(parameter_name, parameter_value));
}

scalar &TuningParameters::get_parameter(std::string parameter_name) {
  if(not find(parameter_name))
    std::cout << "ERROR: VARIABLE " << parameter_name
	      << " DOESN'T EXIST" << std::endl;

  assert(find(parameter_name));
  return set_of_parameters[parameter_name];
}

scalar &TuningParameters::get_parameter(std::string parameter_name,
                                        scalar default_value) {
  if (not find(parameter_name))
    add_item(parameter_name, default_value);

  assert(find(parameter_name));

  return set_of_parameters[parameter_name];
}

void TuningParameters::set_parameter(std::string parameter_name,
				     scalar new_value) {
  if(find(parameter_name))
    set_of_parameters[parameter_name]=new_value;
  else
    std::cout << "ERROR: VARIABLE " << parameter_name
	      << " DOESN'T EXIST" << std::endl;

  assert(find(parameter_name));
}

std::string TuningParameters::get_set_of_parameters_name() const {
  return name;
}

std::map<std::string,scalar>::const_iterator TuningParameters::begin() {
  return set_of_parameters.begin();
}

std::map<std::string,scalar>::const_iterator TuningParameters::end() {
  return set_of_parameters.end();
}

bool TuningParameters::find(std::string parameter_name) {
  if(set_of_parameters.find(parameter_name)!=set_of_parameters.end())
    return true;
  else
    return false;
}

std::ostream &operator<<(std::ostream &os, TuningParameters set_of_parameters)
{
  os << "{ ";
  for (std::map<std::string, scalar>::const_iterator
	 scan=set_of_parameters.begin(),
	 end=set_of_parameters.end();
       scan!=end;
       ++scan) {
    os << scan->first << "= "
       << set_of_parameters.get_parameter(scan->first) << " ";
  }
  os << "}";

  return os;
}

std::istream &operator>>(std::istream &is, TuningParameters &set_of_parameters)
{
  std::string parameter_name;
  scalar parameter_value;

  is >> parameter_name >> parameter_value;
  if (set_of_parameters.find(parameter_name))
    set_of_parameters.set_parameter(parameter_name, parameter_value);
  else
    is.setstate(std::ios::failbit);

  return is;
}
