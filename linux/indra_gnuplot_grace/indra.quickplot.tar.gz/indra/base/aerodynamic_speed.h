#ifndef AERODYNAMIC_SPEED_HEADER_
#define AERODYNAMIC_SPEED_HEADER_

#include "scalar.h"
#include "base.h"
#include "model.h"

class AerodynamicSpeed{
public:
   AerodynamicSpeed();
   AerodynamicSpeed( scalar temperature, scalar pressure,
                     scalar sea_level_temperature, scalar sea_level_pressure);
   
   ~AerodynamicSpeed() {};

private:

   scalar const gamma;
   scalar const R;

   scalar true_airspeed;

   scalar pressure;
   scalar temperature;
   scalar sea_level_pressure;
   scalar sea_level_temperature;

  scalar density() const ;
  scalar sea_level_density() const ;
  scalar local_sound_speed() const ;
  scalar mach() const;

public:


  scalar cas() const ;
  scalar tas()const {return true_airspeed;}
  scalar eas()const ;

  void set_mach(scalar M);
  void set_true_airspeed(scalar tas);
  void set_calibrated_airspeed(scalar cas);
  void set_atmospheric_parameters(scalar static_pressure, scalar dynamic_pressure,
                                   scalar temperature);
  void set_sea_level_atmospheric_parameters(scalar sea_level_temperature,
					    scalar sea_level_pressure);
};


#endif
