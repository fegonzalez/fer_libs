#include "random.h"
#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

int main(int argc, char **argv) {
  long int n_samples=100;
  if (argc>1) {
    n_samples=1000000;
    if (string(argv[1])=="-r") {
      cout << n_samples << endl;
      return 0;
    }
  }
  RandomGenerator rg;
  rg.set_seed(42);
  for (long int i=0; i<n_samples; ++i)
    cout << rg.get_scalar_normal_0_mean_1_standard_deviation() << endl;
}

// you can check the normal distribution statistically by doing the following:
//
//     make randomtest && ./randomtest.plot
//
// ('q' to quit); this generates one million numbers, and plots their
// distribution along with the theoretical distribution (it may take a while),
// which it should match quite closely
