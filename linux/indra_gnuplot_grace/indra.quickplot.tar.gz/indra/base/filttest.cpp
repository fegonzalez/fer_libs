#include "mathfilter.h"
#include <iostream>

using std::cout;
using std::endl;

void feed(Tustin11 &f, scalar x)
{ cout << x << " " << f.filter(x) << endl; }

void feed_r(Tustin02 &f, scalar x)
{ cout << x << " " << f.filter(x) << endl; }

void feed_PID(MMPZ_PID &f, scalar x)
{ cout << x << " " << f.filter(x) << endl; }


int main()
{
     {
	cout << "lag: tau_d=.05" << endl;
	Tustin11 fll(.02, 1, 0, 1, .05);
	fll.initialise(0, 0);
	for (int i=0; i<2; i++)
	  feed(fll, 0);
	for (int i=0; i<10; i++)
	  feed(fll, 1);
	cout << endl;
     }
     {
	cout << "washout: tau_d=.05" << endl;
	Tustin11 fll(.02, 0, .05, 1, .05);
	fll.initialise(0, 0);
	for (int i=0; i<2; i++)
	  feed(fll, 0);
	for (int i=0; i<10; i++)
	  feed(fll, 1);
	cout << endl;
     }
     {
	cout << "lead-lag: tau_n=.1, tau_d=.05" << endl;
	Tustin11 fll(.02, 1, .1, 1, .05);
	fll.initialise(0, 0);
	for (int i=0; i<2; i++)
	  feed(fll, 0);
	for (int i=0; i<10; i++)
	  feed(fll, 1);
	cout << endl;
     }
     {
	cout << "lead-lag: tau_n=.05, tau_d=.1" << endl;
	Tustin11 fll(.02, 1, .05, 1, .1);
	fll.initialise(0, 0);
	for (int i=0; i<2; i++)
	  feed(fll, 0);
	for (int i=0; i<10; i++)
	  feed(fll, 1);
	cout << endl;
     }
     {
	cout << "delay: Delta_t=.1" << endl;
	Tustin02 fr(.02, 4./(.1*.1), 2./.1, 1, 2./.1, 1);
	fr.initialise(0, 0);
	for (int i=0; i<2; i++)
	  feed_r(fr, 0);
	for (int i=0; i<10; i++)
	  feed_r(fr, 1);
	cout << endl;
     }
     {
	cout << "PID: k=2., T_I=.1, T_D=.5, N=5" << endl;
	MMPZ_PID fPID(.02, 2., .1, .5, 5);
	fPID.initialise(0, 0);
	for (int i=0; i<2; i++)
	  feed_PID(fPID, 0);
	for (int i=0; i<10; i++)
	  feed_PID(fPID, i*0.1);
	for (int i=0; i<10; i++)
	  feed_PID(fPID, 1.);
	cout << endl;
     }
     {
         cout << "SecondOrderFilter: k=1., a=1., b=3., c=2." << endl;
         scalar dt = 0.02;
         SecondOrderFilter sof(dt, 1., 1., 3., 2.);
         sof.initialise(0.,0.);
         for (int i=0; i<20; i++)
             cout << 0. << " " << sof.filter(0.) << endl;
         cout << 0.0 << " " << sof.filter(1.0 / dt) << endl;
         for (int i=1; i<=(2/dt+.5); i++)
             cout << i*dt << " " << sof.filter(0.0) << endl;
         cout << endl;
     }
     {
       cout<<"\n\n " << endl;

       scalar x = 0.0;
       int n = 5;

       PureDelay<scalar> delay(&x,n);
       PureDelay<scalar> delay0(&x);

       delay.initialise();
       delay0.initialise();

       std::cout << x << " " << delay.output <<" "<< delay0.output << std::endl;

       while(x < 10.0)
	 {
	   x = x + 1;
	   delay.run();
	   delay0.run();
	   
	   std::cout << x << " " << delay.output <<" "<< delay0.output << std::endl;
	 }
       


     }
     {
       std::cout << "Zero order hold. Characteristic time 0.5" << std::endl;
       scalar dt=0.1;
       ZeroOrderHold zoh(dt, 0.5);
       scalar time=0.0;
       zoh.initialise(0.0, 0.5);
       std::cout << "Time: " << time << "\tZoh: " << zoh() << std::endl;
       while (time<2.0) {
	 time+=dt;
	 zoh.filter(ramp(time,0.0, 0.0, 2.0, 2.0));
	 std::cout << "Time: " << time << "\tZoh: " << zoh() << std::endl;
       }
       std::cout << "Initialising filter. Initial value 1.0 Characteristic time 0.2" << std::endl;
       zoh.initialise(1.0, 0.2);
       time=0.0;
       std::cout << "Time: " << time << "\tZoh: " << zoh() << std::endl;
       while (time<2.0) {
	 time+=dt;
	 zoh.filter(ramp(time,0.0, 0.0, 2.0, 2.0));
	 std::cout << "Time: " << time << "\tZoh: " << zoh() << std::endl;
       }
     }
}
