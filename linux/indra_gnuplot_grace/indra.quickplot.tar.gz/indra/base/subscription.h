#ifndef BASE_SUBSCRIPTION_HEADER_
#define BASE_SUBSCRIPTION_HEADER_

#include "pointer_policy.h"
#include <list>

// FIXME: very poor documentation (in the mean time, see examples in "solid.h"
// and "model.h")

template <typename MagazineDer, typename Reader>
class SubscriptableBase {
private:
  typedef SubscriptableBase<MagazineDer, Reader> Node;
  typedef std::list<pointer_type(Reader)> ReaderCtr;
protected:
  typedef typename ReaderCtr::iterator Handle;
  Handle request_subscription(pointer_type(Reader) reader);
  void request_unsubscription(Handle handle);
  SubscriptableBase() { }
public:
  typedef typename ReaderCtr::iterator iterator;
  typedef typename ReaderCtr::const_iterator const_iterator;
  iterator begin();
  const_iterator begin() const;
  iterator end();
  const_iterator end() const;
private:
  ReaderCtr reader_container;
  // forbidden methods
  SubscriptableBase(SubscriptableBase const &); // copy constructor
  SubscriptableBase &operator=(SubscriptableBase const &); // assignment
};

template <typename MagazineDer, typename Reader=MagazineDer>
class Subscriptable
: public SubscriptableBase<MagazineDer, Reader> {
public:
  typedef typename SubscriptableBase<MagazineDer, Reader>::Handle Handle;
  // subscribe reader to this magazine
  Handle subscribe(pointer_type(Reader) reader);
  // unsubscribe reader from this magazine
  void unsubscribe(Handle handle);
};

template <typename NodeDer>
class Subscriptable<NodeDer, NodeDer>
: public SubscriptableBase<NodeDer, NodeDer> {
public:
  typedef typename SubscriptableBase<NodeDer, NodeDer>::Handle Handle;
  Subscriptable();
  virtual ~Subscriptable();
  // subscribe this to another node
  void subscribe_to(pointer_type(NodeDer) node);
  // subscribe this to another node, giving it a shared pointer if available,
  // so that the node subscribed to keeps the subscribed node alive
  void subscribe_to(pointer_type(NodeDer) node,
                    pointer_type(NodeDer) this_pointer_keep_alive);
  // unsubscribe this from the node it is subscribed to
  void unsubscribe();
  Handle subscribe(pointer_type(NodeDer) node);  // subscribe node to this
  void unsubscribe(Handle handle);  // unsubscribe node from this
protected:
  pointer_type(NodeDer const) get_owner_node() const;
private:
  pointer_type(NodeDer) owner_node;
  Handle handle;
};

/* implementation ************************************************************/

/* SubscriptableBase */

template <typename MagazineDer, typename Reader>
typename SubscriptableBase<MagazineDer, Reader>::Handle
SubscriptableBase<MagazineDer, Reader>
::request_subscription(pointer_type(Reader) reader) {
  return reader_container.insert(reader_container.end(), reader);
}

template <typename MagazineDer, typename Reader>
void
SubscriptableBase<MagazineDer, Reader>::request_unsubscription(Handle handle) {
  reader_container.erase(handle);
}

template <typename MagazineDer, typename Reader>
typename SubscriptableBase<MagazineDer, Reader>::iterator
SubscriptableBase<MagazineDer, Reader>::begin() {
  return reader_container.begin();
}

template <typename MagazineDer, typename Reader>
typename SubscriptableBase<MagazineDer, Reader>::const_iterator
SubscriptableBase<MagazineDer, Reader>::begin() const {
  return reader_container.begin();
}

template <typename MagazineDer, typename Reader>
typename SubscriptableBase<MagazineDer, Reader>::iterator
SubscriptableBase<MagazineDer, Reader>::end() {
  return reader_container.end();
}

template <typename MagazineDer, typename Reader>
typename SubscriptableBase<MagazineDer, Reader>::const_iterator
SubscriptableBase<MagazineDer, Reader>::end() const {
  return reader_container.end();
}

/* Subscriptable<MagazineDer, Reader> */

template <typename MagazineDer, typename Reader>
typename Subscriptable<MagazineDer, Reader>::Handle
Subscriptable<MagazineDer, Reader>::subscribe(pointer_type(Reader) reader) {
  return request_subscription(reader);
}

template <typename MagazineDer, typename Reader>
void Subscriptable<MagazineDer, Reader>::unsubscribe(Handle handle) {
  request_unsubscription(handle);
}

/* Subscriptable<NoderDer> */

template <typename NodeDer>
Subscriptable<NodeDer, NodeDer>::Subscriptable()
  : owner_node() { }

template <typename NodeDer>
Subscriptable<NodeDer, NodeDer>::~Subscriptable() {
  unsubscribe();
  while (not (this->begin()==this->end()))
    (*this->begin())->unsubscribe();
}

template <typename NodeDer>
pointer_type(NodeDer const)
Subscriptable<NodeDer, NodeDer>::get_owner_node() const {
  return owner_node;
}

template <typename NodeDer>
void Subscriptable<NodeDer, NodeDer>
::subscribe_to(pointer_type(NodeDer) node,
               pointer_type(NodeDer) this_pointer_keep_alive) {
  if (is_nonnull(owner_node))
    throw "already subscribed";
  // weak reference to the owner, since there is no reason for the owned to
  // keep the owner alive
  // owner_node=weak_pointer(node);
  owner_node=weak_pointer(node);
  handle=
    node->request_subscription(pointer_dynamic_cast(NodeDer)(
      this_pointer_keep_alive));
}

template <typename NodeDer>
void Subscriptable<NodeDer, NodeDer>
::subscribe_to(pointer_type(NodeDer) node) {
  // will not keep alive
  subscribe_to(node, pointer_dynamic_cast(NodeDer)(this_pointer));
}

template <typename NodeDer>
void Subscriptable<NodeDer, NodeDer>::unsubscribe() {
  if (is_nonnull(owner_node)) {
    // with shared pointers, if we unsubscribe first from "owner_node" and then
    // reset "owner_node", it may happen that "owner_node" holds the last
    // pointer to "this", so it would delete "this", thus triggering its
    // destructor, which calls again this method "unsubscribe()", which
    // requests again unsubscription from "owner_node" (core dumped); in order
    // to avoid this, we first reset "owner_node" and _then_ unsubscribe (from
    // a back-up copy); thus, the second time this method "unsubscribe()" is
    // called (by the destructor), "owner_node" is null and nothing is done
    pointer_type(NodeDer) owner_node_to_unsubscribe_to=owner_node;
    reset_pointer(owner_node);
    owner_node_to_unsubscribe_to->request_unsubscription(handle);
  }
}

template <typename NodeDer>
typename Subscriptable<NodeDer, NodeDer>::Handle
Subscriptable<NodeDer, NodeDer>::subscribe(pointer_type(NodeDer) node) {
  node->subscribe_to(pointer_dynamic_cast(NodeDer)(this_pointer), node);
  return node->handle;
}


template <typename NodeDer>
void Subscriptable<NodeDer, NodeDer>::unsubscribe(Handle handle) {
  pointer_dynamic_cast(NodeDer)(*handle)->unsubscribe();
}

/* end implementation ********************************************************/

#endif
