#include "limit_exceeded.h"
#include <iostream>

using namespace std;


/*---------------------------- IntervaLimit -----------------------------------*/
bool IntervalLimit::inInterval(Point pointToCheck)
{  
  if (pointToCheck.GetX()<initialPoint.GetX() || pointToCheck.GetX()>finalPoint.GetX())
    {return(false);} //x is out of the defined limits
  //To avoid divide by 0
  else if (DeltaX()<0e-5){return(false);}
  else
    {return(pointToCheck.GetY() < initialPoint.GetY()+(DeltaY()/DeltaX())*(pointToCheck.GetX()-initialPoint.GetX()));}
}

/*---------------------------- GraphLimit -----------------------------------*/
GraphLimit::GraphLimit(int numberOfPoints,Point* p_pointsList)
{
  p_points = p_pointsList;
  numberOfIntervals = numberOfPoints - 1;
  
  //The pointer to intervals array is created.
  p_intervals = new IntervalLimit[numberOfIntervals];
  
  //Initializing the array of IntervalLimit
    for(int i=0;i<numberOfIntervals;i++)
    {
      p_intervals[i].SetInitialPoint(p_pointsList[i]);
      p_intervals[i].SetFinalPoint(p_pointsList[i+1]);
    }
}

void GraphLimit::ShowData(void)
{
  for(int i=0; i < numberOfIntervals;i++)
    {
      cout<<"Intervalo: "<<i<<":"<<endl;
      cout<<"X0: "<<p_intervals[i].GetInitialPoint().GetX()<<" Y0: "<<p_intervals[i].GetInitialPoint().GetY()<<endl;
      cout<<"X1: "<<p_intervals[i].GetFinalPoint().GetX()<<" Y1: "<<p_intervals[i].GetFinalPoint().GetY()<<endl;
    }
}

scalar GraphLimit::LowerLimitSlope(void)
{
  scalar deltaX, deltaY;
  
  deltaX = p_points[numberOfIntervals].GetX() - p_points[0].GetX();
  // To avoid divide by 0
  //To avoid divide by 0
  if (deltaX<0e-5){return(0.0);}
  
  deltaY = p_points[numberOfIntervals].GetY() - p_points[0].GetY();
  if (deltaY<0e-5){return(0.0);}

  return (deltaY/deltaX);
}
    
bool GraphLimit::CheckPoint(Point pointToCheck)
{
  bool valueToReturn = false;
  // First is checked that the 'Y' is above the limit.
  if (pointToCheck.GetY()<p_points[0].GetY()+LowerLimitSlope()*(pointToCheck.GetX()-p_points[0].GetX()))
    { return false;}
  // The 'Y' condition is fulfilled 
 else
 {
   for(int i = 0; i<numberOfIntervals;i++)
     {
       valueToReturn = valueToReturn || p_intervals[i].inInterval(pointToCheck);
    }
   return valueToReturn;
 }
}


/*---------------------------- GraphLimitTimer -----------------------------------*/
GraphLimitTimer::GraphLimitTimer(int numberOfPoints, Point* p_pointList, scalar _intervalTime, scalar _dt):
  GraphLimit(numberOfPoints, p_pointList)
{ 
  timeLimit = _intervalTime;
  dt = _dt;
  currentTime = 0.0;
  launchedTimer = false;
}

bool GraphLimitTimer::CheckPointInTime(Point pointToCheck)
{
  if(CheckPoint(pointToCheck))
    {      
      currentTime = 0.0;
      return(true);
    }
  else
    { 
      currentTime += dt;
      return((currentTime<timeLimit) ? true : false);
    }
}


/*---------------------------- ConstantLimit -----------------------------------*/
ConstantLimit::ConstantLimit (scalar _limit): imposedLimit(_limit)
{
  pointerToLimit = &imposedLimit;
}

ConstantLimit::ConstantLimit (scalar *_limit)
{
  pointerToLimit = _limit;
}

/*---------------------------- ConstantLimitTimer -----------------------------------*/
ConstantLimitTimer::ConstantLimitTimer(scalar _limit, scalar _intervalTime, scalar _dt):
  ConstantLimit(_limit)
{
  timeLimit = _intervalTime;
  dt = _dt;
  currentTime = 0.0;
  launchedTimer = false;
}

ConstantLimitTimer::ConstantLimitTimer(scalar *_limit, scalar _intervalTime, scalar _dt):
  ConstantLimit(_limit)
{
  timeLimit = _intervalTime;
  dt = _dt;
  currentTime = 0.0;
  launchedTimer = false;
}


bool ConstantLimitTimer::CheckValueInTime(scalar value)
{
  if(CheckValue(value))
    {      
	currentTime = 0.0;
	return(true);
    }
  else
    { 
	currentTime += dt;
	return((currentTime<timeLimit) ? true : false);
    }
}


/*---------------------------- LowerConstantLimit-----------------------------------------*/

LowerConstantLimit::LowerConstantLimit (scalar _limit): imposedLimit(_limit)
{
  pointerToLimit = &imposedLimit;
}

LowerConstantLimit::LowerConstantLimit (scalar *_limit)
{
  pointerToLimit = _limit;
}

/*---------------------------- LowerConstantLimitTimer -----------------------------------*/
LowerConstantLimitTimer::LowerConstantLimitTimer(scalar _limit, scalar _intervalTime, scalar _dt):
  LowerConstantLimit(_limit)
{
  timeLimit = _intervalTime;
  dt = _dt;
  currentTime = 0.0;
  launchedTimer = false;
}

LowerConstantLimitTimer::LowerConstantLimitTimer(scalar *_limit, scalar _intervalTime, scalar _dt):
  LowerConstantLimit(_limit)
{
  timeLimit = _intervalTime;
  dt = _dt;
  currentTime = 0.0;
  launchedTimer = false;
}


bool LowerConstantLimitTimer::CheckValueInTime(scalar value)
{
  if(CheckValue(value))
    {      
	currentTime = 0.0;
	return(true);
    }
  else
    { 
	currentTime += dt;
	return((currentTime<timeLimit) ? true : false);
    }
}
