#include "shared_ptr.h"
#include <iostream>

using namespace std;
using namespace indra_lib;

class ShowLife {
public:
  ShowLife(int id) : id(id) { cout << "creating " << id << endl; }
  virtual ~ShowLife() { cout << "destroying " << id << endl; }
  void whassup() const { cout << "whassup " << id << endl; }
private:
  int const id;
};

class ShowSecondLife
  : public ShowLife {
public:
  ShowSecondLife(int id) : ShowLife(id), id(id)
    { cout << "creating second " << id << endl; }
  ~ShowSecondLife() { cout << "destroying second " << id << endl; }
private:
  int const id;
};

class UnrelatedLife
  : public ShowLife {
public:
  UnrelatedLife() : ShowLife(0) { }
};

int main() {
  {
    shared_ptr<ShowLife> sp=new_shared_ptr(new ShowLife(3));
    sp->whassup();
    shared_ptr<ShowLife> sp2;
    shared_ptr<ShowLife> sp3(sp);
    sp3->whassup();
    sp2=sp3;
    sp2->whassup();
    sp->whassup();
  }
  {
    shared_ptr<ShowLife> sp=new_shared_ptr(new ShowSecondLife(4));
    sp->whassup();
    shared_ptr<ShowLife> sp2;
    shared_ptr<ShowLife> sp3(sp);
    shared_ptr<ShowLife> sp4=new_shared_ptr(new ShowSecondLife(5));
    sp4.reset();
    sp3->whassup();
    sp2=sp3;
    sp2->whassup();
    sp->whassup();
    if (shared_ptr_dynamic_cast<ShowSecondLife>(sp).is_nonnull())
      cout << "made a correct dynamic cast" << endl;
    else
      cout << "ERROR: avoided a correct dynamic cast" << endl;
    shared_ptr_dynamic_cast<ShowSecondLife>(sp)->whassup();

    if (not shared_ptr_dynamic_cast<ShowSecondLife>(
              new_shared_ptr(new UnrelatedLife)).is_nonnull())
      cout << "correctly avoided a wrong dynamic cast" << endl;
    else
      cout << "ERROR: could not avoid a wrong dynamic cast" << endl;

    ShowSecondLife *free_second_life=new ShowSecondLife(12);
    {
      shared_ptr<ShowSecondLife> weak_second_life=
        weak_shared_ptr(free_second_life);
      weak_second_life->whassup();
      shared_ptr<ShowSecondLife> second_weak_second_life=weak_second_life;
    }
    free_second_life->whassup();
    delete free_second_life;
  }
  ShowLife(99999);
}
