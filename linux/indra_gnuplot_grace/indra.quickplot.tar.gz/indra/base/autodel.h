#ifndef BASE_AUTODEL_HEADER
#define BASE_AUTODEL_HEADER

#include "metaprog.h"

/* The following are slightly-smart pointers that feature single-pointer
 * auto-deletion only (no ownership transfer or reference counting).  The
 * templated class "auto_del_ptr" can be used as a naked C++ pointer, but it
 * will take care of deleting its contents at its own destruction; it can only
 * be given content at construction.  The templated class "late_auto_del_ptr"
 * is identical to "auto_del_ptr" but can be given content either at
 * construction or later; it can thus be default-constructed as a null pointer,
 * then assigned a naked C++ pointer; it also supports re-assigning of a naked
 * C++ pointer, which deletes its old content, if any, before taking ownership
 * of the new content. */

template <typename Type>
class late_auto_del_ptr {
public:
  typedef typename NoQualifier<Type>::Result UnqualifiedType;
  late_auto_del_ptr(Type *ptr) : ptr(ptr) { } // give it a fresh "new" pointer
  late_auto_del_ptr() : ptr(0) { } // default null
  ~late_auto_del_ptr() { delete ptr; } // automatic deletion
  operator Type *() const { return ptr; } // automatic conversion to pointer
  UnqualifiedType operator*() const { return *ptr; } // dereference
  Type *operator->() const { return ptr; } // dereference
  // the following templated method allows to retrieve a pointer to a more
  // concrete type from an auto_del_ptr whose declared type is a more abstract
  // type; i.e., if an auto_del_ptr "adp" is declared as "auto_del_ptr<A>", and
  // "B" is derived from "A", and we know that the auto_del_ptr points to an
  // "A" object that is of type "B" or derived, we can retrieve a pointer to
  // "B" from "adp" with the expression "adp.as<B>()"
  template <typename ConcreteType>
    ConcreteType *as() const { return dynamic_cast<ConcreteType *>(ptr); }
  late_auto_del_ptr<Type> &operator=(Type *new_ptr) {
    delete ptr;
    ptr=new_ptr;
    return *this;
  }
private:
  Type *ptr;
  // forbidden methods:
  late_auto_del_ptr(late_auto_del_ptr<Type> const &); // no copying
  late_auto_del_ptr<Type> &operator=(late_auto_del_ptr<Type> const &);
                                 // no assigning from another late_auto_del_ptr
};

template <typename Type>
class auto_del_ptr
  : public late_auto_del_ptr<Type> {
public:
  auto_del_ptr(Type *ptr) : late_auto_del_ptr<Type>(ptr) { }
private:
  auto_del_ptr<Type> &operator=(Type *); // no assigning
};

#endif
