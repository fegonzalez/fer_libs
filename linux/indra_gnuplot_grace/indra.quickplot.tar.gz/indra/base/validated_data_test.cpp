#include "validated_data.h"
using namespace std;

struct st_test{

st_test(int const &i, char a): int_test(i), char_test(a) {}

int int_test;
char char_test;

friend ostream &operator<<(ostream &os,st_test a);
};


ostream& operator<<(ostream &os,st_test a)
{

   return os << a.int_test <<":"
             << a.char_test;
}




int main (void)
{

  validated_data <bool> test_bool(true,ISVALID);
  validated_data <scalar> test_scalar (3.0, OTHER);
  validated_data <float> test_float(3.0, OTHER);
  validated_data <double> test_double(3.0, OTHER);
  validated_data <char> test_char('a', OTHER);
  validated_data <int> test_int(3, OTHER);
  validated_data <short> test_short(3, OTHER);
  st_test test_str(42,'P');
  validated_data <st_test> test_st(test_str,OTHER);



  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<scalar>                              //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;
  cout << "\n Created a validated_data called test_scalar 3.0 in value and 'OTHER' "
       << endl ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar 13673.1 in value and 'ISVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (13673.1, ISVALID ) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar 3673.498 in value and 'NOVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (3673.498, NOVALID) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar 3673.49 in value and 'NOVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (3673.49, NOVALID) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar 33363.198 in value and 'ISVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (33363.198, ISVALID ) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar -32768.987 in value and 'NOVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (-32768.987, NOVALID) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar -32768.88 in value and 'NOVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (-32768.88, NOVALID) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar -32768.9 in value and 'NOVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (-32768.9, NOVALID) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar -16784.0  in value and 'ISVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (-16784.0,ISVALID) ;
  cout << test_scalar <<endl ;





  cout << "\n Created a validated_data called test_scalar 0.0 in value and 'OTHER' "
       << endl ;
  test_scalar = validated_data <scalar> (0.0, OTHER) ;
  cout << test_scalar <<endl ;




  cout << "\n Created a validated_data called test_scalar 0.0 in value and 'NOVALID' "
       << endl ;
  test_scalar = validated_data <scalar> (0.0, NOVALID) ;
  cout << test_scalar <<endl ;


  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<float>                               //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;

  cout << "\n Created a validated_data called test_float 3.0 in value and 'OTHER' "
       << endl ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float 13673.1 in value and 'ISVALID' "
       << endl ;
  test_float = validated_data <float> (13673.1f, ISVALID ) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float 3673.498 in value and 'NOVALID' "
       << endl ;
  test_float = validated_data <float> (3673.498f, NOVALID) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float 3673.49 in value and 'NOVALID' "
       << endl ;
  test_float = validated_data <float> (3673.49f, NOVALID) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float 33363.198 in value and 'ISVALID' "
       << endl ;
  test_float = validated_data <float> (33363.198f, ISVALID ) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float -32768.987 in value and 'NOVALID' "
       << endl ;
  test_float = validated_data <float> (-32768.987f, NOVALID) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float -32768.88 in value and 'NOVALID' "
       << endl ;
  test_float = validated_data <float> (-32768.88f, NOVALID) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float -32768.9 in value and 'NOVALID' "
       << endl ;
  test_float = validated_data <float> (-32768.9f, NOVALID) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float -16784.0  in value and 'ISVALID' "
       << endl ;
  test_float = validated_data <float> (-16784.0,ISVALID) ;
  cout << test_float <<endl ;





  cout << "\n Created a validated_data called test_float 0.0 in value and 'OTHER' "
       << endl ;
  test_float = validated_data <float> (0.0, OTHER) ;
  cout << test_float <<endl ;




  cout << "\n Created a validated_data called test_float 0.0 in value and 'NOVALID' "
       << endl ;
  test_float = validated_data <float> (0.0, NOVALID) ;
  cout << test_float <<endl ;



  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<bool>                                //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;



  cout << "\n Created a validated_data called test_bool true in value and 'OTHER' "
       << endl ;
  cout << test_bool <<endl ;




  cout << "\n Created a validated_data called test_bool true in value and 'ISVALID' "
       << endl ;
  test_bool = validated_data <bool> (true, ISVALID ) ;
  cout << test_bool <<endl ;




  cout << "\n Created a validated_data called test_bool true in value and 'NOVALID' "
       << endl ;
  test_bool = validated_data <bool> (true, NOVALID) ;
  cout << test_bool <<endl ;




  cout << "\n Created a validated_data called test_bool false in value and 'OTHER' "
       << endl ;
  test_bool = validated_data <bool> (false,OTHER) ;
  cout << test_bool <<endl ;



  cout << "\n Created a validated_data called test_bool false in value and 'ISVALID' "
       << endl ;
  test_bool = validated_data <bool> (false, ISVALID ) ;
  cout << test_bool <<endl ;




  cout << "\n Created a validated_data called test_bool false in value and 'NOVALID' "
       << endl;
  test_bool = validated_data <bool> (false, NOVALID) ;
  cout << test_bool <<endl;


  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<double>                              //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;


  cout << "\n Created a validated_data called test_double 3.0 in value and 'OTHER' "
       << endl ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double 13673.1 in value and 'ISVALID' "
       << endl ;
  test_double = validated_data <double> (13673.1, ISVALID ) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double 3673.498 in value and 'NOVALID' "
       << endl ;
  test_double = validated_data <double> (3673.498, NOVALID) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double 3673.49 in value and 'NOVALID' "
       << endl ;
  test_double = validated_data <double> (3673.49, NOVALID) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double 33363.198 in value and 'ISVALID' "
       << endl ;
  test_double = validated_data <double> (33363.198, ISVALID ) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double -32768.987 in value and 'NOVALID' "
       << endl ;
  test_double = validated_data <double> (-32768.987, NOVALID) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double -32768.88 in value and 'NOVALID' "
       << endl ;
  test_double = validated_data <double> (-32768.88, NOVALID) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double -32768.9 in value and 'NOVALID' "
       << endl ;
  test_double = validated_data <double> (-32768.9, NOVALID) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double -16784.0  in value and 'ISVALID' "
       << endl ;
  test_double = validated_data <double> (-16784.0,ISVALID) ;
  cout << test_double <<endl ;





  cout << "\n Created a validated_data called test_double 0.0 in value and 'OTHER' "
       << endl ;
  test_double = validated_data <double> (0.0, OTHER) ;
  cout << test_double <<endl ;




  cout << "\n Created a validated_data called test_double 0.0 in value and 'NOVALID' "
       << endl ;
  test_double = validated_data <double> (0.0, NOVALID) ;
  cout << test_double <<endl ;


  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<char>                              //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;


  cout << "\n Created a validated_data called test_char 'a' in value and 'OTHER' "
       << endl ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char 'b' in value and 'ISVALID' "
       << endl ;
  test_char = validated_data <char> ('b', ISVALID ) ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char 'X'in value and 'NOVALID' "
       << endl ;
  test_char = validated_data <char> ('X', NOVALID) ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char 'Y' in value and 'NOVALID' "
       << endl ;
  test_char = validated_data <char> ('Y', NOVALID) ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char '2' in value and 'ISVALID' "
       << endl ;
  test_char = validated_data <char> ('2', ISVALID ) ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char '4' in value and 'OTHER' "
       << endl ;
  test_char = validated_data <char> ('4', OTHER) ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char 0x31 in value and 'NOVALID' "
       << endl ;
  test_char = validated_data <char> (0x31, NOVALID) ;
  cout << test_char <<endl ;




  cout << "\n Created a validated_data called test_char 0x41 in value and 'ISVALID' "
       << endl ;
  test_char = validated_data <char> (0x41, ISVALID) ;
  cout << test_char <<endl ;





  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<int>                              //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;
  cout << "\n Created a validated_data called test_int 3 in value and 'OTHER' "
       << endl ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int 65535 in value and 'ISVALID' "
       << endl ;
  test_int = validated_data <int> (65535, ISVALID ) ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int 100000 in value and 'NOVALID' "
       << endl ;
  test_int = validated_data <int> (100000, NOVALID) ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int 198 in value and 'ISVALID' "
       << endl ;
  test_int = validated_data <int> (198, ISVALID ) ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int -3 in value and 'NOVALID' "
       << endl ;
  test_int = validated_data <int> (-3, NOVALID) ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int -32768 in value and 'NOVALID' "
       << endl ;
  test_int = validated_data <int> (-32768, NOVALID) ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int -16784  in value and 'ISVALID' "
       << endl ;
  test_int = validated_data <int> (-16784,ISVALID) ;
  cout << test_int <<endl ;





  cout << "\n Created a validated_data called test_int 0 in value and 'OTHER' "
       << endl ;
  test_int = validated_data <int> (0, OTHER) ;
  cout << test_int <<endl ;




  cout << "\n Created a validated_data called test_int 0 in value and 'NOVALID' "
       << endl ;
  test_int = validated_data <int> (0, NOVALID) ;
  cout << test_int <<endl ;



  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<short>                              //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;
  cout << "\n Created a validated_data called test_short 3 in value and 'OTHER' "
       << endl ;
  cout << test_short <<endl ;




  cout << "\n Created a validated_data called test_short 65535 in value and 'ISVALID' "
       << endl ;
  test_short = validated_data <short> ((short int)(65535), ISVALID ) ;
  cout << test_short <<endl ;




  cout << "\n Created a validated_data called test_short 100000 in value and 'NOVALID' "
       << endl ;
  test_short = validated_data <short> ((short int)(100000), NOVALID) ;
  cout << test_short <<endl ;




  cout << "\n Created a validated_data called test_short 198 in value and 'ISVALID' "
       << endl ;
  test_short = validated_data <short> (198, ISVALID ) ;
  cout << test_short <<endl ;




  cout << "\n Created a validated_data called test_short -3 in value and 'NOVALID' "
       << endl ;
  test_short = validated_data <short> (-3, NOVALID) ;
  cout << test_short <<endl ;




  cout << "\n Created a validated_data called test_short -32768 in value and 'NOVALID' "
       << endl ;
  test_short = validated_data <short> (-32768, NOVALID) ;
  cout << test_short <<endl ;




  cout << "\n Created a validated_data called test_short -16784  in value and 'ISVALID' "
       << endl ;
  test_short = validated_data <short> (-16784,ISVALID) ;
  cout << test_short <<endl ;





  cout << "\n Created a validated_data called test_short 0 in value and 'OTHER' "
       << endl ;
  test_short = validated_data <short> (0, OTHER) ;
  cout << test_short <<endl ;



  cout << "\n Created a validated_data called test_short 0 in value and 'NOVALID' "
       << endl ;
  test_short = validated_data <short> (0, NOVALID) ;
  cout << test_short <<endl ;


  cout<<"////////////////////////////////////////////////////////////////////////////"<<endl
      <<"//            Pruebas validated_data<st_test>                             //"<<endl
      <<"////////////////////////////////////////////////////////////////////////////"<<endl;

  cout << "\n Created a validated_data called test_st (type st_test)= 42:Q in value and 'NOVALID' "
       << endl ;
  test_st = validated_data<st_test> (test_str,NOVALID);
  cout << test_st <<endl ;



  cout << "\n Created a validated_data called test_st (type st_test)= 43:R in value and 'OTHER' "
       << endl ;
  test_str=st_test(43,'R');
  test_st = validated_data<st_test> (test_str,OTHER);
  cout << test_st <<endl ;



  cout << "\n Created a validated_data called test_st (type st_test)= 53:@ in value and 'ISVALID' "
       << endl ;
  test_str=st_test(53,'@');
  test_st = validated_data<st_test> (test_str,ISVALID);
  cout << test_st <<endl ;



  cout << "\n Created a validated_data called test_st (type st_test)= 143:s in value and 'OTHER' "
       << endl ;
  test_str=st_test(143,'s');
  test_st = validated_data<st_test> (test_str,OTHER);
  cout << test_st <<endl ;




  return 0;



}
