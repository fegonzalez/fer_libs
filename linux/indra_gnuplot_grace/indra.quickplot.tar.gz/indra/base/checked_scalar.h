#ifndef CHECKED_SCALAR_HEADER_
#define CHECKED_SCALAR_HEADER_

#include <iostream>



#ifdef SIMDEBUG_NAN  // Compilation flag for checking NaN's

#include <iostream>

#ifdef SIMOS_VXWORKS
#include <vxWorks.h>
#include <private/mathP.h>
#endif

#ifdef SIMOS_SUNOS
#include <ieeefp.h>
#endif

#ifdef SIMKERNEL_LINUX
#include <cmath>
#endif

   class scalar {
     public:
      scalar () ;
      scalar(double val_ini) : value(val_ini) { check();}
      scalar(int val_ini) : value(val_ini) { check(); }
      operator double const() const { check(); return value;  }
      scalar &operator=(double arg) { value=arg; check(); return *this; }
      scalar &operator+=(double arg) { value+=arg; check(); return *this; }
      scalar &operator-=(double arg) { value-=arg; check(); return *this; }
      scalar &operator*=(double arg) { value*=arg; check(); return *this; }
      scalar &operator/=(double arg) { value/=arg; check(); return *this; }
      static void set_throw(); // throw exception when a NaN appears
      static void unset_throw(); // do nothing when a NaN appears
      static void set_reset_value_nan();
      static void set_reset_value(double new_reset_value);
     private:

      // fpclass(value) returns 0 for NaN with signal, 1 for NaN without
      // signal, 2 for negative infinite and 3 for positive infinite
#ifdef SIMOS_SUNOS
      void check() const { if (fpclass(value)<=3) error(); }
#endif
#ifdef SIMOS_VXWORKS
      void check() const { if (fpTypeGet (value, 0)>=INF) error(); }
#endif
#ifdef SIMKERNEL_LINUX
      void check() const { if (isnan(value) or isinf(value)) error(); }
#endif

      void error() const;
      mutable double value; // is mutable in order to change the value to
                            // error()
   };

   extern bool scalar_throw_on_error;
   extern double scalar_reset_value; // scalar::error() does value=reset_value

   inline std::ostream &operator<<(std::ostream &os, scalar arg)
   { return os << double(arg); }
   inline std::istream &operator>>(std::istream &is, scalar &arg)
   {
      double arg_d;
      is >> arg_d;
      arg=scalar(arg_d);
      return is;
   }

   inline scalar operator+(scalar arg) { return scalar(+double(arg)); }
   inline scalar operator-(scalar arg) { return scalar(-double(arg)); }

   inline scalar operator+(scalar arg1, scalar arg2)
   { return scalar(double(arg1)+double(arg2)); }
   inline scalar operator-(scalar arg1, scalar arg2)
   { return scalar(double(arg1)-double(arg2)); }
   inline scalar operator*(scalar arg1, scalar arg2)
   { return scalar(double(arg1)*double(arg2)); }
   inline scalar operator/(scalar arg1, scalar arg2)
   { return scalar(double(arg1)/double(arg2)); }
   inline bool operator>(scalar arg1, scalar arg2)
   { return double(arg1)>double(arg2); }
   inline bool operator>=(scalar arg1, scalar arg2)
   { return double(arg1)>=double(arg2); }
   inline bool operator<(scalar arg1, scalar arg2)
   { return double(arg1)<double(arg2); }
   inline bool operator<=(scalar arg1, scalar arg2)
   { return double(arg1)<=double(arg2); }


   inline scalar operator+(double arg1, scalar arg2)
   { return scalar(double(arg1)+double(arg2)); }
   inline scalar operator-(double arg1, scalar arg2)
   { return scalar(double(arg1)-double(arg2)); }
   inline scalar operator*(double arg1, scalar arg2)
   { return scalar(double(arg1)*double(arg2)); }
   inline scalar operator/(double arg1, scalar arg2)
   { return scalar(double(arg1)/double(arg2)); }
   inline bool operator>(double arg1, scalar arg2)
   { return double(arg1)>double(arg2); }
   inline bool operator>=(double arg1, scalar arg2)
   { return double(arg1)>=double(arg2); }
   inline bool operator<(double arg1, scalar arg2)
   { return double(arg1)<double(arg2); }
   inline bool operator<=(double arg1, scalar arg2)
   { return double(arg1)<=double(arg2); }

   inline scalar operator+(scalar arg1, double arg2)
   { return scalar(double(arg1)+double(arg2)); }
   inline scalar operator-(scalar arg1, double arg2)
   { return scalar(double(arg1)-double(arg2)); }
   inline scalar operator*(scalar arg1, double arg2)
   { return scalar(double(arg1)*double(arg2)); }
   inline scalar operator/(scalar arg1, double arg2)
   { return scalar(double(arg1)/double(arg2)); }
   inline bool operator>(scalar arg1, double arg2)
   { return double(arg1)>double(arg2); }
   inline bool operator>=(scalar arg1, double arg2)
   { return double(arg1)>=double(arg2); }
   inline bool operator<(scalar arg1, double arg2)
   { return double(arg1)<double(arg2); }
   inline bool operator<=(scalar arg1, double arg2)
   { return double(arg1)<=double(arg2); }

   inline scalar operator+(int arg1, scalar arg2)
   { return scalar(double(arg1)+double(arg2)); }
   inline scalar operator-(int arg1, scalar arg2)
   { return scalar(double(arg1)-double(arg2)); }
   inline scalar operator*(int arg1, scalar arg2)
   { return scalar(double(arg1)*double(arg2)); }
   inline scalar operator/(int arg1, scalar arg2)
   { return scalar(double(arg1)/double(arg2)); }
   inline bool operator>(int arg1, scalar arg2)
   { return double(arg1)>double(arg2); }
   inline bool operator>=(int arg1, scalar arg2)
   { return double(arg1)>=double(arg2); }
   inline bool operator<(int arg1, scalar arg2)
   { return double(arg1)<double(arg2); }
   inline bool operator<=(int arg1, scalar arg2)
   { return double(arg1)<=double(arg2); }

   inline scalar operator+(scalar arg1, int arg2)
   { return scalar(double(arg1)+double(arg2)); }
   inline scalar operator-(scalar arg1, int arg2)
   { return scalar(double(arg1)-double(arg2)); }
   inline scalar operator*(scalar arg1, int arg2)
   { return scalar(double(arg1)*double(arg2)); }
   inline scalar operator/(scalar arg1, int arg2)
   { return scalar(double(arg1)/double(arg2)); }
   inline bool operator>(scalar arg1, int arg2)
   { return double(arg1)>double(arg2); }
   inline bool operator>=(scalar arg1, int arg2)
   { return double(arg1)>=double(arg2); }
   inline bool operator<(scalar arg1, int arg2)
   { return double(arg1)<double(arg2); }
   inline bool operator<=(scalar arg1, int arg2)
   { return double(arg1)<=double(arg2); }

   template <typename type>
   inline type if_then_else(bool condition, type true_val, type false_val)
   { if (condition) return true_val; else return false_val;};

   inline scalar if_then_else(bool condition, scalar true_val, scalar false_val)
   { if (condition) return true_val; else return false_val;};
   inline scalar if_then_else(bool condition, scalar true_val, double false_val)
   { if (condition) return true_val; else return false_val;};
   inline scalar if_then_else(bool condition, double true_val, scalar false_val)
   { if (condition) return true_val; else return false_val;};
   inline scalar if_then_else(bool condition, scalar true_val, int false_val)
   { if (condition) return true_val; else return false_val;};
   inline scalar if_then_else(bool condition, int true_val, scalar false_val)
   { if (condition) return true_val; else return false_val;};

#endif



#endif
