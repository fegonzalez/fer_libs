#include "real_time.h"
#include <iostream>

using namespace RealTime;
using namespace std;

void timer_test()
{
  
  Timer<TestClock> timer_test;


  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  
  timer_test.reset();

  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;
  std::cout<< "t: "<< timer_test.read() 
	   << std::endl;



};

void statistic_timer_test()
{

  StatisticTimer<TestClock> timer_test;

  std::cout<<"\n CONSTRUCTION: "<< std::endl;
  std::cout<< " TOTAL: "<< timer_test.total
	   << " AVERAGE: "<< timer_test.average
	   << " MIN: "<< timer_test.min_value
	   << " MAX: "<< timer_test.max_value
	   << " LAST :" << timer_test.last_value
	   << " CYCLE: " << timer_test.cycles
	   << std::endl;
  

  std::cout<<"\n RUN: "<< std::endl;


  for(int i = 0; i <= 10; i++ ){

  timer_test.start_timer();
  for (int j=0; j<=i; j++){    
    TestClock::get_time();    
  }

  timer_test.stop_timer();

  std::cout<< " TOTAL: "<< timer_test.total
	   << " AVERAGE: "<< timer_test.average
	   << " MIN: "<< timer_test.min_value
	   << " MAX: "<< timer_test.max_value
	   << " LAST :" << timer_test.last_value
	   << " CYCLE: " << timer_test.cycles
	   << std::endl;

  }


};

int main (void)
{
  timer_test();
  statistic_timer_test();

  return (0);


}
