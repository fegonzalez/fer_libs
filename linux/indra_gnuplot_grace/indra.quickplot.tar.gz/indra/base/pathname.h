#ifndef INDRA_BASE_PATHNAME_HEADER_
#define INDRA_BASE_PATHNAME_HEADER_

#include <memory>
#include <list>
#include <string>
#include <iostream>

/* The class PathNamePolicy represents a policy in getting from an incomplete
 * file name (a "relative file name") the absolute file name (the "pathname").
 * The method pathname() returns the pathname corresponding to the supplied
 * relative file name according to the policy.  A concrete policy must supply
 * an implementation for the protected abstract method absolute_pathname().
 * The pathname() also checks whether the file specified by the pathname
 * returned by absolute_pathname() exists, and throws an exception otherwise;
 * if the file does indeed exists, it returns that pathname.
 *
 * The class-static automatic pointer "global" serves as a default pathname
 * policy; it is initialised to IdentityPathNamePolicy. */
class PathNamePolicy {
public:
  virtual ~PathNamePolicy() { }
  std::string pathname(std::string const &relative_pathname) const {
    std::string result(absolute_pathname(relative_pathname));
    if (not file_exists(result))
      {
	std::cout << "file " << relative_pathname << " not found" << std::endl;
	throw "file "+relative_pathname+" not found";
      }
    else
      return result;
  }
  static std::auto_ptr<PathNamePolicy> &global();
protected:
  virtual std::string
    absolute_pathname(std::string const &relative_pathname) const=0;
  static bool file_exists(std::string pathname);
};

/* Convenience function-like macro to query the pathname using the default
 * (global) policy.  This function-like macro returns a "char const *", as
 * demanded by most of the ill-defined STL file-related interface.  The
 * real-function approach below does not work, since the compiler is allowed to
 * (and indeed does) deallocate the returned "char const *" when the
 * "std::string" is destroyed, that is just before returning. */
#define global_pathname(relative_pathname) \
(PathNamePolicy::global()->pathname(relative_pathname).c_str())
// std::string global_pathname(std::string const &relative_pathname) {
//   return PathNamePolicy::global()->pathname(relative_pathname);
// }

/* A pathname policy that simply returns the relative pathname, to be used when
 * the pathname are always absolute, or relative to the CWD. */
class IdentityPathNamePolicy
  : public PathNamePolicy {
public:
  std::string absolute_pathname(std::string const &relative_pathname) const
  { return relative_pathname; }
};

/* A pathname policy that adds a prefix in front of the relative pathname.  It
 * also inserts a slash between the prefix and the relative pathname, just in
 * case. */
class PrefixPathNamePolicy
  : public PathNamePolicy {
public:
  PrefixPathNamePolicy(std::string const &prefix)
    : prefix(prefix) { }
  std::string absolute_pathname(std::string const &relative_pathname) const
  { return prefix+"/"+relative_pathname; }
private:
  std::string const prefix;
};

/* A pathname policy that is similar to PrefixPathNamePolicy, but is given a
 * list of prefixes instead of a single prefix.  The first prefix that yields a
 * pathname corresponding to an existing file is chosen.  If no prefix is
 * appropriate, the method PathNamePolicy::pathname() will throw an
 * exception. */
class AlternativePrefixPathNamePolicy
  : public PathNamePolicy {
public:
  AlternativePrefixPathNamePolicy(std::list<std::string> const &prefix_list);
  std::string absolute_pathname(std::string const &relative_pathname) const;
private:
  std::list<std::string> const prefix_list;
};

/* A pathname that filters other pathname policies looking for substrings to
 * replace with other substrings.  This pathname policy is intended for
 * replacing normal files with files for testing.  The "unfiltered_policy" must
 * find an existing pathname for FilteredPathNamePolicy to filter it.  If
 * "unfiltered_policy" finds an existing pathname, FilteredPathNamePolicy will
 * lookup all its substitution list, searching for a rule that matches the
 * returned pathname, and that yields an existing file.  If it finds it, it
 * applies it and returns the modified pathname; otherwise, it returns the
 * original pathname unmodified. */
class FilteredPathNamePolicy // FIXME: untested yet
  : public PathNamePolicy {
public:
  typedef std::list<std::pair<std::string, std::string> > SubstitutionList;
  FilteredPathNamePolicy(PathNamePolicy const *unfiltered_policy,
                         SubstitutionList const &substitution_list)
    : unfiltered_policy(unfiltered_policy),
      substitution_list(substitution_list)
  { }
  ~FilteredPathNamePolicy() { delete unfiltered_policy; }
protected:
  std::string absolute_pathname(std::string const &relative_pathname) const;
private:
  PathNamePolicy const *const unfiltered_policy;
  SubstitutionList const substitution_list;
};

#endif
