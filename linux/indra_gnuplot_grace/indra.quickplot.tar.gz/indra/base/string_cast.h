#ifndef _STRING_CAST_HEADER
#define _STRING_CAST_HEADER

#include <string>
#include <sstream>
#include <iomanip>
#include "scalar.h"

std::string integer_to_string(int);

int string_to_integer(std::string);

scalar string_to_scalar(std::string);

// convert any type to its string text representation; bools are represented as
// "true" or "false"
template <typename T>
std::string to_string(T const &t) {
  std::ostringstream ss;
  ss << std::boolalpha << t;
  return ss.str();
}

// convert any type to its string text representation with the
// specified precision (in "fixed" notation); bools are represented as
// "true" or "false"
template <typename T>
std::string to_string(T const &t, unsigned int precision) {
  std::ostringstream ss;
  ss << std::boolalpha << std::fixed << std::setprecision(precision) << t;
  return ss.str();
}

// interprent a string as a value of the specified type; bools must be
// represented as "true" or "false", not "1" or "0"; if "1" or "0" must be
// used, convert to "int" instead of "bool" (i.e., "bool(string_to<int>())"
// instead of "string_to<bool>()")
template <typename T>
T string_to(std::string const &s) {
  std::istringstream ss(s);
  T result;
  ss >> std::boolalpha >> result;
  return result;
}

#endif
