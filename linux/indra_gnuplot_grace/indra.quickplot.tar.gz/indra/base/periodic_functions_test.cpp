#include <iostream>
#include <string>
#include <math.h>
#include <cstdlib>
#include "../base/base.h"
#include "../base/periodic_functions.h"

using std::cout;
using std::endl;

scalar sample_function(scalar t) {

 scalar t12=15.;
 scalar period=5.;

return 10*t+100*exp(-log(2.)/t12*t)*cos(2.*M_PI*t/period+.4*scalar(rand())/scalar(RAND_MAX));
}
int main() {

//Check out in diferenets compilers
return 0;


 srand(0);

// PeriodicFunctions periodic(20,500,1.);
 PeriodicFunctions periodic;


 scalar t0=0;
 scalar tf=32;
 int size=200;

 scalar dt=(tf-t0)/scalar(size);
 scalar t=t0;
 for (int i=0;i<size;i++) {
  periodic.add_point(t,sample_function(t));
  t+=dt;
 }

 periodic.compute();

 std::cout << "#t12 = " << periodic.get_t12() << std::endl;
 std::cout << "#period = " << periodic.get_period() << std::endl;

 t=t0;
 for (int i=0;i<size;i++) {
  std::cout << t << '\t'
            << sample_function(t) << '\t'
            << periodic.get_spline(t) << '\t'
            << periodic.get_peaks()->get_y(float(t)) << '\t'
            << periodic.get_amplitude(t) << '\t'
            << periodic.get_mean_line(t) << '\t'
            << periodic.get_mean_exponential_line(t) << '\t'
            << periodic.get_mean_poly_2(t) << '\t'
            << std::endl;
  t+=dt;
 }


 //periodic.get_peaks()->print(std::string("peaks.dat").c_str());
return 0;

}
