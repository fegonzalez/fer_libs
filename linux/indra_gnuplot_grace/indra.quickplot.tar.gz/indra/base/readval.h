#ifndef INDRA_BASE_READVAL_HEADER_
#define INDRA_BASE_READVAL_HEADER_

#include <stdexcept>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>


class ReadValues {
public:
  ReadValues(std::string file);

  template <typename T>
  T value(std::string name) const {
    T value;
    if (map_name_value.find(name)==map_name_value.end())
      throw std::runtime_error("value name not found: "+name);
    std::istringstream iss(map_name_value.find(name)->second);
    iss >> value;
    if (iss.fail())
      throw std::runtime_error("value syntax error: "+ map_name_value.find(name)->second);
    return value;
  }
private:
  std::map<std::string, std::string> map_name_value;
};


std::string find_substring(std::string const data,std::string const init_mark,
			   std::string const final_mark="\"");


#endif
