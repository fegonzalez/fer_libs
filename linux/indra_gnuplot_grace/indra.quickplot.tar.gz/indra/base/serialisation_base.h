#ifndef INDRA_BASE_SERIALISATION_BASE_HEADER_
#define INDRA_BASE_SERIALISATION_BASE_HEADER_

#include "geometry.h"
#include "base.h"
#include "serialisation.h"

to_be_serialized_as_binary(long double);
to_be_serialized_as_binary(double);
to_be_serialized_as_binary(float);
to_be_serialized_as_binary(long long int);
to_be_serialized_as_binary(long int);
to_be_serialized_as_binary(int);
to_be_serialized_as_binary(unsigned int);
to_be_serialized_as_binary(bool);
to_be_serialized_as_binary(char);
to_be_serialized_as_binary(unsigned char);

template <typename T, typename Archive>
void serialize(Archive &a, auto_init<T> &t) { serialize_binary(a, t); }

to_be_serialized_as_binary(Vector);
to_be_serialized_as_binary(Matrix);
to_be_serialized_as_binary(Quaternion);

#endif
