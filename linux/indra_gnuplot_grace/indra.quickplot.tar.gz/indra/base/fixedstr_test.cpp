#include <iostream>
#include "fixedstr.h"

using namespace std;

#define show_and_count(x) \
cout << "\"" << x.to_string() << "\" is " << x.length() << " chars" << endl

int main() {
  FixedString<15> fcs("from C");
  show_and_count(fcs);
  fcs+=" string";
  show_and_count(fcs);
  fcs="overwritten";
  show_and_count(fcs);

  FixedString<15> fs(string("forty"));
  show_and_count(fs);
  fs+=string("-two");
  show_and_count(fs);
  try {
    fs.append(string("is the answer"));
  }
  catch (...) {
    cout << "exception caught" << endl;
  }
  for (unsigned int i=0; i<fs.length(); ++i)
    cout << fs[i] << " ";
  cout << endl;
  fs=string("six times nine");
  show_and_count(fs);
  cout << fs << endl;

  FixedString<12> empty;
  show_and_count(empty);
}
