#include "earth.h"
#include <cmath>

Earth const WGS84(6378137., 6356752.3142);

/* lon_lat_alt ***************************************************************/

std::ostream &operator<<(std::ostream &os, lat_lon_alt lla)
{
   return os << lla.lat() << " : " << lla.lon() << " : " << lla.alt();
}

std::istream &operator>>(std::istream &is, lat_lon_alt &lla)
{
    scalar lat, lon, alt;
    is >> lat >> lon >> alt;
    lla = lat_lon_alt(lat, lon, alt);
    return is;
}

Quaternion ref_local_horizon(lat_lon_alt pos_geographic)
{
   scalar lambda=deg_to_rad(pos_geographic.lon());
   scalar phi=deg_to_rad(pos_geographic.lat());
/*   return inv(Quaternion(Matrix(-sin(phi)*cos(lambda), 
				   -sin(phi)*sin(lambda), 
				      -cos(phi),
				-sin(lambda),          
				   cos(lambda),           
				      0,
				cos(phi)*cos(lambda),  
				   cos(phi)*sin(lambda),  
				      -sin(phi)))); */
   Quaternion result = qpsithetaphi(lambda, -PI/2-phi, 0);
   return result ;
}

/* Earth ********************************************************************/

lat_lon_alt Earth::inertial_to_earth(Vector pos_inertial) const
{
    if (norm(pos_inertial) < 0.5)
    {
        return lat_lon_alt(0.0, 0.0, 6758000.0);
    }
    
   scalar x=pos_inertial.x();
   scalar y=pos_inertial.y();
   scalar z=pos_inertial.z();
   scalar R=norm(pos_inertial);
   scalar lambda=arcsincos(y, x);
   scalar phi_prime=arcsincos(z, square_root(square(x)+square(y)));
   scalar delta_prime=
     e_2*sin(phi_prime)*cos(phi_prime)/(1.-e_2*square(cos(phi_prime)));
   scalar R_prime_e=b*(1.
		       +1./2.*e_2*square(cos(phi_prime))
		       +3./8.*square(e_2*square(cos(phi_prime))));
   scalar sigma=R_prime_e*delta_prime/R;
   scalar h=(R-R_prime_e)*(1.-delta_prime*sigma/2.);
   scalar phi=phi_prime+sigma;
   return lat_lon_alt(rad_to_deg(phi), rad_to_deg(lambda), h);
}

Vector Earth::earth_to_inertial(lat_lon_alt pos_geographic) const
{
   scalar lambda=deg_to_rad(pos_geographic.lon());
   scalar phi=deg_to_rad(pos_geographic.lat());
   scalar h=pos_geographic.alt();
   scalar delta=e_2*sin(phi)*cos(phi)/(1.-e_2*square(sin(phi)));
   scalar phi_second=phi-delta;
   scalar R_e=b*(1.
		 +1./2.*e_2*square(cos(phi_second))
		 +3./8.*square(e_2*square(cos(phi_second))));
   scalar sigma=R_e*delta/(R_e+h);
   scalar R=R_e+h*(1.-delta*sigma/2.);
   scalar phi_prime=phi-sigma;
   scalar x=R*cos(phi_prime)*cos(lambda);
   scalar y=R*cos(phi_prime)*sin(lambda);
   scalar z=R*sin(phi_prime);
   return Vector(x, y, z);
}
