#include "initial_conditions.h"
#include <stdexcept>
#include <sstream>
#include <iostream>

using std::string;
using std::ifstream;
using std::istringstream;
using std::map;
using std::cout;
using std::endl;
using std::runtime_error;

/* InitialConditions ******************************************************/

InitialConditions::InitialConditions(string file)
: file(file)
{
   // cout << "reading the initial conditions in the file" << file << endl;
   ifstream in(file.c_str());
   while (in) {
      string name;
      string line_string;
      getline(in, line_string);
      istringstream line(line_string);
      char c=' ';
      line >> c;
      while (line && c!='=') {
	 if ((c>='a' && c<='z')
	     || (c>='A' && c<='Z')
	     || (c>='0' && c<='9')
	     || c=='_' || c=='.')
	   name+=c;
	 line >> c;
      }
      if (c!='=')
	continue;
      scalar value;
      line >> value;
//      cout << "  " << name << " = " << value << endl;
      map_name_value[name]=value;
   }
}

scalar InitialConditions::operator[](string name) const
{
   map<string, scalar>::const_iterator pos=map_name_value.find(name);
   if (pos!=map_name_value.end())
     return pos->second;
   else {
      cout << "name " << name
	   << " not found in the file " << file << endl;
      throw runtime_error("initial conditions query error");
   }
}
