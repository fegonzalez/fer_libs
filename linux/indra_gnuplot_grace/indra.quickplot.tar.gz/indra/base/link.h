#ifndef LINK_HEADER_
#define LINK_HEADER_

#include <cassert>
#include <list>
#include "base.h"


//#include "Hxtemplate.h"

/* The following classes make possible to link inputs and outputs from
 * simulation models in performance time. The type of the model inputs is
 * Input<>, and the type of the outputs is a type derived from Output<>.
 * The Input<>s and Output<>s of a class which implements a simulation model
 * should be part of the public interface (in order to make the links from
 * the client).
 *
 * An Output<> of a given type of data(the type is the argument of the template
 * e.g. Vector for Output<Vector>) has an abstract operator for the conversion
 * to the data type; the subclasses derived from Output<> have to implement
 * the operator. This implementation may consist in a calculus made
 * just when requested, a saved value of an assignment, may return a constant
 * value, etc. An Output<> may have Input<>s, in this case, it needs the 
 * values of the Input<>s in order to calculate its own value. These Input<>s
 * should be related to other Output<>s in performance time.
 *
 * An Input<> is related (by means of the mode link_to())to an Output<> 
 * in performance time; the operator of the conversion to the type of data
 * of Input<> verifies that the Input<> is related to some Output<>, and 
 * then it returns the value of the Output<> related to it. Other Input<>
 * classes should not be derived.
 *
 * The client has to create the needed instances of the classes which 
 * implement the simulation models, and then has to make sure that each
 * Input<> of the created instances is related to some Output<>. An Output<>
 * related to an Input<> may be part of another instance of the ones
 * created by the client, or it may be created directly by the client itself.
 * E.g., when the value of an Input<> of a model is constant, the client
 * may create a ConstVar<> with the suitable value, and may relate the 
 * Input<> to the ConstVar<>. */


/* Abstract base class Output<>. It declares an abstract operator for
 * the conversion to the type of data of the Output<>. */

template <class Type>
class Output {
 public:
   Output() { };
   virtual ~Output() { };
   operator Type() const
     { last_value=compute_value(); return last_value; };
//   virtual void record_play() { RecPlay(&last_value); }
   mutable Type last_value;
 protected:
   virtual Type compute_value() const=0;
};

/* Datum input class. It is not possible that a value of type datum is 
 * returned until the Input<> is related to an Output<>. After being related
 * to an Output<>, it returns the value of the Output<> when its own value is
 * requested. */
template <class Type>
class Input 
: public Output<Type> {
 public:
   Input() 
     : link(0) { };
   void link_to(Output<Type> const &output)
     { link=&output; };
 private:
   Type compute_value() const 
     { assert(link!=0); return link->operator Type(); };
   Output<Type> const *link;
};

/* Output<> of variable output type. This Output<> returns the last value
 * assigned by the assignation operator. In consecuence, it works like a 
 * normal C variable. */

template <class Type>
class OutVar 
: public Output<Type> {
 public:
   OutVar() 
     : datum() { };
   OutVar const &operator=(Type const &new_datum)
     { datum=new_datum; return *this; };
 //  void record_play() { Output<Type>::record_play(); RecPlay(&datum); }
 private:
   Type compute_value() const
     { return datum; };
   Type datum;
};

/* This Output<> repeats the value of another Output<> related to it. It is
 * the same as Input<>, but it remarks the intention of making that the 
 * constraint is made by the object which containts it, and not the client
 * which instances the object. */

template <class Type>
class InOutput 
: public Output<Type> {
 public:
   InOutput() : link(0) { };
   void link_to(Output<Type> const &output)
     { link=&output; };
 private:
   Type compute_value() const
     { assert(link!=0); return link->operator Type(); };
   Output<Type> const *link;
};

/* The same as InOutput, but the returned value is the Output<>'s to which
 * it is related, multiplied by a constant. The constant is taken from the
 * 'multiplier' Input<>, that has to be related to some Output<>.
 * Normally it is the object that contains the k_InOutput<> the one which
 * relates 'multiplier', and usually it is related to a ConstVar<>. */

template <class Type>
class k_InOutput
: public Output<Type> {
 public:
   k_InOutput() : link(0) { };
   void link_to(Output<Type> const &output)
     { link=&output; };
   Input<scalar> multiplier;
 private:
   Type compute_value() const
     { assert(link!=0); return multiplier*link->operator Type(); };
   Output<Type> const *link;
};

/* Output<> with constant value. The constant value returned is passed to
 * it by the constructor when the ConstVar<> is instanced. */

template <class Type>
class ConstVar 
: public Output<Type> {
 public:
   ConstVar(Type const &value)
     : const_value(value) { };
 private:
   Type compute_value() const
     { return const_value; };
   Type const const_value;
};

/* Output<> whose value is the sum of the added Output<>s. The contributions
 * are added in performance time by the add() mode. It may be as many 
 * contributions as necessary, even zero (in this case the value returned
 * is the default value of the datum type, that is, 0 for the scalars, 
 * the null vector for Vector...).
 * Usually the SumVar<> is instanced by the client in order to relate an
 * Input<> of a model to the sum of various Output<>s, instead of just
 * one Output<>. */

template <class Type>
class SumVar
: public Output<Type> {
 public:
   SumVar() { };
   void add(Output<Type> const &contrib)
     { contrib_list.push_back(&contrib); };
 private:
   Type compute_value() const
     {
	Type result=Type();
	for (typename std::list<Output<Type> const *>::const_iterator scan=contrib_list.begin();
	     scan!=contrib_list.end();
	     scan++)
	  result+=(*scan)->operator Type();
	return result;
     };
   std::list<Output<Type> const *>contrib_list;
};

/* Output<> the same as InOutput<>, but instead of repeating the value of
 * another Output<>, it repeats the value of a normal C++ variable (of the
 * same type as the class parameter). */

template <class Type>
class FwdVar 
: public Output<Type> {
 public:
   FwdVar() : link(0) { };
   FwdVar(Type const *output)
     : link(output) { }
   void link_to(Type const *output)
     { link=output; };
 private:
   Type compute_value() const
     { assert(link!=0); return *link; };
   Type const *link;
};

/* Like FwdVar<>, but the output type is different to the input type. */

template <class OutputType, class InputType>
class CastVar 
: public Output<OutputType> {
 public:
   CastVar() : link(0) { };
   void link_to(InputType const *output)
     { link=output; };
 private:
   OutputType compute_value() const
     { assert(link!=0); return OutputType(*link); };
   InputType const *link;
};

#endif
