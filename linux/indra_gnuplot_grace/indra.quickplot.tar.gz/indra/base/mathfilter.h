#ifndef MATHFILTER_HEADER_
#define MATHFILTER_HEADER_

#include "base.h"
#include "model.h"

//#include "Hxtemplate.h"
#include <cmath>
#include <cfloat>
#include <limits>
#include <list>

/* This package defines classes for implementing several filters with one input
 * and one output (SISO).
 * The filtered value is always a scalar. */

/* The class Filter is an abstract base class for the SISO filters.
 * When creating one filter the simulation time step is given.
 * This time step is constant throughout the filter's lifetime.
 *
 * The method filter() updates the input 'x', runs one simulation step over
 * the filter, and returns the output. The method initialise() initialises
 * the filter with the input 'x' and the output 'y'.
 * Both methods are abstract. They are defined in each implementation of the
 * class Filter. */
class MathFilter {
 public:
   MathFilter(scalar dt)
     : Dt(dt),output(std::numeric_limits<scalar>::quiet_NaN()) { };
   virtual ~MathFilter(); // does nothing
   virtual scalar filter(scalar x)=0;
   virtual void initialise(scalar x, scalar y)=0;
   virtual scalar operator()() const { return output; }
   scalar limit_filter(scalar x, scalar lower_limit, scalar upper_limit);
   scalar limit_abs_filter(scalar x, scalar limit);
 protected:
   Scalar const Dt;
   Scalar output;
};

/* Lowpass filter according to Tustin method. This class, derived from
 * Filter, implements the simulation of filters with constant numerator
 * and first order denominator, according to Tustin method. */
class Tustin01
: public MathFilter { // for a/(c+ds)
 public:
   Tustin01(scalar dt, scalar a, scalar c, scalar d)
     : MathFilter(dt)
     { set_coefficients(a, c, d); };
   void set_coefficients(scalar a, scalar c, scalar d)
     {	c_y_n=c*Dt+2*d;	  c_y_n_1=c*Dt-2*d;
	c_x_n=a*Dt;
     }
   scalar filter(scalar x) {
      scalar x_n_1=x_n;
      x_n=x;
      scalar y_n_1=y_n;
      output=y_n=(-c_y_n_1*y_n_1+c_x_n*(x_n_1+x_n))/c_y_n;
      return output;
   }
   void initialise(scalar x, scalar y) { x_n=x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&c_y_n); RecPlay(&c_y_n_1); RecPlay(&c_x_n);
//       RecPlay(&y_n); RecPlay(&x_n);
//   }
 private:
   Scalar c_y_n, c_y_n_1, c_x_n;
   Scalar y_n, x_n;
};

/* First order filter according to Tustin method.
 * This class, derived from Filter, implements the simulation of filters
 * with first order numerators and first order denominators,
 * according to Tustin method. */
class Tustin11
: public MathFilter { // para (a+bs)/(c+ds)
 public:
   Tustin11(scalar dt, scalar a, scalar b, scalar c, scalar d)
     : MathFilter(dt),
       y_n(), x_n()
     { set_coefficients(a, b, c, d); };
   void set_coefficients(scalar a, scalar b, scalar c, scalar d)
     {	c_y_n=c*Dt+2*d;	  c_y_n_1=c*Dt-2*d;
	c_x_n=a*Dt+2*b;	  c_x_n_1=a*Dt-2*b;
     }
   scalar filter(scalar x) {
      scalar x_n_1=x_n;
      x_n=x;
      scalar y_n_1=y_n;
      output=y_n=(-c_y_n_1*y_n_1+c_x_n_1*x_n_1+c_x_n*x_n)/c_y_n;
      return output;
   }
   void initialise(scalar x, scalar y) { x_n=x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&c_y_n); RecPlay(&c_y_n_1); RecPlay(&c_x_n); RecPlay(&c_x_n_1);
//       RecPlay(&y_n); RecPlay(&x_n);
//   }
 private:
   scalar c_y_n, c_y_n_1, c_x_n, c_x_n_1;
   scalar y_n, x_n;
};

/* Second order filter according to Tustin method. This class, derived
 * from Filter, implements the simulation of filters with zero order numerator
 * and second order denominator,according to Tustin method.. */
class Tustin02
: public MathFilter { // para k/((a+bs)*(c+d*s))
 public:
   Tustin02(scalar dt, scalar k, scalar a, scalar b, scalar c, scalar d)
     : MathFilter(dt)
     { set_coefficients(k, a, b, c, d);  };
   void set_coefficients(scalar k, scalar a, scalar b, scalar c, scalar d)
     {  c_y_n=(a*Dt+2*b)*(c*Dt+2*d); c_y_n_1=(-8*b*d+2*a*c*Dt*Dt);
	                             c_y_n_2=(a*Dt-2*b)*(c*Dt-2*d);
	c_x_n=c_x_n_2=k*Dt*Dt; c_x_n_1=2*k*Dt*Dt;
     }
   scalar filter(scalar x) {
      scalar x_n_2=x_n_1;
      x_n_1=x_n;
      x_n=x;
      scalar y_n_2=y_n_1;
      y_n_1=y_n;
      output=y_n=(-c_y_n_2*y_n_2-c_y_n_1*y_n_1
		  +c_x_n_2*x_n_2+c_x_n_1*x_n_1+c_x_n*x_n)/c_y_n;
      return output;
   };
   void initialise(scalar x, scalar y) { x_n_1=x_n=x; output=y_n_1=y_n=y; };
//    void record_play() {
//      RecPlay(&c_y_n); RecPlay(&c_y_n_1); RecPlay(&c_y_n_2);
//      RecPlay(&c_x_n); RecPlay(&c_x_n_1); RecPlay(&c_x_n_2);
//      RecPlay(&y_n); RecPlay(&y_n_1);
//      RecPlay(&x_n); RecPlay(&x_n_1);
//   }
 private:
   Scalar c_y_n, c_y_n_1, c_y_n_2, c_x_n, c_x_n_1, c_x_n_2;
   Scalar y_n_1, y_n, x_n_1, x_n;
};

/* Second order filter according to method Tustin. This class, derived from
 * Filter, implements the simulation of filters with first order numerators and
 * second order denominators, according to Tustin method. */
class Tustin12
: public MathFilter { // para (a+bs)/(c + d*s + e*s2)
 public:
  Tustin12(scalar dt, scalar a, scalar b, scalar c, scalar d, scalar e)
    : MathFilter(dt)
    {set_coefficients(a,b,c,d,e);}

  void set_coefficients(scalar a, scalar b, scalar c, scalar d, scalar e)
    {
      c_y_n= c + ( 2*d/Dt ) + ( 4*e/(Dt*Dt) );
      c_y_n_1= (2*c) - (8*e/(Dt*Dt));
      c_y_n_2= c - (2*d/Dt) + (4*e/(Dt*Dt));
      c_x_n= a  + ( 2*b/Dt );
      c_x_n_1= 2*a;
      c_x_n_2= a - ( 2*b/Dt );
    }

  void initialise(scalar x, scalar y) {
    x_n_1=x_n=x;
    output=y_n_1=y_n=y;
  };

  scalar filter(scalar x){
    scalar x_n_2=x_n_1;
    x_n_1=x_n;
    x_n=x;
    scalar y_n_2=y_n_1;
    y_n_1=y_n;
    output=y_n=(-c_y_n_1*y_n_1 - c_y_n_2*y_n_2
		+c_x_n_2*x_n_2 + c_x_n_1*x_n_1 + c_x_n*x_n)/c_y_n;
    return output;
  };

 private:
  scalar c_y_n, c_y_n_1, c_y_n_2, c_x_n, c_x_n_1, c_x_n_2;
  Scalar y_n_1, y_n, x_n_1, x_n;

};


/* Second order filter according to method Tustin. This class, derived from
 * Filter, implements the simulation of filters with second order numerators and
 * second order denominators, according to Tustin method. */
class Tustin22
  : public MathFilter { // for (a2*s2 a1*s +a0)/(b2*s2 + b1*s + b0)
public:

  Tustin22(scalar dt, scalar a2, scalar a1, scalar a0,
	   scalar b2, scalar b1, scalar b0);

  void set_coefficients(scalar a2, scalar a1, scalar a0,
			scalar b2, scalar b1, scalar b0);

  void initialise(scalar x, scalar y);

  scalar filter(scalar x);

  scalar operator()() const { return output; }

private:

  scalar A0,A1,A2,B0,B1,B2;
  Scalar y_k, y_k1, x_k, x_k1;

};

/* Fourth order filter according to method Tustin. This class, derived from
 * Filter, implements the simulation of filters with fourth order numerators and
 * fourth order denominators, according to Tustin method. */
class Tustin44
  : public MathFilter { // for (a4*s4 + a3*s3 + a2*s2 + a1*s +a0)/(b4*s4 + b3*s3 + b2*s2 + b1*s + b0)
public:

  Tustin44(scalar dt, scalar a4, scalar a3,scalar a2, scalar a1, scalar a0,
	   scalar b4, scalar b3,scalar b2, scalar b1, scalar b0);

  void set_coefficients(scalar a4, scalar a3,scalar a2, scalar a1, scalar a0,
			scalar b4, scalar b3,scalar b2, scalar b1, scalar b0);

  void initialise(scalar x, scalar y);

  scalar filter(scalar x);

  scalar operator()() const { return output; }

private:

  scalar A0,A1,A2,A3,A4,B0,B1,B2,B3,B4;
  Scalar y_k, y_k1, y_k2, y_k3, x_k, x_k1, x_k2, x_k3;

};


/* PID filter according to MMPZ method. This class, derived from Filter,
 * implements the simulation of filters PID (proportional + integral +
 * derivative)according to method "Modified Matched Pole-Zero". */
class MMPZ_PID
: public MathFilter {
   // para $k\left(1+\frac{1}{T_I s}+\frac{T_D s}{1+T_D s/N}\right)$
 public:
   MMPZ_PID(scalar dt, scalar k, scalar T_I, scalar T_D, scalar N)
     : MathFilter(dt)
     { set_coefficients(k, T_I, T_D, N); };
   void set_coefficients(scalar _k, scalar T_I, scalar T_D, scalar N) {
      k=_k;
      dt_T_Id=Dt/T_I;
      scalar const abs_log_scalar_min=-log(FLT_MIN);
        // FIXME: change FLT_MIN for <limits> when libstdc++ is completed
      nu=(T_D*abs_log_scalar_min>N*Dt) ? exp(-N*Dt/T_D) : 0.;
      T_Dd_dt=T_D*(1-nu)/Dt;
   };
   scalar filter(scalar x) {
      scalar x_n_1=x_n;
      x_n=x;
      scalar v_i_n_1=v_i_n;
      scalar v_d_n_1=v_d_n;
      v_i_n=v_i_n_1+dt_T_Id*x_n_1;
      v_d_n=nu*v_d_n_1+T_Dd_dt*(x_n-x_n_1);
      output=y_n=k*(x_n+v_i_n+v_d_n);
      return output;
   };
   void initialise(scalar x, scalar y)
     { x_n=x; output=y_n=y; v_d_n=0; v_i_n=y_n/k-x_n; };
//    void record_play() {
//       RecPlay(&k); RecPlay(&dt_T_Id); RecPlay(&T_Dd_dt); RecPlay(&nu);
//       RecPlay(&v_i_n); RecPlay(&v_d_n); RecPlay(&y_n); RecPlay(&x_n);
//   }
 private:
   scalar k, dt_T_Id, T_Dd_dt, nu;
   Scalar v_i_n, v_d_n, y_n, x_n;
};


// *Proporcional Control. Useful to PID empiric adjust*/
class P_control
: public MathFilter {
   // to K*system
 public:
   P_control(scalar dt, scalar k)
     : MathFilter(dt)
     { set_coefficients(k); };
   void set_coefficients(scalar _k) {
      k=_k;
      };
   scalar filter(scalar x) {
      x_n=x;
      output=y_n=k*x_n;
      return output;
   };
   void initialise(scalar x, scalar y)
     { x_n=x; output=y_n=y;};

 private:
   Scalar k;
   Scalar y_n, x_n;
};




/* PIDD2 filter according to MMPZ method. This class, derived from Filter,
 * implements the simulation of filters PIDD2 (proportional + integral +
 * derivative + second order derivative)according to "Modified Matched
 * Pole-Zero. */
class MMPZ_PIDD2
: public MathFilter {
   // for $k\left(1+\frac{1}{T_I s}+\frac{T_D s}{1+T_D s/N}
   //              +\left(\frac{T_{D_2} s}{1+T_{D_2} s/N_2}\right)^2\right)$
 public:
   MMPZ_PIDD2(scalar dt, scalar k, scalar T_I,
	      scalar T_D, scalar N, scalar T_D_2, scalar N_2)
     : MathFilter(dt)
     { set_coefficients(k, T_I, T_D, N, T_D_2, N_2); };
   void set_coefficients(scalar _k, scalar T_I,
			 scalar T_D, scalar N, scalar T_D_2, scalar N_2) {
      k=_k;
      dt_T_Id=Dt/T_I;
      nu=exp(-N*Dt/T_D);
      T_Dd_dt=T_D*(1-nu)/Dt;
      nu_2=exp(-N_2*Dt/T_D_2);
      T_D2d_dt_2=square(T_D_2*(1-nu_2)/Dt);
   };
   scalar filter(scalar x) {
      scalar x_n_2=x_n_1;
      x_n_1=x_n;
      x_n=x;
      scalar v_i_n_1=v_i_n;
      scalar v_d_n_1=v_d_n;
      scalar v_d2_n_2=v_d2_n_1;
      v_d2_n_1=v_d2_n;
      v_i_n=v_i_n_1+dt_T_Id*x_n_1;
      v_d_n=nu*v_d_n_1+T_Dd_dt*(x_n-x_n_1);
      v_d2_n=2*nu_2*v_d2_n_1-square(nu_2)*v_d2_n_2
	     +T_D2d_dt_2*(x_n-2*x_n_1+x_n_2);
      output=y_n=k*(x_n+v_i_n+v_d_n+v_d2_n);
      return output;
   };
   void initialise(scalar x, scalar y)
     { x_n_1=x_n=x; output=y_n=y; v_d_n=0; v_d2_n_1=v_d2_n=0; v_i_n=y_n/k-x_n; };
//    void record_play() {
//       RecPlay(&k); RecPlay(&dt_T_Id); RecPlay(&T_Dd_dt); RecPlay(&nu);
//       RecPlay(&T_D2d_dt_2); RecPlay(&nu_2);
//       RecPlay(&v_i_n); RecPlay(&v_d_n); RecPlay(&v_d2_n_1); RecPlay(&v_d2_n);
//       RecPlay(&y_n); RecPlay(&x_n_1); RecPlay(&x_n);
//   }
 private:
   scalar k, dt_T_Id, T_Dd_dt, nu, T_D2d_dt_2, nu_2;
   Scalar v_i_n, v_d_n, v_d2_n_1, v_d2_n, y_n, x_n_1, x_n;
};

/* First order filter implemented using an exact discrete operator
 * y/x= 1/(1+s*tau)
 */
class FirstOrderMathFilter
: public MathFilter {
 public:
   FirstOrderMathFilter(scalar dt, scalar tau0)
     : MathFilter(dt)
     { set_constTime(tau0); };
   void set_constTime(scalar tau0)
     {
        tau=tau0;
     }
   scalar filter(scalar x) {
      scalar y_n_1=y_n;
      output=y_n=exp(-Dt/tau)*y_n_1+(1.0-exp(-Dt/tau))*x;
      return output;
   }
   void initialise(scalar x, scalar y) { (void) x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&y_n); RecPlay(&tau);
//   }
 private:
   scalar tau;
   Scalar y_n;
};

/* Filter for limiting the lower limit of the derivative.
 */
class LowerLimitDerivativeFilter
: public MathFilter {
 public:
   LowerLimitDerivativeFilter(scalar dt, scalar lowerLimit)
     : MathFilter(dt)
     { set_lowerLimit(lowerLimit); };
   void set_lowerLimit(scalar limit)
     {
        lowerLimit= limit;
     }
   scalar filter(scalar x) {

      if( ((x-y_n)/Dt) < lowerLimit )
         y_n= y_n + Dt*lowerLimit;
      else
         y_n= x;
      // Note: lowerLimit<0.0
      output=y_n;
      return output;

   }
   void initialise(scalar x, scalar y) { (void) x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&y_n); RecPlay(&lowerLimit);
//   }
 private:
   scalar lowerLimit;
   Scalar y_n;
};

/* Filter for limiting the upper limit of the derivative.
 */
class UpperLimitDerivativeFilter
: public MathFilter {
 public:
   UpperLimitDerivativeFilter(scalar dt, scalar upperLimit)
     : MathFilter(dt)
     { set_upperLimit(upperLimit); };
   void set_upperLimit(scalar limit)
     {
        upperLimit= limit;
     }
   scalar filter(scalar x) {

      if( ((x-y_n)/Dt) > upperLimit )
         y_n= y_n + Dt*upperLimit;
      else
         y_n= x;
      output=y_n;
      return output;

   }
   void initialise(scalar x, scalar y) { (void) x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&y_n); RecPlay(&upperLimit);
//   }
 private:
   scalar upperLimit;
   Scalar y_n;
};

/* Filter for limiting the lower and upper limits of the derivative.
 */
class LimitDerivativeFilter
: public MathFilter {
 public:
   LimitDerivativeFilter(scalar dt, scalar lowerLimit, scalar upperLimit)
   : MathFilter(dt)
     { set_lowerLimit(lowerLimit);
       set_upperLimit(upperLimit); };
   void set_lowerLimit(scalar limit)
     {
        lowerLimit= limit;
     }
   void set_upperLimit(scalar limit)
     {
        upperLimit= limit;
     }

   scalar filter(scalar x) {

      if( ((x-y_n)/Dt) > upperLimit )
         y_n= y_n + Dt*upperLimit;
      else if( ((x-y_n)/Dt) < lowerLimit )
         y_n= y_n + Dt*lowerLimit;
      else
         y_n= x;

      output=y_n;
      return output;

   }
   void initialise(scalar x, scalar y) { (void) x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&y_n); RecPlay(&lowerLimit); RecPlay(&upperLimit);
//   }
 private:
   scalar lowerLimit;
   scalar upperLimit;
   Scalar y_n;
};

/* DelayFilter: this filter produces one output equal to the input if
 * the input derivative is bigger than certain threshold. This is suitable
 * for reproducing the behaviour of systems whose behaviour can't be
 * modelled just with inertia. Typically, itś the case of flexible walls tanks.
 */
class DelayFilter
: public MathFilter {
 public:
   DelayFilter(scalar dt, scalar minNegativeThreshold, scalar minPositiveThreshold)
   : MathFilter(dt)
     { set_minNegativeThreshold(minNegativeThreshold);
       set_minPositiveThreshold(minPositiveThreshold); };
   void set_minNegativeThreshold(scalar limit)
     {
        minNegativeThreshold= limit;
     }
   void set_minPositiveThreshold(scalar limit)
     {
        minPositiveThreshold= limit;
     }

   scalar filter(scalar x) {

      if( (((x-y_n)/Dt)>=0.0) && (((x-y_n)/Dt)<=minPositiveThreshold) ){}
      else if( (((x-y_n)/Dt)<=0.0) && (((x-y_n)/Dt)>=minNegativeThreshold) ){}
      else
        y_n= x;

      output=y_n;
      return output;

   }
   void initialise(scalar x, scalar y) { (void) x; output=y_n=y; };
//    void record_play() {
//       RecPlay(&y_n); RecPlay(&minNegativeThreshold); RecPlay(&minPositiveThreshold);
//   }
 private:
   scalar minNegativeThreshold;
   scalar minPositiveThreshold;
   Scalar y_n;
};

/* Second order filter in the form k/(as^2+bs+c)*/
class SecondOrderFilter
: public MathFilter {
public:
  SecondOrderFilter(scalar dt, scalar k, scalar a, scalar b, scalar c)
    : MathFilter(dt)
    { set_coefficients(k, a, b, c); };
  void set_coefficients(scalar k, scalar a, scalar b, scalar c)
    {
       c_y_n=4.*a+2.*b*Dt+c*Dt*Dt;
       c_y_n_1=2.*c*Dt*Dt-8.*a;
       c_y_n_2=4.*a-2.*b*Dt+c*Dt*Dt;
       c_x_n=k*Dt*Dt;
       c_x_n_1=2.*c_x_n;
       c_x_n_2=c_x_n;
    }
  scalar filter(scalar x)
    {
        scalar x_n_2=x_n_1;
        x_n_1=x_n;
        x_n=x;
        scalar y_n_2=y_n_1;
        y_n_1=y_n;
	output=y_n=(-c_y_n_1*y_n_1-c_y_n_2*y_n_2+
                    c_x_n*x_n+c_x_n_1*x_n_1+c_x_n_2*x_n_2)/c_y_n;
        return output;
    }
  void initialise(scalar x, scalar y) { x_n=x; x_n_1=x; output=y_n=y; y_n_1=y; };
private:
    scalar c_y_n, c_y_n_1, c_y_n_2, c_x_n, c_x_n_1, c_x_n_2;
    Scalar y_n, y_n_1, x_n, x_n_1;
};

template <typename TypeValue>
class PureDelay : public Model
{
public:

  PureDelay(TypeValue const *input,int n_delayed=0):
    n(n_delayed),x(input),output(*input)
  {
  };

  ~PureDelay(){};

  void set_parameters(int new_n){ n = new_n;}
  void model();
  void initialise_model();

private:

  int n;
  TypeValue const *x;
  std::list<TypeValue> L;

public:

  TypeValue output;

};


/* Implementation ***********************************************/


template <typename TypeValue>
void PureDelay<TypeValue>::initialise_model()
{
  L.clear();

  for(int ii = 0; ii < n; ii ++)
    {
      L.push_back(*x);
    }
};

template <typename TypeValue>
void PureDelay<TypeValue>::model()
{
  if(L.empty())
    {
      output = *x;
    }
  else
    {
      output = L.front(); // the first value
      L.erase(L.begin());
      L.push_back(*x);
    }
};

/* Zero order hold filter implementation. This filter updates the output once
 * each characteristic time. It means that the output is frozen during 
 * characteristic time; later, the output is updated.
 */
class ZeroOrderHold : public MathFilter {
 public:
  ZeroOrderHold(scalar dt, scalar time_c)
    : MathFilter(dt), dt(dt), 
      time_c(time_c), time(0.0) {
    output=0.0;
  }
  ~ZeroOrderHold() {}
  void set_characteristic_time(scalar new_time_c) {
    time_c=new_time_c;
  }
  scalar filter(scalar x) {
    time+=dt;
    if (time>=time_c) {
      output=x;
      time=0.0;
    }
    return output;
  }
  void initialise(scalar x, scalar y) {
    time=0.0;
    time_c=y;
    output=x;
  }
 private:
  scalar const dt;
  scalar time_c;
  scalar time;
};


#endif
