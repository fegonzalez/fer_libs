#include "aerodynamic_speed.h"
#include "scalar.h"

#include <iostream>
using namespace std;

int main()
{
   scalar sea_level_pressure = 101325.0;
   scalar sea_level_temperature = 288.15;

   scalar pressure = sea_level_pressure;
   scalar temperature = sea_level_temperature;

   AerodynamicSpeed aerodynamic( temperature, pressure,
                                 sea_level_temperature, sea_level_pressure);

   cout << "Zero speed velocity" << endl;
   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;

  
   cout << "True airspeed 10 m/s" << endl;
   aerodynamic.set_true_airspeed(10);

   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;

   cout << "Changes in sealevel atmospheric conditions" << endl;
   aerodynamic.set_sea_level_atmospheric_parameters(sea_level_temperature,
                                                    sea_level_pressure*1.2);
   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;

   cout << "Return to sealevel atmospheric conditions" << endl;
   aerodynamic.set_sea_level_atmospheric_parameters(sea_level_temperature,
                                                    sea_level_pressure);
   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;


   cout << "Calibrated airspeed 10 m/s" << endl;
   aerodynamic.set_calibrated_airspeed(10);

   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;


   cout << "Changes in sealevel atmospheric conditions" << endl;
   aerodynamic.set_sea_level_atmospheric_parameters(sea_level_temperature,
                                                    sea_level_pressure*1.2);
   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;

   cout << "True airspeed 100 m/s" << endl;
   scalar true_airspeed = 100.0;
   aerodynamic.set_true_airspeed(true_airspeed);
   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << endl;

   cout << "Changes in the level condition with standard sea level" << endl;
   aerodynamic.set_sea_level_atmospheric_parameters(sea_level_temperature,
                                                    sea_level_pressure);

   pressure = 90812.0;
   temperature = 282.21;
   scalar dynamic_pressure = 63568;

   aerodynamic.set_atmospheric_parameters(pressure, dynamic_pressure, temperature);

   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << " if EAS=322.16 OK "<< endl;


   pressure = 84307;
   temperature = 278.24;
   dynamic_pressure = 59015;

   aerodynamic.set_atmospheric_parameters(pressure, dynamic_pressure, temperature);

   cout << "tas:  " << aerodynamic.tas() << endl;
   cout << "cas:  " << aerodynamic.cas() << endl;
   cout << "eas:  " << aerodynamic.eas() << " if EAS=310.40 OK "<< endl;



   
   return 0;
   
}


