#ifndef INDRA_BASE_MODIFIABLE_PARAMETER_HEADER_
#define INDRA_BASE_MODIFIABLE_PARAMETER_HEADER_

#include "cppfunctor.h"
#include <string>
#include <map>

// TODO: a�adir
//
//     * un argumento "Function<bool ()> enable" al constructor de
//       ModifiableParameterDictionary, que controle si se aplican los
//       modificadores
//
//     * un argumento parecido a ModifiableParameterDictionary::modify(), que
//       controle lo mismo pero s�lo para el ajuste concreto
//
//     * un meta-ModifiableParameterDictionary que sirva para todos los tipos
//       de funci�n
//
// (ambos tendr�an que tener valor for defecto "constant(true)")

template <class Signature, typename Argument>
class ModifiableParameterDictionary {
public:
  typedef cppfunct::Function<Signature> FunctionType;
  typedef typename FunctionType::RetType RetType;
  typedef cppfunct::Function<RetType (RetType, Argument)>
    FunctionModifier;
  typedef cppfunct::Function<RetType (RetType)> BoundFunctionModifier;
  ModifiableParameterDictionary(
    cppfunct::Function<Argument ()> const &argument);
  FunctionType function(std::string name, FunctionType const &original);
  std::list<std::string> name_list() const;
  void modify(std::string name, FunctionModifier const &f);
  FunctionType get_function(std::string name) const;
private:
  cppfunct::Function<Argument ()> argument;
  std::map<std::string, FunctionType> original_function_ctr;
  typedef std::map<std::string, BoundFunctionModifier> ModifierFunctionCtr;
  ModifierFunctionCtr modifier_function_ctr;
  std::map<std::string, FunctionType> modified_function_ctr;
  FunctionType get_modified_function(std::string name) const;
  void update_modified_function(std::string name);
};

/// implementation

template <typename FunctionType, typename Argument>
ModifiableParameterDictionary<FunctionType, Argument>
::ModifiableParameterDictionary(
  cppfunct::Function<Argument ()> const &argument)
  : argument(argument) { }

template <typename Signature, typename Argument>
typename ModifiableParameterDictionary<Signature, Argument>::FunctionType
ModifiableParameterDictionary<Signature, Argument>
::function(std::string name, FunctionType const &original) {
  if (original_function_ctr.find(name)!=original_function_ctr.end())
    throw "function "+name+" already in the ModifiableParameterDictionary";
  using namespace cppfunct;
  original_function_ctr[name]=original;
  if (modifier_function_ctr.find(name)==modifier_function_ctr.end())
    modifier_function_ctr[name]=identity<RetType>();
  update_modified_function(name);
  return apply(
    bind_arg<1>(method(this,
                       &ModifiableParameterDictionary<Signature, Argument>
                         ::get_modified_function),
                name));
}

template <typename Signature, typename Argument>
std::list<std::string>
ModifiableParameterDictionary<Signature, Argument>::name_list() const {
  std::list<std::string> result;
  for (typename std::map<std::string, FunctionType>::const_iterator scan=
         original_function_ctr.begin(),
         end=original_function_ctr.end();
       scan!=end;
       ++scan)
    result.push_back(scan->first);
  return result;
}

template <typename Signature, typename Argument>
typename ModifiableParameterDictionary<Signature, Argument>::FunctionType
ModifiableParameterDictionary<Signature, Argument>
::get_function(std::string name) const {
  using namespace cppfunct;
  return apply(
    bind_arg<1>(method(this,
                       &ModifiableParameterDictionary<Signature, Argument>
                         ::get_modified_function),
                name));
}

template <typename Signature, typename Argument>
void
ModifiableParameterDictionary<Signature, Argument>
::modify(std::string name, FunctionModifier const &f) {
  using namespace cppfunct;
  if (modifier_function_ctr.find(name)==modifier_function_ctr.end())
    modifier_function_ctr[name]=identity<RetType>();
  modifier_function_ctr[name]=compose(bind_arg<2>(f, argument),
                                      modifier_function_ctr[name]);
  if (original_function_ctr.find(name)!=original_function_ctr.end())
    update_modified_function(name);
}

template <typename Signature, typename Argument>
void
ModifiableParameterDictionary<Signature, Argument>
::update_modified_function(std::string name) {
  modified_function_ctr[name]=
    compose(modifier_function_ctr[name], original_function_ctr[name]);
}


template <typename Signature, typename Argument>
typename ModifiableParameterDictionary<Signature, Argument>::FunctionType
ModifiableParameterDictionary<Signature, Argument>
::get_modified_function(std::string name) const {
  assert(modifier_function_ctr.find(name)!=modifier_function_ctr.end());
  assert(original_function_ctr.find(name)!=original_function_ctr.end());
  assert(modified_function_ctr.find(name)!=modified_function_ctr.end());
  using namespace cppfunct;
  return modified_function_ctr.find(name)->second;
}

template <typename Signature, typename Argument,
          typename Factor, typename Offset>
void modify_by_factor_offset(
  ModifiableParameterDictionary<Signature, Argument> &mpd,
  std::string name,
  Factor const &factor_arg,   // convertible to Function<scalar (Ret, Argument)
  Offset const &offset_arg) { // convertible to Function<Ret (Ret, Argument)
  typedef typename cppfunct::Function<Signature>::RetType RetType;
  cppfunct::Function<scalar (RetType, Argument)> factor=factor_arg;
  cppfunct::Function<RetType (RetType, Argument)> offset=offset_arg;
  mpd.modify(name,
             factor*cppfunct::arg<1, RetType>()+offset);
}

template <typename Argument, typename ElementType>
cppfunct::Function<
  ElementType (cppfunct::FunctionIgnoredArgumentType, Argument)>
arg_el(ElementType const Argument::*attribute_pointer) {
  return cppfunct::route_args<cppfunct::IndexSet<2> >(
    cppfunct::attribute(attribute_pointer));
}

#endif
