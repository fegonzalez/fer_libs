#include "algebra_functor.h"
#include <iostream>

using namespace std;

void lineal_0()
{
  cout<<"========================================================"<<endl;
  cout<<"=======          TEST: LINEAL FUNCTOR 0           ======"<<endl;
  cout<<"========================================================"<<endl;

  double x = 0.0;

  Lineal_0<double> lineal(new VariableRepeater<double>(&x),
			  new Constant_0<double>(1.0),
			  new Constant_0<double>(0.0));

  Lineal_0<double> lineal2(new VariableRepeater<double>(&x),
			   new Constant_0<double>(2.0),
			   new Constant_0<double>(10.0));

  x=0.0;
  cout << " Variable : " << x << " Lineal: " << lineal() <<" "<< lineal2() << endl;
  x = 10.0;
  cout << " Variable : " << x << " Lineal: " << lineal() <<" "<< lineal2() << endl;


  cout<<"\n========================================================"<<endl;
  cout<<"=======           FINISH TEST                     ======"<<endl;
  cout<<"========================================================"<<endl;


}

void summatory_0()
{
  cout<<"========================================================"<<endl;
  cout<<"=======          TEST: SUMMATORY FUNCTOR 0        ======"<<endl;
  cout<<"========================================================"<<endl;

  double x = 0.0;
  double y = 1.0;
  double z = 5.0;

  Summatory_0<double> sum;

  VariableRepeater<double> X(&x);
  VariableRepeater<double> Y(&y);
  VariableRepeater<double> Z(&z);

  sum.subscribe_functor(pointer_to(X));
  sum.subscribe_functor(pointer_to(Y));
  sum.subscribe_functor(pointer_to(Z));

  cout << x << " " << y << " " << z << " total: " << sum() << endl;

  x = 0.0;
  y = 0.0;
  z = 0.0;
  cout << x << " " << y << " " << z << " total: " << sum() << endl;


  cout<<"\n========================================================"<<endl;
  cout<<"=======           FINISH TEST                     ======"<<endl;
  cout<<"========================================================"<<endl;


};

void product_0()
{
  cout<<"========================================================"<<endl;
  cout<<"=======          TEST: PRODUCT FUNCTOR 0          ======"<<endl;
  cout<<"========================================================"<<endl;

  double x = 1.0;
  double y = 2.0;
  double z = 5.0;
  double u = 15.0;

  Product_0<double> pro;

  VariableRepeater<double> X(&x);
  VariableRepeater<double> Y(&y);
  VariableRepeater<double> Z(&z);
  VariableRepeater<double> U(&u);

  pro.subscribe_functor(pointer_to(X));
  pro.subscribe_functor(pointer_to(Y));
  pro.subscribe_functor(pointer_to(Z));

  cout << x << " " << y << " " << z << " total: " << pro() << endl;

  x = 0.0;
  y = 0.0;
  z = 0.0;
  cout << x << " " << y << " " << z << " total: " << pro() << endl;

  x = 10.0;
  y = 2.0;
  z = 0.5;
  cout << x << " " << y << " " << z << " total: " << pro() << endl;

  x = 10.0;
  y = 2.0;
  z = 0.5;
  pro.subscribe_functor(pointer_to(U));

  cout << x << " " << y << " " << z << " " << u << " total: " << pro() << endl;


  cout<<"\n========================================================"<<endl;
  cout<<"=======           FINISH TEST                     ======"<<endl;
  cout<<"========================================================"<<endl;


};


int main ( )
{
  lineal_0();
  summatory_0();
  product_0();

};
