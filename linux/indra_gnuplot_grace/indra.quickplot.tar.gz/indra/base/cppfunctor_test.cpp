#include "cppfunctor.h"
#include <iostream>

using namespace std;

int main() {
  using namespace cppfunct;

  Function<double ()> f;

  f=new_constant(3.4);
  cout << f() << endl;

  f=4.5;
  cout << f() << endl;
  cout << f << endl;

  pointer_type(Functor_0<double> const) g;
  g=new_functor(f);
  cout << g->function() << endl;

  new_cppfunct_function_inspector(constant(42))->output_value(cout);
  cout << endl;
}
