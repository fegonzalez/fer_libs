#include "serialisation_base.h"
#include "serialisation.h"
#include "geometry.h"
#include "base.h"
#include <sstream>
#include <iostream>

using namespace std;

typedef double scalar;

class Stuff {
public:
  Stuff() : the_answer(0), the_time_lapse(0), the_truth(false) { }
  Stuff(int answer, scalar time_lapse, bool truth)
    : the_answer(answer), the_time_lapse(time_lapse), the_truth(truth) { }
  int answer() const { return the_answer; }
  scalar time_lapse() const { return the_time_lapse; }
  bool truth() const { return the_truth; }
private:
  int the_answer;
  scalar the_time_lapse;
  bool the_truth;
};

ostream &operator<<(ostream &os, Stuff const &stuff) {
  return os << "{ "
            << stuff.answer() << " "
            << stuff.time_lapse() << " "
            << stuff. truth()
            << "}";
}

template <typename A>
void serialize(A &a, Stuff &s) {
  int answer;
  scalar time_lapse;
  bool truth;
  if (a.is_output_archive()) {
    answer=s.answer();
    time_lapse=s.time_lapse();
    truth=s.truth();
    a << answer << time_lapse << truth;
  } else {
    a >> answer >> time_lapse >> truth;
    s=Stuff(answer, time_lapse, truth);
  }
}


class Lump {
public:
  Lump() : the_x(0.), the_y(0.) { }
  Lump(double x, double y)
    : the_x(x), the_y(y) { }
  double x() const { return the_x; }
  double y() const { return the_y; }
  template <typename A>
  void serialize(A &a) {
    a & the_x & the_y;
  }
private:
  Double the_x;
  Double the_y;
};

ostream &operator<<(ostream &os, Lump const &lump) {
  return os << "( "
            << lump.x() << " "
            << lump.y()
            << " )";
}

class ModelWithVirtualMethods {
public:
  virtual ~ModelWithVirtualMethods() { }
  struct State {
    double time_from_0;
    int times_run;
  } state;
  template <typename A>
  void serialize(A &a) {
    serialize_binary(a, state);
  }
};


int main() {
  {
    Stuff s1(42, 5000000000., false);
    cout << boolalpha << "s1: " << s1 << endl;
    ostringstream oss;
    OutputArchive ossa(oss);
    ossa & s1;

    cout << "s1 -> archive -> s2" << endl;

    Stuff s2;
    istringstream iss(oss.str());
    InputArchive issa(iss);
    issa & s2;
    cout << boolalpha << "s2: " << s2 << endl;
  }

  cout << endl;

  {
    Lump l1(3.14, 2.72);
    cout << "l1: " << l1 << endl;
    ostringstream oss;
    OutputArchive ossa(oss);
    ossa & l1;

    cout << "l1 -> archive -> l2" << endl;

    Lump l2;
    istringstream iss(oss.str());
    InputArchive issa(iss);
    issa & l2;
    cout << "l2: " << l2 << endl;
  }

  cout << endl;

  {
    Vector v1(1., -2., 4.);
    cout << "v1: " << v1 << endl;
    ostringstream oss;
    OutputArchive ossa(oss);
    ossa & v1;

    cout << "v1 -> archive -> v2" << endl;

    Vector v2;
    istringstream iss(oss.str());
    InputArchive issa(iss);
    issa & v2;
    cout << "v2: " << v2 << endl;
  }

  cout << endl;

  {
    ModelWithVirtualMethods m1;
    m1.state.time_from_0=3.11;
    m1.state.times_run=99;
    cout << "m1.state.time_from_0: " << m1.state.time_from_0 << endl;
    cout << "m1.state.times_run: " << m1.state.times_run << endl;
    ostringstream oss;
    OutputArchive ossa(oss);
    ossa & m1;

    cout << "m1 -> archive -> m2" << endl;

    ModelWithVirtualMethods m2;
    istringstream iss(oss.str());
    InputArchive issa(iss);
    issa & m2;
    cout << "m2.state.time_from_0: " << m2.state.time_from_0 << endl;
    cout << "m2.state.times_run: " << m2.state.times_run << endl;
  }

}
