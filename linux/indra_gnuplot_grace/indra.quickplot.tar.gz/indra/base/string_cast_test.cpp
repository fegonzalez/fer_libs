#include "string_cast.h"
#include <string>
#include <iostream>


void integer_to_string_conversion(){
  int number = 13;
  std::string thirteen = integer_to_string (number);

  std::cout<<thirteen<<std::endl;

  std::string fourteen="14";
  std::cout<<string_to_integer(fourteen)<<std::endl;
}

void string_to_scalar_conversion(){
  std::string fourteen_and_a_half="14.5";
  std::cout<<string_to_scalar(fourteen_and_a_half)+1<<std::endl;
}

int main() {
  integer_to_string_conversion();
  string_to_scalar_conversion();
  std:: cout << std::boolalpha << string_to<bool>("false") << std::endl;
  std:: cout << std::boolalpha << string_to<bool>("true") << std::endl;
  std:: cout << std::boolalpha << bool(string_to<int>("0")) << std::endl;
  std:: cout << std::boolalpha << bool(string_to<int>("1")) << std::endl;
return 0;}
