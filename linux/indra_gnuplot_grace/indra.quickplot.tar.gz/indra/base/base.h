#ifndef BASE_HEADER_
#define BASE_HEADER_

#include "scalar.h"
//#include "Hkcon.h"
#include <cmath>
#include <cassert>

unchecked_scalar const PI=M_PI;   // pi constant

typedef long int integer;

extern unchecked_scalar simTime; // general simulation time
// extern scalar const dt; // general time step; not fixed for all models
                           // in the future; SO NOW IT'S A PARAMETER OF
                           // THE CONSTRUCTOR OF EACH MODULE
extern integer tick; // it's increased in every simulation step; It's useful
                     // for implementing caches in time, with comparisons
                     // among discrete variables instead of among
                     // continuous ones
void new_step(); // it increases tick, and void all the caches which
                   // are based in its value; it must be done al last once
                   // per iteration, but not in the middle of the proccess of
                   // doing a group of calculations that use one common buffer
                   // in the same integration step.

scalar sin_over(scalar x); // sin(x)/x, with sin_over(0)=1

inline
scalar arcsin(scalar s); // safe arc sine: if s<-1, arcsin=-PI/2, if s>+1,
                         // arcsin=+PI/2
inline
scalar arccos(scalar c); // safe arc cosine: if s<-1, arccos=-PI, if s>+1,
                         // arccos=0
inline
scalar arcsincos(scalar s, scalar c); // it returns c+i�s argument;
                                      // s and s don't need to be
                                      // normalised

inline
scalar square(scalar x); // x*x
inline
scalar square_root(scalar x); // safe square root; if x<0, sqrt=0

inline
scalar cube(scalar x); // x*x*x

inline
integer sign(scalar x); //it returns 1 if x>0 and -1 if x<0

inline
scalar rad_to_deg(scalar rad); // it converts radians to degrees
inline
scalar deg_to_rad(scalar deg); // it converts degrees to radians
inline
scalar mod_pi_pi(scalar rad); // it reduces to the [-pi,+pi] range
                              // (by adding n*2*pi)
inline
scalar mod_0_2pi(scalar rad); // it reduces the [0:2*pi] range

template <typename T, typename U>
T maximum(T a, U b); // largest of a and b
template <typename T, typename U>
T minimum(T a, U b); // smallest of a and b

inline
scalar limit(scalar x, scalar lowerLimit, scalar upperLimit);
  // x is limited between lowerLimit and upperLimit values; that is,
  // if x>upperLimit, upperLimit is returned; if x<lowerLimit,
  // lowerLimit is returned, if x is between them, x is returned

inline
scalar limit_abs(scalar x, scalar limit_abs);
  // x is limited to absolute values not bigger than limit; that is,
  // if x>+limit, +limit is returned; if x<-limit, -limit is returned,
  // in any other case, x is returned

inline
scalar linear(scalar x, scalar x1, scalar y1, scalar x2, scalar y2);
  // it interpolates or extrapolates linearly between (x1, y1) and (x2, y2);
  // there's no need that x1 and x2 should be arranged in order

inline
scalar ramp(scalar x, scalar x1, scalar y1, scalar x2, scalar y2);
  // it interpolates linearly between (x1, y1) and (x2, y2);
  // outside the ]x1, x2[ range, the value is constant; there's no need
  // that x1 and x2 should be arranged in order.

inline
scalar toward(scalar x, scalar objective, scalar step);
  // it returns x displaced towards objective, until a maximum of
  // abs(step) (in any direction); if the distance between x and objective
  // is less than abs(step), objective is returned

inline
scalar square_hysteresis(scalar x, scalar last_y,
                         scalar x1, scalar y1, scalar x2, scalar y2);
  // returns x through the hysteretical function that returns y1 for x=x1 and
  // y2 for x=x2; for x between x1 and x2, returns last_y; for x not between x1
  // and x2 the function is constant; x1 and x2 need not be ordered


// the following comparison functions apply a margin towards returning "true"
// or "false"; "permissive" functions apply the marging towards "true", and
// "strict" functions apply the margin towards "false"; the allowed difference
// for "permissive_eq()" is "sqrt(std::numeric_limits<T>::epsilon())"
// multiplied by a magnitude, which is the larger (in absolute value) of "arg1"
// or "arg2"

template <typename T>
bool permissive_eq(T arg1, T arg2); // permissive equal

template <typename T>
bool strict_ne(T arg1, T arg2); // strict non-equal

template <typename T>
bool permissive_less_than(T arg1, T arg2); // permissive less than

template <typename T>
bool permissive_greater_than(T arg1, T arg2); // permissive greater than

template <typename T>
bool strict_less_than(T arg1, T arg2); // strict less than

template <typename T>
bool strict_greater_than(T arg1, T arg2); // strict greater than

// the following comparison operations are the same as the previous
// "permissive" and "strict" comparisons, but an additional argument gives the
// magnitude of the comparison, instead of it being determined by the larger of
// the compared arguments

template <typename T>
bool permissive_eq(T arg1, T arg2, T magnitude);

template <typename T>
bool strict_ne(T arg1, T arg2, T magnitude);

template <typename T>
bool permissive_less_than(T arg1, T arg2, T magnitude);

template <typename T>
bool permissive_greater_than(T arg1, T arg2, T magnitude);

template <typename T>
bool strict_less_than(T arg1, T arg2, T magnitude);

template <typename T>
bool strict_greater_than(T arg1, T arg2, T magnitude);


extern scalar round_to_1_decimal(scalar x);
extern scalar round_to_the_n_decimal(scalar x, int n);

// the following declares
template <typename T>
class auto_init {
public:
  auto_init(T init_value=T()) : value(init_value) { }
  operator T() const { return value; }
  template <typename U>
  auto_init &operator=(U const &u) { value=u; return *this; }
  template <typename U>
  auto_init &operator+=(U const &u) { value+=u; return *this; }
  template <typename U>
  auto_init &operator-=(U const &u) { value-=u; return *this; }
  template <typename U>
  auto_init &operator*=(U const &u) { value*=u; return *this; }
  template <typename U>
  auto_init &operator/=(U const &u) { value/=u; return *this; }
  T *operator&() { return &value; }
  T const *operator&() const { return &value; }
private:
  T value;
};

typedef auto_init<bool> Bool;
typedef auto_init<scalar> Scalar;
typedef auto_init<double> Double;
typedef auto_init<int> Int;
typedef auto_init<long int> LongInt;
typedef auto_init<char> Char;

template <typename T>
class auto_init<T *> {
public:
  auto_init(int init_value=0) : value_((T *)(init_value)) {
    assert(init_value==0);
  }
  template <typename U>
  auto_init(U *init_value) : value_(init_value) { }
  template <typename U>
  auto_init &operator=(U const &u) { value_=u; return *this; }
  T *value() const { return value_; }
  T &operator*() const { return *value_; }
  T *operator->() const { return value_; }
  operator bool() const { return value_; }
  operator T *() const { return value_; }
private:
  T *value_;
};

#include "base.inl"

#endif
