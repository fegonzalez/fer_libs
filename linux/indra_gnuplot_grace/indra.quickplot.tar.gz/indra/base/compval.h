#ifndef INDRA_BASE_COMPUTED_VALUE_
#define INDRA_BASE_COMPUTED_VALUE_

template <typename Type>
class ComputedValue {
public:
  typedef Type function_type();
  ComputedValue(function_type *function) : function(function) { }
  operator Type const() const { return (*function)(); }
private:
  function_type *const function;
};

#endif
