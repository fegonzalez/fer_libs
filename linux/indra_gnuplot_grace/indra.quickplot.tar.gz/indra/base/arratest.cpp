#include "array.h"
#include "geometry.h"
#include "base.h"

#include <iostream>

using std::cout;
using std::endl;

int main()
{
   array<scalar, 8> a; cout << "array<scalar, 8> a;" << endl;
   cout << "a[2]: " << a[2] << endl;
   a[7]=2.3; cout << "a[7]=2.3" << endl;
   a[7]+=1.; cout << "a[7]+=1." << endl;
   cout << "a[7]: " << a[7] << endl;
   try {
      cout << "trying a[8]" << endl;
      cout << a[8] << endl;
   }
   catch (char const *error) {
      cout << "catched error: " << error << endl;
   }
   cout << "a.size(): " << a.size() << endl;
   
   array_2<Vector, 2, 3> b; cout << "array_2<Vector, 2, 3> b;" << endl;
   cout << "b[1][2]: " << b[1][2] << endl;
   b[1][2]-=Vector(1, 2, 3); cout << "b[1][2]-=Vector(1, 2, 3)" << endl;
   cout << "b[1][2]: " << b[1][2] << endl;
   try {
      cout << "trying b[1][3]" << endl;
      cout << b[1][3] << endl;
   }
   catch (char const *error) {
      cout << "catched error: " << error << endl;
   }
   try {
      cout << "trying b[2][2]" << endl;
      cout << b[2][2] << endl;
   }
   catch (char const *error) {
      cout << "catched error: " << error << endl;
   }
   cout << "b.size_1(): " << b.size_1() << endl;
   cout << "b.size_2(): " << b.size_2() << endl;
}
