#ifndef BASE_TIME_HEADER_
#define BASE_TIME_HEADER_

#include "scalar.h"

class TimeManagement {
public:
  virtual ~TimeManagement() { }
  virtual scalar simulation_time() const=0;
  virtual scalar dt() const=0;
};

extern TimeManagement *time_management;

#endif
