#include "piecefunction.h"
#include "wizardfunction.h"
#include <iostream>

int main() {
    try {
    Line *line1 = Line::new_by_points(1.0, 1.0, 3.0, 3.0);
    Line *line2 = Line::new_by_points(6.0, 0.6, 10.0, 1.0);
    Constant *constant = new Constant(0.0);
    Exponential *exponential = Exponential::new_by_points(0.0,0.0,
                                                          1.0,3.0,
                                                          2.0,7.0);
    Quadratic *quadratic = Quadratic::new_by_points(-1.0,0.0,
                                                    0.0,1.0,
                                                    1.0,0.0);
    (void) line1;
    (void) line2;
    (void) constant;
    (void) exponential;
    (void) quadratic;

    PieceFunction_1 *function = new PieceFunction_1();

    function->add_function(1.0, 2.5, line1);
    std::cout << "Line between (1.0, 1.0) and (3.0, 3.0) added" << std::endl;
    for(scalar x=0.0; x <= 12.0; x+=1.0)
        std::cout << "f(" << x << ") = " << (*function)(x) << std::endl;

    function->add_function(9.0, 11.0, line2);
    std::cout << "Line between (6.0, 0.6) and (10.0, 1.0) added" << std::endl;
    for(scalar x=0.0; x <= 12.0; x+=1.0)
        std::cout << "f(" << x << ") = " << (*function)(x) << std::endl;

    function->add_function(4.5, 5.0, constant);
    std::cout << "Constant = 0.0 added" << std::endl;
    for(scalar x=0.0; x <= 12.0; x+=0.5)
        std::cout << "f(" << x << ") = " << (*function)(x) << std::endl;

    function->add_function(6.0, 8.0, exponential);
    std::cout << "Exponential defined by (0.0,0.0),(1.0,3.0) and (2.0,7.0) added" << std::endl;
    for(scalar x=0.0; x <= 12.0; x+=0.5)
        std::cout << "f(" << x << ") = " << (*function)(x) << std::endl;

    function->add_function(2.6,4.4, quadratic);
    std::cout << "Quadratic defined by (-1.0,0.0),(0.0,1.0) and (1.0,0.0) added" << std::endl;
    for(scalar x=0.0; x <= 12.0; x+=0.5)
        std::cout << "f(" << x << ") = " << (*function)(x) << std::endl;

    return 0;
    }catch(char const *error){
        std::cout<<"============================" << std::endl;
        std::cout<<"|| " << error<< " ||" << std::endl;
        std::cout<<"============================" << std::endl;
    }
}


