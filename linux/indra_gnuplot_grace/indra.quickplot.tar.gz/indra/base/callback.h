#ifndef INDRA_BASE_CALLBACK_HEADER_
#define INDRA_BASE_CALLBACK_HEADER_

#include "pointer_policy.h"

template <typename T>
class CallBack {
public:
  virtual ~CallBack() { }
  virtual void call_back(T const &t) const=0;
};

template <typename T>
class AssignCallBack {
public:
  AssignCallBack(pointer_type(T) p) : p(p) { }
  void call_back(T const &t) const { *p=t; }
private:
  pointer_type(T) const p;
};

#endif
