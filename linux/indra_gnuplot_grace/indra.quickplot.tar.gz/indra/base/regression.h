#ifndef REGRESSION_HEADER_
#define REGRESSION_HEADER_

#include "scalar.h"
#include "base.h"
#include "algebra.h"


namespace Regression
{
  template< class T, int n, int k>
  class RegressionResult
  {
  public:

    RegressionResult(Algebra::GeneralVector<T,k+1> coefficient,
		     scalar const SSE,
		     scalar const SST):
      coefficient(coefficient),
      sse(SSE),sst(SST)
    {
    };

    ~RegressionResult(){};
    
    Algebra::GeneralVector<T,k+1> const coefficient;
    
    scalar R2() const { return 1 -(sse/sst);}
    scalar SSE() const { return sse;}
    scalar SST() const { return sst;}
    
  private:

    scalar const sse; // residual variance
    scalar const sst;

  };

  template< class T, int n, int k>
  RegressionResult<T,n,k> least_squares(Algebra::GeneralVector<T,n> const &y,
					Algebra::Matrix<T,n,k> const &x);

  template< class T, int n>
  T media(Algebra::GeneralVector<T,n> const &x);

}


/* Implementation ***********************************/


namespace Regression {

  template< class T, int n, int k>
  RegressionResult<T,n,k> least_squares(Algebra::GeneralVector<T,n> const &y,
					Algebra::Matrix<T,n,k> const &x)
  {

    // Calculate the matrix X= [1 | x]
    Algebra::Matrix<T,n,k+1> X;

    for(int i=0;i<n;i++)
      {
	for(int j=0;j<k+1;j++)
	  {
	    if(j==0)
	      {
		X(i)(j)= 1;
	      }
	    else
	      {
		X(i)(j)= x(i)(j-1);
	      }
	  }
      }


    /*
      The process tries to obtain the minimum of SSE:
      SSE= (y-Xb)' (y-Xb) ---> (X'X)*b = X'*y    
      b = inv(A) *g  = inv(X'X) * X* * y

    */

    Algebra::Matrix<T,k+1,k+1>  const A = Algebra::trans(X)*X;
    Algebra::GeneralVector<T,k+1> const g = Algebra::trans(X)*y;

    Algebra::GeneralVector<T,k+1> b = Algebra::inverse(A) * (g);
    
    // Calculate the residual variance
    // scalar const sse= (y - X*b)*(y - X*b)/n;
    scalar const yy = (y*y);
    Algebra::GeneralVector<T,k+1> Xy = (trans(X)*y);
    scalar const bXy= b*Xy ;
    scalar const sse= (yy-bXy)/n;

    // Calculate the variance Y
    scalar const Y= media(y);
    scalar const sst=(yy/(n))- (Y*Y);

    return RegressionResult<T,n,k>(b,sse,sst) ;
    
  }



  template< class T, int n>
  T media(Algebra::GeneralVector<T,n> const &x)
  {
    T sum=T();

    for(int i=0;i<n;i++)
      {
	sum= sum + x(i);
      }

    return sum/(n);

  };





}



#endif
