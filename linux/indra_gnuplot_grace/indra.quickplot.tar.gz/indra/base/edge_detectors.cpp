#include "edge_detectors.h"


// -----------------------------------------------------
//                    EDGE DETECTOR
// -----------------------------------------------------
// Constructor without malfunction asociated
Edge_Detector::Edge_Detector(bool const *input_signal):
  input_signal(input_signal), malfunction(0),  previous_input(0),edge_detected(0), state(0)   
{}

// Constructor with malfunction. The malfuction state is checked before evaluate the input signal
Edge_Detector::Edge_Detector(bool const *input_signal, bool const *malfunction):
  input_signal(input_signal), malfunction(malfunction), previous_input(0), state(0)
{}


void Edge_Detector::initialise_model(void)
{
  previous_input = 0;
  state = 0;
  edge_detected = 0;
}



// -----------------------------------------------------
//               RISING EDGE DETECTOR
// -----------------------------------------------------

// Constructor without malfunction asociated
Rising_Edge_Detector::Rising_Edge_Detector(bool const *input_signal):
  Edge_Detector(input_signal)
{}

// Constructor with malfunction. The malfuction state is checked before evaluate the input signal
Rising_Edge_Detector::Rising_Edge_Detector(bool const *input_signal, bool const *malfunction):
  Edge_Detector(input_signal, malfunction)
{}


// The state is switched when a rising edge is detected
void Rising_Edge_Detector::model()
{

   //The malfunction state is checked
   if (malfunction != 0 )
   {
      if ( *malfunction == true)
      {
         state = false;
         edge_detected = false;
         return;
      }
   }
      
  
  // The input signal is checked
  if ( (false == previous_input) and
       (true == *input_signal) )
    {	  
      state = !state;
      edge_detected = true;
    }
  else
    {
      edge_detected = false;
    }
    
  // Update the previous value
  previous_input = *input_signal;  
      
}



// -----------------------------------------------------
//               FALLING EDGE DETECTOR
// -----------------------------------------------------

// Constructor without malfunction asociated
Falling_Edge_Detector::Falling_Edge_Detector(bool const *input_signal):
  Edge_Detector(input_signal)
{}

// Constructor with malfunction. The malfuction state is checked before evaluate the input signal
Falling_Edge_Detector::Falling_Edge_Detector(bool const *input_signal, bool const *malfunction):
  Edge_Detector(input_signal, malfunction)
{}


// The state is switched when a falling edge is detected
void Falling_Edge_Detector::model()
{

   //The malfunction state is checked
  if (malfunction != 0 && *malfunction == true)
    {
      state = false;
      edge_detected = false;
      return;
    }
  
  // The input signal is checked
  if ( (true == previous_input ) and
       (false == *input_signal ) )
    {	  
      state = !state;
      edge_detected = true;
    }
  else
    {
      edge_detected = false;
    }
    
  // Update the previous value 
  previous_input = *input_signal;  
      
}




