#include "ntable.h"
#include <iostream>

// typedef ArgumentList<double, ArgumentList<double, ArgumentListNil> >
//   TwoDoubles;
typedef RepeatedArgumentList<double, 2>::Type TwoDoubles;

template <typename ArgumentListT,
          typename ArgT1, typename ArgT2,
          typename ValueT>
void insert(Table<ArgumentListT, ValueT> &table,
            ArgT1 arg1, ArgT2 arg2, ValueT value) {
  table.insert(tabarg(arg1).tabarg(arg2), value);
}

template <typename ArgumentListT,
          typename ArgT1, typename ArgT2,
          typename ValueT>
ValueT access(Table<ArgumentListT, ValueT> const &table,
              ArgT1 arg1, ArgT2 arg2) {
  return table.access(tabarg(arg1).tabarg(arg2));
}

#define show_access(table, arg1, arg2)                     \
std::cout << #table << "[" << arg1 << ", " << arg2 << "]: " \
          << access(table, arg1, arg2) << std::endl


int main() {
  Table<TwoDoubles, double> table;

  insert(table, 1., 1., 2.); // table[1, 1]=2
  insert(table, 1., 2., 3.); // table[1, 2]=3
  insert(table, 2., 1., 4.); // table[2, 1]=4
  insert(table, 2., 2., 5.); // table[2, 2]=5
  insert(table, -10., -10., 0.);
  insert(table, -10., 10., 0.);
  insert(table, 10., -10., 0.);
  insert(table, 10., 10., 0.);
  insert(table, -10., 1., 0.);
  insert(table, -10., 2., 0.);
  insert(table, 10., 1., 0.);
  insert(table, 10., 2., 0.);
  insert(table, 1., -10., 0.);
  insert(table, 1., 10., 0.);
  insert(table, 2., -10., 0.);
  insert(table, 2., 10., 0.);

  show_access(table, 1., 1.);
  show_access(table, 1.5, 2.);
  show_access(table, 2., 1.5);
  show_access(table, 1.5, 1.5);

  for (double x=0.; x>=-10.; x-=2.)
    show_access(table, x, x);
  for (double x=-2.; x>=-10.; x-=2.)
    show_access(table, 0., x);
  for (double x=-2.; x>=-10.; x-=2.)
    show_access(table, x, 0.);
}
