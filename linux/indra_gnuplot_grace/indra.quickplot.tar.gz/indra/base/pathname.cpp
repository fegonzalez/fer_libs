#include "pathname.h"
#include <fstream>

bool PathNamePolicy::file_exists(std::string pathname) {
  try {
    std::ifstream file_exist_test(pathname.c_str());
    if (file_exist_test.is_open())
      return true;
  }
  catch (...) {
  }
  return false;
}


std::auto_ptr<PathNamePolicy> &PathNamePolicy::global() {
  static std::auto_ptr<PathNamePolicy> result(new IdentityPathNamePolicy);
  return result;
}


AlternativePrefixPathNamePolicy
::AlternativePrefixPathNamePolicy(std::list<std::string> const &prefix_list)
  : prefix_list(prefix_list)
{ }

std::string AlternativePrefixPathNamePolicy
::absolute_pathname(std::string const &relative_pathname) const {
  for (std::list<std::string>::const_iterator scan=prefix_list.begin(),
         end=prefix_list.end();
       scan!=end;
       ++scan) {
    std::string slash_or_not="";
    if (*(scan->end()-1)!='/')
      slash_or_not="/";
    std::string temptative_pathname=*scan+slash_or_not+relative_pathname;
    if (file_exists(temptative_pathname))
      return temptative_pathname;
  }
  return "";
}

std::string FilteredPathNamePolicy
::absolute_pathname(std::string const &relative_pathname) const {
  std::string unfiltered_pathname=
    unfiltered_policy->pathname(relative_pathname);
  for (SubstitutionList::const_iterator scan=substitution_list.begin();
       scan!=substitution_list.end();
       ++scan) {
    if (unfiltered_pathname.find(scan->first)!=std::string::npos) {
      std::string filtered_pathname=unfiltered_pathname;
      filtered_pathname.replace(
        filtered_pathname.find(scan->first),
        scan->first.length(),
        scan->second);
      if (file_exists(filtered_pathname))
        return filtered_pathname;
    }
  }
  return unfiltered_pathname;
}
