#ifndef INDRA_BASE_CPPFUNCTOR_HEADER_
#define INDRA_BASE_CPPFUNCTOR_HEADER_

#include "cppfunct"
#include "functor.h"
#include "pointer_policy.h"
#include "inspector.h"
#include "scalar.h"
#include <iostream>

namespace cppfunct=FunctionLibrary;

namespace FunctionLibrary {

#ifdef USE_SHARED_POINTERS_WHEN_AVAILABLE
  namespace Implementation {

    template <typename T>
    class DynamicVirtualPointerPolicyPointerAlias
      : public DynamicVirtualPointer<T> {
    public:
      DynamicVirtualPointerPolicyPointerAlias(pointer_type(T) p) : p(p) { }
      T *pointer() const { return p.operator->(); }
    private:
      pointer_type(T) const p;
    };

  }

  template <typename T>
  VirtualPointer<T>
  virtual_pointer(pointer_type(T) p) {
    return VirtualPointer<T>(
             new Implementation::DynamicVirtualPointerPolicyPointerAlias<T>(p),
             construct_from_dynamic);
  }
#else

  template <typename T>
  struct Conversion<Function<T ()>,
                    auto_init<pointer_type(Functor_0<T> const)> > {
    static Function<T ()> convert(pointer_type(Functor_0<T> const) f) {
      return method(virtual_pointer(f), &Functor_0<T>::function);
    }
  };

  template <typename T>
  struct Conversion<Function<T ()>,
                    auto_init<pointer_type(Functor_0<T>)> >
    : public Conversion<Function<T ()>, pointer_type(Functor_0<T> const)> { };

  template <typename T>
  struct AsFunction<pointer_type(Functor_0<T>)> {
    typedef Function<T ()> Result;
  };

  template <typename T>
  struct AsFunction<pointer_type(Functor_0<T> const)>
    : public AsFunction<pointer_type(Functor_0<T>)> { };

  template <typename T, typename U>
  struct Conversion<Function<T (U)>,
                    auto_init<pointer_type(Functor_1<T, U> const)> > {
    static Function<T (U)> convert(
      pointer_type(Functor_1<T, U> const) f) {
      return method(virtual_pointer(f), &Functor_1<T, U>::function);
    }
  };

  template <typename T, typename U>
  struct Conversion<Function<T (U)>,
                    auto_init<pointer_type(Functor_1<T, U>)> >
    : public Conversion<Function<T (U)>,
                        pointer_type(Functor_1<T, U> const)> { };


  template <typename T, typename U>
  struct AsFunction<pointer_type(Functor_1<T, U>)> {
    typedef Function<T (U)> Result;
  };

  template <typename T, typename U>
  struct AsFunction<pointer_type(Functor_1<T, U> const)>
    : public AsFunction<pointer_type(Functor_1<T, U>)> { };

  template <typename T, typename U, typename V>
  struct Conversion<Function<T (U, V)>,
                    auto_init<pointer_type(Functor_2<T, U, V> const)> > {
    static Function<T (U, V)> convert(
      pointer_type(Functor_2<T, U, V> const) f) {
      return method(virtual_pointer(f), &Functor_2<T, U, V>::function);
    }
  };

  template <typename T, typename U, typename V>
  struct Conversion<Function<T (U, V)>,
                    auto_init<pointer_type(Functor_2<T, U, V>)> >
    : public Conversion<Function<T (U, V)>,
                        pointer_type(Functor_2<T, U, V> const)> { };


  template <typename T, typename U, typename V>
  struct AsFunction<pointer_type(Functor_2<T, U, V>)> {
    typedef Function<T (U, V)> Result;
  };

  template <typename T, typename U, typename V>
  struct AsFunction<pointer_type(Functor_2<T, U, V> const)>
    : public AsFunction<pointer_type(Functor_2<T, U, V>)> { };

  template <typename T, typename U, typename V, typename W>
  struct Conversion<Function<T (U, V, W)>,
                    auto_init<pointer_type(Functor_3<T, U, V, W> const)> > {
    static Function<T (U, V, W)> convert(
      pointer_type(Functor_3<T, U, V, W> const) f) {
      return method(virtual_pointer(f), &Functor_3<T, U, V, W>::function);
    }
  };

  template <typename T, typename U, typename V, typename W>
  struct Conversion<Function<T (U, V, W)>,
                    auto_init<pointer_type(Functor_3<T, U, V, W>)> >
    : public Conversion<Function<T (U, V, W)>,
                        pointer_type(Functor_3<T, U, V, W> const)> { };

  template <typename T, typename U, typename V, typename W>
  struct AsFunction<pointer_type(Functor_3<T, U, V, W>)> {
    typedef Function<T (U, V, W)> Result;
  };

  template <typename T, typename U, typename V, typename W>
  struct AsFunction<pointer_type(Functor_3<T, U, V, W> const)>
    : public AsFunction<pointer_type(Functor_3<T, U, V, W>)> { };

#endif

  template <typename T>
  struct Conversion<Function<T ()>,
                    pointer_type(Functor_0<T> const)> {
    static Function<T ()> convert(
      pointer_type(Functor_0<T> const) f) {
      return method(virtual_pointer(f), &Functor_0<T>::function);
    }
  };

  template <typename T>
  struct Conversion<Function<T ()>, pointer_type(Functor_0<T>)>
    : public Conversion<Function<T ()>,
                        pointer_type(Functor_0<T> const)> { };


  template <typename T, typename U>
  struct Conversion<Function<T (U)>,
                    pointer_type(Functor_1<T, U> const)> {
    static Function<T (U)> convert(
      pointer_type(Functor_1<T, U> const) f) {
      return method(virtual_pointer(f), &Functor_1<T, U>::function);
    }
  };

  template <typename T, typename U>
  struct Conversion<Function<T (U)>, pointer_type(Functor_1<T, U>)>
    : public Conversion<Function<T (U)>,
                        pointer_type(Functor_1<T, U> const)> { };


  template <typename T, typename U, typename V>
  struct Conversion<Function<T (U, V)>,
                    pointer_type(Functor_2<T, U, V> const)> {
    static Function<T (U, V)> convert(
      pointer_type(Functor_2<T, U, V> const) f) {
      return method(virtual_pointer(f), &Functor_2<T, U, V>::function);
    }
  };

  template <typename T, typename U, typename V>
  struct Conversion<Function<T (U, V)>, pointer_type(Functor_2<T, U, V>)>
    : public Conversion<Function<T (U, V)>,
                        pointer_type(Functor_2<T, U, V> const)> { };


  template <typename T, typename U, typename V, typename W>
  struct Conversion<Function<T (U, V, W)>,
                    pointer_type(Functor_3<T, U, V, W> const)> {
    static Function<T (U, V, W)> convert(
      pointer_type(Functor_3<T, U, V, W> const) f) {
      return method(virtual_pointer(f), &Functor_3<T, U, V, W>::function);
    }
  };

  template <typename T, typename U, typename V, typename W>
  struct Conversion<Function<T (U, V, W)>, pointer_type(Functor_3<T, U, V, W>)>
    : public Conversion<Function<T (U, V, W)>,
                        pointer_type(Functor_3<T, U, V, W> const)> { };

  // back to "Functor"s...

  template <typename T>
  class FunctionFunctor_0
    : public Functor_0<T> {
  public:
    FunctionFunctor_0(Function<T ()> f) : f(f) { }
    T operator()() const { return f(); }
  private:
    Function<T ()> const f;
  };

  template <typename T, typename U>
  class FunctionFunctor_1
    : public Functor_1<T, U> {
  public:
    FunctionFunctor_1(Function<T (U)> f) : f(f) { }
    T operator()(U const &a1) const { return f(a1); }
  private:
    Function<T (U)> const f;
  };

  template <typename T, typename U, typename V>
  class FunctionFunctor_2
    : public Functor_2<T, U, V> {
  public:
    FunctionFunctor_2(Function<T (U, V)> f) : f(f) { }
    T operator()(U const &a1, V const &a2) const { return f(a1, a2); }
  private:
    Function<T (U, V)> const f;
  };

  template <typename T, typename U, typename V, typename W>
  class FunctionFunctor_3
    : public Functor_3<T, U, V, W> {
  public:
    FunctionFunctor_3(Function<T (U, V, W)> f) : f(f) { }
    T operator()(U const &a1, V const &a2, W const &a3) const
      { return f(a1, a2, a3); }
  private:
    Function<T (U, V, W)> const f;
  };

}

template <typename T>
pointer_type(Functor_0<T> const) new_functor(cppfunct::Function <T ()> f)
  { return new_pointer(cppfunct::FunctionFunctor_0<T>(f)); }

template <typename T, typename U>
pointer_type(Functor_1<T, U> const) new_functor(cppfunct::Function <T (U)> f)
  { return new_pointer(cppfunct::FunctionFunctor_1<T, U>(f)); }

template <typename T, typename U, typename V>
pointer_type(Functor_2<T, U, V> const)
new_functor(cppfunct::Function <T (U, V)> f)
  { return new_pointer(cppfunct::FunctionFunctor_2<T, U, V>(f)); }

template <typename T, typename U, typename V, typename W>
pointer_type(Functor_3<T, U, V, W> const)
new_functor(cppfunct::Function <T (U, V, W)> f)
  { return new_pointer(cppfunct::FunctionFunctor_3<T, U, V, W>(f)); }

/// inspector

template <typename Type>
class CppfunctFunctionInspector
  : public ReadOnlyBaseValueInspector {
public:
  CppfunctFunctionInspector(cppfunct::Function<Type ()> const &f) : f(f) { }
  void output_value(std::ostream &os) const { os << f; }
private:
  cppfunct::Function<Type ()> const f;
};

template <typename Type>
pointer_type(CppfunctFunctionInspector<Type>)
new_cppfunct_function_inspector(cppfunct::Function<Type ()> const &f)
{ return new_pointer(CppfunctFunctionInspector<Type>(f)); }

// operations and type_of

class Vector;
class Quaternion;
class SolidMass;
class SolidAction;

namespace FunctionLibrary {
  namespace TypeOf {
    // geometry.h
    template <> struct unary_plus<Vector> { typedef Vector Result; };
    template <> struct unary_minus<Vector> { typedef Vector Result; };
    template <> struct binary_plus<Vector, Vector> { typedef Vector Result; };
    template <> struct binary_minus<Vector, Vector> { typedef Vector Result; };
    template <> struct multiplies<scalar, Vector> { typedef Vector Result; };
    template <> struct multiplies<Vector, scalar> { typedef Vector Result; };
    template <> struct divided<Vector, scalar> { typedef Vector Result; };
    template <> struct multiplies<Quaternion, Vector>
      { typedef Vector Result; };
    template <> struct multiplies<Quaternion, Quaternion>
      { typedef Quaternion Result; };

    // solid.h
    template <> struct binary_plus<SolidMass, SolidMass>
      { typedef SolidMass Result; };
    template <> struct multiplies<scalar, SolidMass>
      { typedef SolidMass Result; };
    template <> struct multiplies<SolidMass, scalar>
      { typedef SolidMass Result; };
    template <> struct divided<SolidMass, scalar>
      { typedef SolidMass Result; };

    template <> struct binary_plus<SolidAction, SolidAction>
      { typedef SolidAction Result; };
    template <> struct binary_minus<SolidAction, SolidAction>
      { typedef SolidAction Result; };
    template <> struct multiplies<scalar, SolidAction>
      { typedef SolidAction Result; };
    template <> struct multiplies<SolidAction, scalar>
      { typedef SolidAction Result; };
    template <> struct divided<SolidAction, scalar>
      { typedef SolidAction Result; };
  }
}

namespace FunctionLibrary {

  // ostream
  template <typename Ret>
  std::ostream &operator<<(std::ostream &os, Function<Ret ()> const &f) {
    return os << f();
  }

}

typedef cppfunct::Function<bool ()> Fbool;
typedef cppfunct::Function<int ()> Fint;
typedef cppfunct::Function<scalar ()> Fscalar;
typedef cppfunct::Function<Vector ()> FVector;
typedef cppfunct::Function<Quaternion ()> FQuaternion;
typedef cppfunct::Function<SolidMass ()> FSolidMass;
typedef cppfunct::Function<SolidAction ()> FSolidAction;

#endif
