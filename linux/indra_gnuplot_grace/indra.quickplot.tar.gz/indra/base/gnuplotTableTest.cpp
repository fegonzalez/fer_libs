
#include "gnuplotTables.h"

#include <iostream>
#include <stdlib.h>
#include "scalar.h"
#include <string>
using std::cout;
using std::endl;
using std::cerr;
using std::string;

// At least three arguments:
// 1st: the dimension on the table
// 2nd: the input data  filename
// 3rd: the output data filename
// 4th: (optional) interpolation
// 5th: number of points in x axis
// 6th: number of points in y axis

int main(int argc, char *argv[])
{
    int number_of_arguments = argc;
    int dimension_number;
    string filename_in,  filename_out;
    if (number_of_arguments > 1)
        dimension_number = atoi(argv[1]);
    if (number_of_arguments > 2)
        filename_in = argv[2];
    if (number_of_arguments > 3)
        filename_out = argv[3];
    bool interpolation;
    int number_points_x, number_points_y;
    if (number_of_arguments>4)
    {
        interpolation = bool (atoi(argv[4]));
        if (number_of_arguments>5)
        {
            number_points_x = atoi(argv[5]);

            if (number_of_arguments>6)
            {
                number_points_y = atoi(argv[6]);
            }
        }
    }

    if ( (number_of_arguments >=4) &&
         (dimension_number==1 || dimension_number==2) )
    {
        if (dimension_number==1)
        {
            // 2D
            GnuplotDataTable_1D object1(filename_in.c_str(), filename_out.c_str());
            if (number_of_arguments >4)
                if (interpolation) {
                    if (number_of_arguments >=6 && number_points_x >10 )
                    {
                        object1.interpolate((filename_out + "_interp").c_str(), 50);
                    }
                    else
                    {
                        object1.interpolate((filename_out + "_interp").c_str());
                    }
                }
        }
        else if (number_of_arguments >=4 && dimension_number==2)
        {
            //3D
            GnuplotDataTable_2D object2(filename_in.c_str(), filename_out.c_str());
            if (number_of_arguments>4)
            {
                if (interpolation)
                    if (number_of_arguments >=6 && number_points_x > 10)
                    {
                        if (number_of_arguments==6)
                        {
                            object2.interpolate((filename_out +"_interp").c_str(),
                                               number_points_x);
                        }

                        else if (number_of_arguments ==7 && number_points_y> 0)
                        {
                            object2.interpolate((filename_out+"_interp").c_str(),
                                               number_points_x,
                                               number_points_y);

                        }
                        else
                        {
                            object2.interpolate((filename_out +"_interp").c_str());
                        }
                    }
            }
        }
        else
        {
            std::cerr << "The dimension of the table is not correct" << endl;

        }
    }
    else
    {
        std::cerr << "Usage:  " << endl;
        std::cerr << "gnuplotTablesTest <dimension> <input filename> <output filename> " << endl;
        std::cerr <<"\t\t\t [interpolation: 0 or 1 ]" << endl;
        std::cerr <<"\t\t\t [number of points for x axis interpolation]" << endl;
        std::cerr <<"\t\t\t [number of points for y axis interpolation]" << endl;

        std::cerr << "  At least three arguments: " << endl;
        std::cerr << " 1st: the dimension on the table (1 or 2)" << endl;
        std::cerr << " 2nd: the input data  filename  " << endl;
        std::cerr << " 3rd: the output data filename " << endl;
        std::cerr << " 4th: (optional) interpolation " << endl;
        std::cerr << " 5th: number of points in x axis " << endl;
        std::cerr << " 6th: number of points in y axis " << endl;

    }


    return 1;
}
