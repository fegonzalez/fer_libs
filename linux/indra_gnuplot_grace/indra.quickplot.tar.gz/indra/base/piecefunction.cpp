#include "piecefunction.h"
#include "base.h"
#include <limits>
#include <cmath>

void PieceFunction_1::add_function(scalar min, scalar max,
                              Functor_1<scalar> *new_function) {
    function_container_1[min]=new_function;
    function_container_2[max]=new_function;
}

scalar PieceFunction_1::operator()(scalar const &value) const {
    if (isnan(value))
        return std::numeric_limits<scalar>::quiet_NaN();
    FunctionCtr::const_iterator pos_container_1 =
        function_container_1.lower_bound(value);
    if (pos_container_1==function_container_1.begin())
        return (*pos_container_1->second)(pos_container_1->first);
    else
        pos_container_1--;
    FunctionCtr::const_iterator pos_container_2 =
        function_container_2.lower_bound(value);
    if (pos_container_2==function_container_2.end())
    {
        pos_container_2--;
        return (*pos_container_2->second)(pos_container_2->first);
    }

    if (pos_container_1->second==pos_container_2->second)
        return (*pos_container_1->second)(value);
    else
    {
        pos_container_1++;
        pos_container_2--;
        scalar x1 = pos_container_2->first;
        scalar x2 = pos_container_1->first;
        scalar y1 = (*pos_container_2->second)(x1);
        scalar y2 = (*pos_container_1->second)(x2);
        return ramp(value, x1, y1, x2, y2);
    }
}
