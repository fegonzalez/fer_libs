#ifndef TABLE_GNUPLOT_HEADER_
#define TABLE_GNUPLOT_HEADER_


#include "table.h"

// Class made for processing datafile and converted data into compatible
// Gnuplot data file for 1 dimensional tables.
// There is also a function just for interpolating datapoints 

class GnuplotDataTable_1D 
{
public:
    GnuplotDataTable_1D(char const * filename_in, char const * filename_out);
    ~GnuplotDataTable_1D() {};

    Data_1D_file datafile_object_1D;
    Table_1D_linear table_object;
    void interpolate( char const *filename_out ,
                     int n_points_x = 100);
    
};

// Class made for processing datafile and converted data into compatible
// Gnuplot data file for 2 dimensional tables

class GnuplotDataTable_2D 
{
public:
    GnuplotDataTable_2D(char const * filename_in, char const * filename_out);
    ~GnuplotDataTable_2D() {};

    Data_2D_file datafile_object_2D;
    Table_2D_linear table_object;
    void interpolate( char const *filename_out ,
                     int n_points_x = 100,
                     int n_points_y = 100);
    
};



#endif


