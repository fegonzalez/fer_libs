#include "solid.h"
#include <iostream>
#include <iomanip>
#include <sstream>

using namespace std;

void test_solid_mass_istream(string s) {
  SolidMass sm;
  istringstream smiss(s);
  smiss >> sm;
  cout << "\"" << s << "\"" << " -> " << sm << endl;
}

#define test_solid_mass(...)                                            \
do {                                                                    \
  cout << #__VA_ARGS__ << " -> " << __VA_ARGS__ << endl;                \
} while (false)

int main (void) {
  {
    // allowable syntaxes for reading a SolidMass from a stream are those
    // between quotes below; don't forget the dot before operations
    // (".placed_at", ".relative_to")
    test_solid_mass(SolidMass(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
    test_solid_mass_istream("SolidMass 1 2 3 4 5 6 7 8 9 10");
    test_solid_mass(point_mass(10));
    test_solid_mass_istream("point_mass 10");
    test_solid_mass(point_mass(10).placed_at(Vector(1, 2, 3)));
    test_solid_mass_istream("point_mass 10 :placed_at 1 2 3");
    test_solid_mass(point_mass(10).relative_to(Vector(1, 2, 3)));
    test_solid_mass_istream("point_mass 10 :relative_to 1 2 3");
    test_solid_mass(uniform_sphere_mass(5, 3));
    test_solid_mass_istream("uniform_sphere_mass 5 3");
    test_solid_mass(hollow_sphere_mass(5, 3));
    test_solid_mass_istream("hollow_sphere_mass 5 3");
    test_solid_mass(hollow_sphere_mass(5, 3)
                      .placed_at(Vector(1, 2, 3))
                      .placed_at(Vector(4, 5, 7)));
    test_solid_mass_istream(
      "hollow_sphere_mass 5 3 :placed_at 1 2 3 :placed_at 4 5 7");
    cout << endl;
  }


// Testing "SolidAction from_reduced_to"
  cout.precision (2);
  cout<<fixed;

  Reference_0 ejes_padre;
    ejes_padre.set_abs (Vector(2., 0., 0.), Quaternion (Vector (0., 1., 0.), M_PI/4.*0.));

  Reference_0 ejes_hijo (&ejes_padre);
    ejes_hijo.set_parent (Vector(0., 0., 3.), Quaternion (Vector (0., 1., 0.), M_PI/2.));

  SolidAction solid_action = SolidAction (Vector (1., 0., 0.), Vector (0., 0., 0.));

  cout << "Actions in 'ejes hijo' = " << solid_action << endl;
  cout << "Actions in 'ejes padre' = " << from_reduced_to (&solid_action, &ejes_hijo, &ejes_padre) << endl;
  cout << "Actions in abs = " << from_reduced_to (&solid_action, &ejes_hijo, 0) << endl;
}
