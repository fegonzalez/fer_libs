
#include <iostream>

#include "introspection.h"
#include "factory.h"
#include "string_cast.h"

using namespace std;
using namespace HierarchyIntrospection;

namespace {

  class Component
  {
  public:

    Component(std::string name);

    virtual ~Component() ;

    virtual double result()=0;

    static Component *concrete(std::string name);
    static std::list<std::string> concrete_name_list();

  protected:

    bool declared;
    std::string const name;

  };

  Component::Component(std::string name):
    declared(Dictionary<Component>::singleton().declare(name,this)),
    name(name)
  {

  }


  Component::~Component() { Dictionary<Component>::singleton().undeclare(name); }


  Component* Component::concrete(std::string name)
  { return Dictionary<Component>::singleton().get(name);}


  std::list<std::string> Component::concrete_name_list()
  { return Dictionary<Component>::singleton().get_list();}




  class CteComponent
    : public Component
  {
    CteComponent():
      Component("Cte"){};

    double result()
    {
      return 1.0;
    }

  private:

    static CteComponent* instance;

  };

  CteComponent* CteComponent::instance = new CteComponent;

  class DoubleComponent
    : public Component
  {
  public:

    DoubleComponent():
      Component("Double"){};

    double result()
    {
      return 2;
    }


  private:

    static DoubleComponent * instance;
  };

  DoubleComponent* DoubleComponent::instance = new DoubleComponent;


  //////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////


  // Factory Classes
  class ParametricComponent
  {
  public:

    virtual ~ParametricComponent(){}
    virtual double result()=0;

  };


  class IntrospectionTestFactory:
    public BaseFactory::Factory<ParametricComponent ,std::string >
  {
  public:

    static IntrospectionTestFactory* concrete(std::string name)
  { return Dictionary<IntrospectionTestFactory>::singleton().get(name);}


  };

  class ComponentEnglish
    : public ParametricComponent {
  public:
    ComponentEnglish(std::string number) {
      if (number=="one")
	value=1.;
      else if (number=="two")
	value=2.;
      else
	value=999.;
    }
    double result() { return value; }
  private:
    double value;
  };



  class ComponentEnglishFactory
    : public IntrospectionTestFactory {
  public:
    pointer_type(ParametricComponent)
      create_new(std::string const &number) const
      { return new_pointer(ComponentEnglish(number)); }


    static bool declared;
  };

  bool ComponentEnglishFactory::declared = Dictionary<IntrospectionTestFactory>::singleton().declare("english",new ComponentEnglishFactory);


  class ComponentNumber
    : public ParametricComponent {
  public:

    ComponentNumber(std::string number)  {
      value=string_to<double>(number);
    }

    double result() { return value; }
  private:
    double value;
  };


  class ComponentNumberFactory
    : public IntrospectionTestFactory {
  public:

    pointer_type(ParametricComponent)
      create_new(std::string const &number) const
      { return new_pointer(ComponentNumber(number)); }

  static bool declared;

  };

bool ComponentNumberFactory::declared = Dictionary<IntrospectionTestFactory>::singleton().declare("number",new ComponentNumberFactory);



}





void introspection_test()
{

  cout<<"\n========================================================"<<endl;
  cout<<"=======           INTROSPECTION TEST BASIC        ======"<<endl;
  cout<<"========================================================"<<endl;

  // Demostration of the known instruments
  std::list<std::string> component_list = Component::concrete_name_list();

  std::cout << "Known components: ";

  for(std::list<std::string>::const_iterator scan=component_list.begin();
      scan!=component_list.end(); )
    {
      std::cout << *scan;
      ++scan;

      if(scan!=component_list.end())
	std::cout << ", ";
    }
  std::cout << std::endl;


  cout<< "Cte value: "<< Component::concrete("Cte")->result() << endl;
  cout<< "Double value: "<< Component::concrete("Double")->result() << endl;




  cout<<"\n========================================================"<<endl;
  cout<<"=======           FINISH TEST                     ======"<<endl;
  cout<<"========================================================"<<endl;

}

void  introspection_factory_test()
{

  cout<<"\n========================================================"<<endl;
  cout<<"=======           INTROSPECTION TEST FACTORIES    ======"<<endl;
  cout<<"========================================================"<<endl;


  cout<< "English one: "<< IntrospectionTestFactory::concrete("english")->
    create_new("one")->result() << endl;

  cout<< "Number 2 + 1: "<< IntrospectionTestFactory::concrete("number")->
    create_new("2")->result() + 1<< endl;


  cout<<"\n========================================================"<<endl;
  cout<<"=======           FINISH TEST                     ======"<<endl;
  cout<<"========================================================"<<endl;

}




int main() {

  introspection_test();
  introspection_factory_test();


  cout<<"End of program "<< endl;
}
