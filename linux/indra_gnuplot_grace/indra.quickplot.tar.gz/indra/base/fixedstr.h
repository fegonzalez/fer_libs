#ifndef BASE_FIXED_STR_HEADER_
#define BASE_FIXED_STR_HEADER_

#include <string>
#include <algorithm>
#include <iostream>

// the class FixedString implements a limited-size string without any memory
// management; it is useful in situations where a std::string cannot be used
// (e.g. when viewing the same data from two processes, or through reflective
// memory), but higher abstraction than naked C-strings is needed
template <unsigned int max_size, typename CharType=char>
class FixedString {
public:
  FixedString() {
    *this=std::basic_string<CharType>();
  }
  template <typename T>
  FixedString(T s) {
    *this=s;
  }

  unsigned int length() const {
    return current_length;
  }
  CharType operator[](unsigned int index) const {
    if (index>=length())
      throw "access past the end of FixedString";
    return contents[index];
  }
  std::basic_string<CharType> to_string() const {
    return std::basic_string<CharType>(contents, length());
  }

  template <typename ArgumentCharType>
  FixedString &append(std::basic_string<ArgumentCharType> s) {
    return *this=to_string()+s;
  }
  template <typename ArgumentCharType>
  FixedString &operator=(std::basic_string<ArgumentCharType> s) {
    if (s.length()>max_size)
      throw "FixedString assigned too big a string";
    std::copy(s.begin(), s.end(), contents);
    current_length=s.length();
    return *this;
  }

  template <typename ArgumentCharType>
  FixedString &append(ArgumentCharType const *s) {
    return append(std::basic_string<ArgumentCharType>(s));
  }
  template <typename ArgumentCharType>
  FixedString &operator=(ArgumentCharType const *s) {
    return *this=std::string(s);
  }

  template <typename T>
  FixedString &operator+=(T s)
    { return append(s); }

private:
  CharType contents[max_size];
  unsigned int current_length;
};

template <unsigned int max_size, typename CharType>
std::ostream &operator<<(std::ostream &os,
                         FixedString<max_size, CharType> const &fs) {
  return os << fs.to_string();
}

template <unsigned int max_size, typename CharType>
std::istream &operator>>(std::istream &is,
                         FixedString<max_size, CharType> &fs) {
  std::basic_string<CharType> s;
  is >> s;
  fs=s;
  return is;
}

#endif
