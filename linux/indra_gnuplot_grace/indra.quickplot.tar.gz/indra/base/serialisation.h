#ifndef INDRA_BASE_SERIALISATION_HEADER_
#define INDRA_BASE_SERIALISATION_HEADER_

#include <iostream>

template <typename A, typename T>
void serialize(A &a, T &t) {
  t.serialize(a);
}

typedef char byte;

class GeneralInputArchive {
public:
  bool is_input_archive() const { return true; }
  bool is_output_archive() const { return false; }
};

class InputArchive
  : public GeneralInputArchive {
public:
  InputArchive(std::istream &is) : is(is) { }
  template <typename T>
  InputArchive &operator>>(T &t) { serialize(*this, t); return *this;}
  template <typename T>
  InputArchive &operator&(T &t) { return *this >> t; }
  template <typename T>
  InputArchive &operator<<(T &) { throw "output to InputArchive"; }
  void serialize_bytes(byte *b, std::streamsize n)
    { is.rdbuf()->sgetn(b, n); }
private:
  std::istream &is;
};

class GeneralOutputArchive {
public:
  bool is_input_archive() const { return false; }
  bool is_output_archive() const { return true; }
};

class OutputArchive
  : public GeneralOutputArchive {
public:
  OutputArchive(std::ostream &os) : os(os) { }
  template <typename T>
  OutputArchive &operator<<(T &t) { serialize(*this, t); return *this; }
  template <typename T>
  OutputArchive &operator&(T &t) { return *this << t; }
  template <typename T>
  OutputArchive &operator>>(T &) { throw "input from OutputArchive"; }
  void serialize_bytes(byte *b, std::streamsize n)
    { os.rdbuf()->sputn(b, n); }
private:
  std::ostream &os;
};

template <typename Archive, typename T>
void serialize_binary(Archive &a, T &t) {
  a.serialize_bytes(reinterpret_cast<byte *>(&t), sizeof(T));
}

#define to_be_serialized_as_binary(T)                                   \
template <typename Archive>                                             \
void serialize(Archive &a, T &t) { serialize_binary(a, t); } namespace { }

#endif
