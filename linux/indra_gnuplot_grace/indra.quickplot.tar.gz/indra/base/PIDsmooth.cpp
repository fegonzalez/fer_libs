#include "PIDsmooth.h"

PIDSmooth::PIDSmooth(scalar dt)
  : Dt(dt), max_der_reference(1),
    last_reference(0.), ramped_reference(0.), smooth_reference(0.),
    last_control(0.),
    smoothing(true),
    critical_filter(dt, 1., 1., 1., 1., 1.),
    PID_filter(dt, 1., 1., 1., 5.)
{ }

void PIDSmooth::set_coefficients(scalar _max_der_reference,
				scalar critical_time,
				scalar k, scalar t_I, scalar t_D) {
  max_der_reference=_max_der_reference;
  critical_filter.set_coefficients(1., 1., critical_time, 1., critical_time);
  PID_filter.set_coefficients(k, t_I, t_D, 5.);
}

void PIDSmooth::set_smoothing(bool _smoothing) {
  smoothing=_smoothing;
}

void PIDSmooth::initialise(scalar measure, scalar reference, scalar control) {
  last_measure=measure;
  last_reference=ramped_reference=smooth_reference=reference;
  critical_filter.initialise(ramped_reference, ramped_reference);
  last_control=control;
  PID_filter.initialise(last_measure-ramped_reference, last_control);
}

scalar PIDSmooth::control(scalar measure, scalar reference) {
  last_measure=measure;
  last_reference=reference;
  if (smoothing) {
    ramped_reference=toward(ramped_reference, last_reference,
			      max_der_reference * Dt);
    smooth_reference=critical_filter.filter(ramped_reference);
  }
  else {
    ramped_reference=smooth_reference=last_reference;
  }
  
  last_control=PID_filter.filter(last_measure-smooth_reference);
  return last_control;
}
