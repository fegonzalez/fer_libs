#include "table.h"
#include "string_cast.h"
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
#include <stdexcept>
#include <iostream>
#include <algorithm>
#include <functional>
#include <limits>
#include <cstring>
#include <cassert>


using std::string;
using std::vector;
using std::map;
using std::ifstream;
using std::istringstream;
using std::copy;
using std::cout;
using std::cerr;
using std::endl;
using std::runtime_error;
using namespace indra_lib;


static unsigned int posterior_index(scalar const nodes[],
				     unsigned int n_nodes,
				     scalar x)
{
   int left=-1, rite=n_nodes, mid;
   while (rite-left>1) {
      mid=(rite+left)/2;
      if (nodes[mid]<x)
	left=mid;
      else
	rite=mid;
   }
   return rite;
}

static bool syntactically_empty_line(string const &line_string)
{
  return (line_string.find_first_not_of(" \t\r")==string::npos
	  || line_string.size()==0
	  || line_string[line_string.find_first_not_of(" \t\r")]=='#');
                               // because of the previous condition, size()>=1
}


std::vector<std::string> HeaderReaderDefault::operator()(std::ifstream * const & file) const {
  std::string line;
  std::vector<std::string> var_name_vector;
  getline(*file, line);
  while (syntactically_empty_line(line))
    getline(*file, line);
  std::istringstream line_iss(line);
  std::string var_name;
  while (line_iss) {
    line_iss >> var_name;
    if (not line_iss)
      continue;
    var_name_vector.push_back(var_name);
  }
  return var_name_vector;
}

/* Data_1D_file **********************************************************/

Data_1D_file::Data_1D_file(char const *file_name)
{
   //- cout << "reading of the table 1D from the file" << file_name << endl;
   vector<scalar> vector_nodes_x;
   vector<scalar> vector_values;
   ifstream file(file_name);
   if (!file.is_open())
       cerr <<"ERROR: THE FILE CANNOT BE OPENED: "<<file_name<<endl;
   assert (file.is_open() );

   int n_line=0;

   while (file) {
      // process new line
      string line_string;
      getline(file, line_string);
      n_line++;

      // ignore in case it is empty or begins with "#"
      if (syntactically_empty_line(line_string))
	continue;

      // extract node, separation and value
      istringstream line(line_string);
      unchecked_scalar new_node, new_value;  //-
      char separation;
      line >> new_node;
      if (line.fail()) {
	 cout << "error reading the node from the file" << file_name
	      << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }
      line >> separation;
      if (separation!='=' && separation!='|') {
	 cout << "error of separator in file" << file_name
              << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }
      line >> new_value;
      if (line.fail()) {
	 cout << "error reading value from the file " << file_name
              << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }

      //- cout << new_node << " | " << new_value << endl;

      // add the nodes and values vectors
      vector_nodes_x.push_back(new_node);
      vector_values.push_back(new_value);
   }

   // load data in base class Data_1D
   n_nodes_x=vector_nodes_x.size();
   scalar *nodes_x=new scalar[n_nodes_x];
   copy(vector_nodes_x.begin(), vector_nodes_x.end(), nodes_x);
   Data_1D::nodes_x=nodes_x;
   scalar *values=new scalar[n_nodes_x];
   copy(vector_values.begin(), vector_values.end(), values);
   Data_1D::values=values;
}

Data_1D_file::~Data_1D_file()
{
   delete[] nodes_x;
   delete[] values;
}

/* Data_1D_copy **************************************************/

Data_1D_copy::Data_1D_copy(scalar const nodes_x_[],
        scalar const values_[],
        unsigned int n_nodes_x_)
{

    n_nodes_x = n_nodes_x_;
    scalar *nodes_x=new scalar[n_nodes_x_];
    memcpy(nodes_x, nodes_x_, sizeof(scalar)*n_nodes_x_);
    Data_1D::nodes_x=nodes_x;

    scalar *values=new scalar[n_nodes_x_];
    memcpy(values, values_, sizeof(scalar)*n_nodes_x_);
    Data_1D::values=values;


};


Data_1D_copy::~Data_1D_copy()
{

delete[] nodes_x;
delete[] values;
}



DataTimeHistoryFile::
DataTimeHistoryFile(std::string const file_name,
		    pointer_type(Functor_1<std::vector<std::string>,
                                           std::ifstream *>) read_header)
{
  std::ifstream file(file_name.c_str());
  if (!file.is_open())
    cerr << "ERROR: THE FILE CANNOT BE OPENED: " << file_name << endl;
  assert(file.is_open());

  std::vector< std::vector<scalar> *> value_vector;

  //FIXME: It is necessary include a method to read header
  //FIXME: independently of the data file format.
  std::vector<std::string> var_name_vector=read_header->function(&file);
  for(std::vector<std::string>::iterator scan=var_name_vector.begin(),
	end=var_name_vector.end();
      scan!=end;
      ++scan) {
    value_vector.push_back(value_ctr[*scan]=new std::vector<scalar>);
  }

  //  scalar last_time=-std::numeric_limits<scalar>::infinity();

  std::string line;
  int line_no=1;
  while (file) {
    getline(file, line);
    if (syntactically_empty_line(line))
      continue;
    std::istringstream line_iss(line);
    std::vector< std::vector<scalar> >::size_type i;
    for (i=0;
         i<value_vector.size();
         ++i) {
      std::string value_string;
      line_iss >> value_string;
      scalar value;
      if ((value_string=="nan") or (value_string=="NaN"))
	value=std::numeric_limits<scalar>::quiet_NaN();
      else {
	std::istringstream value_iss(value_string);
	value_iss>>value;
	if (value_iss.fail())
	  line_iss.setstate(std::ios::failbit);
      }
      value_vector[i]->push_back(value);
      if (line_iss.fail())
	break;
    }
    if (line_iss.fail())
      throw "error reading file "+file_name+", "
	+integer_to_string(line_no)+ " lines after header, value number "
	+integer_to_string(i+1)+" (\""+line+"\")";
    ++line_no;
  }
}

// DataTimeHistoryFile::DataTimeHistoryFile(std::string const file_name) {
//   DataTimeHistoryFile(file_name, new HeaderReaderDefault());
// }

scalar const *DataTimeHistoryFile::get(std::string name) const {
  if (value_ctr.find(name)==value_ctr.end()) {
    scalar *result=new scalar[get_lenght()];
    for (scalar *scan=result, *end=result+get_lenght(); scan!=end; ++scan)

//It is set as infinity to signal the requested variable is missing
// nan is useless because it a legitimate value
//      *scan=std::numeric_limits<scalar>::quiet_NaN();
      *scan=std::numeric_limits<scalar>::infinity();
    return result;
  }
  else {
    std::vector<scalar> values_vector=*(value_ctr.find(name)->second);
    scalar *values=new scalar[values_vector.size()];
    copy(values_vector.begin(), values_vector.end(), values);
    return values;
  }
}

unsigned int DataTimeHistoryFile::get_lenght() const {
  return value_ctr.begin()->second->size();
}

unsigned int DataTimeHistoryFile::get_lenght(std::string name) const {
  if (value_ctr.find(name)==value_ctr.end())
    throw "variable \""+name
      +"\" not found in time history map; known variables are "
      +list_of_known_variables();

  return value_ctr.find(name)->second->size();
}

std::string DataTimeHistoryFile::list_of_known_variables() const {
  std::string result="{";
  for (std::map<std::string, std::vector<scalar> *>::const_iterator scan
	 =value_ctr.begin();
       scan!=value_ctr.end();
       ++scan)
    result+=" "+scan->first;
  result+=" }";
  return result;
}

void DataTimeHistoryFile::append(DataTimeHistoryFile const &dth,
                                 std::string time_label,
                                 bool shift_time,
                                 scalar time_shift) {
  for (map<string, vector<scalar> *>::iterator scan=value_ctr.begin();
       scan!=value_ctr.end();
       ++scan) {
    scalar shift=0.;
    if (scan->first==time_label) {
      if (shift_time)
        shift=time_shift;
      else {
        vector<scalar> *time_value=scan->second;
        scalar last_orig_time=*(time_value->end()-1);
        scalar next_to_last_orig_time=*(time_value->end()-2);
        scalar dt=last_orig_time-next_to_last_orig_time;
        scalar first_append_time=
          dth.value_ctr.find(time_label)->second->front();
        shift=last_orig_time+dt-first_append_time;
      }
    }

    vector<scalar> *dth_value=dth.value_ctr.find(scan->first)->second;
    transform(dth_value->begin(),
              dth_value->end(),
              std::back_insert_iterator<vector <scalar> >(*scan->second),
              std::bind1st(std::plus<scalar>(), shift));
  }
}

bool DataTimeHistoryFile::is_variable_file(std::string variable) const {
 if (value_ctr.find(variable)==value_ctr.end()) return false;
 return true;
}

scalar DataTimeHistoryFile::initial_value(std::string const var)
{
  scalar const *init = get(var);
  scalar const result = *init;
  delete[] init;
  return result;
}

scalar DataTimeHistoryFile::last_value(std::string const var)
{
  scalar const *init = get(var);
  scalar const result = *(init + get_lenght()-1);
  delete[] init;
  return result;
}



/* DataTimeHistoryTable ******************************************************************/

DataTimeHistoryTable::DataTimeHistoryTable(std::string const file_name,
					   std::string const var_x,
					   pointer_type(Functor_1<std::vector<std::string>,
							std::ifstream *>) read_header):
  DataTimeHistoryFile(file_name,read_header),
  map_tables()
{
  unsigned int const data_size = get_lenght(var_x);
  scalar const *nodes  = get(var_x);

  for(std::map<std::string,std::vector<scalar> *>::const_iterator scan= value_ctr.begin();
      scan!=value_ctr.end();++scan)
    {
      scalar const *values = get(scan->first);
      
      map_tables[scan->first]= new_shared_ptr(new Table_1D_linear(new Data_1D(nodes,values,data_size),
								  Table_1D::limit)); 
      // FIXME: Correct the memory leaks in the destructor
    }
  
}

DataTimeHistoryTable::~DataTimeHistoryTable()
{
}

scalar DataTimeHistoryTable::value(scalar var_x_value,std::string var_name)
{
  return map_tables[var_name]->function(var_x_value);
}



/* Table_1D ******************************************************************/

unsigned int Table_1D::posterior_index_x(scalar x) const
{
   return ::posterior_index(data->nodes_x, data->n_nodes_x, x);
}

/* Table_1D_linear ***********************************************************/

scalar Table_1D_linear::operator()(scalar const &x) const
{
   unsigned i_post_x=posterior_index_x(x);
   scalar x_lim=x;
   if (i_post_x==0) {
      i_post_x=1;
      if (mode_x==limit)
	x_lim=data->nodes_x[0];
   }
   else if (i_post_x==data->n_nodes_x) {
      i_post_x=data->n_nodes_x-1;
      if (mode_x==limit)
	x_lim=data->nodes_x[data->n_nodes_x-1];
   }

   return linear(x_lim,
		 data->nodes_x[i_post_x-1], data->values[i_post_x-1],
		 data->nodes_x[i_post_x], data->values[i_post_x]);
}


/* Data_2D_file **********************************************************/

Data_2D_file::Data_2D_file(char const *file_name)
{
   //- cout << "reading table 2D from the file " << file_name << endl;
   vector<scalar> vector_nodes_x;
   vector<scalar> vector_nodes_y;
   vector<scalar> vector_values;
   ifstream file(file_name);
   if (!file.is_open())
       cerr <<"ERROR: THE FILE CANNOT BE OPENED: "<<file_name<<endl;
   assert (file.is_open() );
   int n_line=0;

   // ignore line if it is empty or begins with "#"
   string line_string;
   while (syntactically_empty_line(line_string)) {
      getline(file, line_string);
      n_line++;
   }

   // process line
   istringstream line(string(line_string,
                             line_string.find_first_not_of(" |\t")));
   while (line) {
      // extract node
      unchecked_scalar new_node;
      line >> new_node;

      // if it is passed, there are no more nodes
      if (!line)
	continue;

      if (line.fail()) {
	 cout << "error reading node from the file " << file_name
              << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }

      // add node to the 'x' nodes vector
      vector_nodes_x.push_back(new_node);
      //- cout << new_node << " ";
   }
   //- cout << endl;

   // load data from 'x' nodes in base class Data_2D
   n_nodes_x=vector_nodes_x.size();
   scalar *nodes_x=new scalar[n_nodes_x];
   copy(vector_nodes_x.begin(), vector_nodes_x.end(), nodes_x);
   Data_2D::nodes_x=nodes_x;

   // read the separation line with "=============="
   string separation;
   getline(file, separation);
   n_line++;
   while (syntactically_empty_line(separation)) {
      getline(file, separation);
      n_line++;
   }
   //- cout << "========================================"
   //-         "========================================" << endl;

   // process the rest of the lines, composed of one node, one separation
   // character, "|", and the values
   while (file) {
      // process new line
      string line_string;
      getline(file, line_string);
      n_line++;

      // ignore if it is empty or begins with "#"
      if (syntactically_empty_line(line_string))
	continue;

      // extract node and separation
      istringstream line(line_string);
      unchecked_scalar new_node;
      char separation;
      line >> new_node;
      if (line.fail()) {
	 cout << "error reading node from the file " << file_name
              << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }
      line >> separation;
      if (separation!='=' && separation!='|') {
	 cout << "error separation in file " << file_name
	      << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }

      // add node to the 'y' nodes vector
      vector_nodes_y.push_back(new_node);
      //- cout << new_node << " | ";

      // read the values
      unsigned int n_values=0;
      while (line) {
	 // extract value
	 unchecked_scalar new_value;
	 line >> new_value;

	 // if it has passed, go to the following line
	 if (!line)
	   continue;

	 if (line.fail()) {
	    cout << "error reading value from file " << file_name
                 << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }

	 // add node to the 'y' nodes vector, and update counter in order
	 // to check that the number of values in this line is equal to
	 // the number of 'x' nodes
	 n_values++;
	 vector_values.push_back(new_value);
	 //- cout << new_value << " ";
      }
      if (n_nodes_x!=n_values) {
	 cout << "error (no. nodes != no. values) in file " << file_name
	      << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }
      //- cout << endl;
   }

   n_nodes_y=vector_nodes_y.size();
   scalar *nodes_y=new scalar[n_nodes_y];
   copy(vector_nodes_y.begin(), vector_nodes_y.end(), nodes_y);
   Data_2D::nodes_y=nodes_y;
   scalar *values=new scalar[n_nodes_x*n_nodes_y];
   copy(vector_values.begin(), vector_values.begin()+n_nodes_x*n_nodes_y,
	values);
   Data_2D::values=values;
}

Data_2D_file::~Data_2D_file()
{
   delete[] nodes_x;
   delete[] nodes_y;
   delete[] values;
}

/* Table_2D ******************************************************************/

unsigned int Table_2D::posterior_index_x(scalar x) const
{
   return ::posterior_index(data->nodes_x, data->n_nodes_x, x);
}

unsigned int Table_2D::posterior_index_y(scalar y) const
{
   return ::posterior_index(data->nodes_y, data->n_nodes_y, y);
}

scalar Table_2D::value(unsigned int index_x, unsigned int index_y) const
{
   return data->values[index_x+index_y*data->n_nodes_x];
}

/* Table_2D_linear ***********************************************************/

scalar Table_2D_linear::operator()(scalar const &x, scalar const &y) const
{

   unsigned i_post_x=posterior_index_x(x);
   scalar x_lim=x;
   if (i_post_x==0) {
      i_post_x=1;
      if (mode_x==limit)
	x_lim=data->nodes_x[0];
   }
   else if (i_post_x==data->n_nodes_x) {
      i_post_x=data->n_nodes_x-1;
      if (mode_x==limit)
	x_lim=data->nodes_x[data->n_nodes_x-1];
   }

   unsigned i_post_y=posterior_index_y(y);
   scalar y_lim=y;
   if (i_post_y==0) {
      i_post_y=1;
      if (mode_y==limit)
	y_lim=data->nodes_y[0];
   }
   else if (i_post_y==data->n_nodes_y) {
      i_post_y=data->n_nodes_y-1;
      if (mode_y==limit)
	y_lim=data->nodes_y[data->n_nodes_y-1];
   }

   // first it is interpolated through 'x', keeping 'y' constant
   scalar v_y1=
     linear(x_lim,
	    data->nodes_x[i_post_x-1], value(i_post_x-1, i_post_y-1),
	    data->nodes_x[i_post_x], value(i_post_x, i_post_y-1));
   scalar v_y2=
     linear(x_lim,
	    data->nodes_x[i_post_x-1], value(i_post_x-1, i_post_y),
	    data->nodes_x[i_post_x], value(i_post_x, i_post_y));
   // now it is interpolated through 'y' between 'v_y1' and 'v_y2'
   return linear(y_lim,
		 data->nodes_y[i_post_y-1], v_y1,
		 data->nodes_y[i_post_y], v_y2);
}

/* Data_3D_file **********************************************************/

Data_3D_file::Data_3D_file(char const *file_name)
{
   //- cout << "reading of  table 3D from the file " << file_name << endl;
   vector<scalar> vector_nodes_x;
   vector<scalar> vector_nodes_y;
   vector<scalar> vector_nodes_z;
   vector<scalar> vector_values;
   ifstream file(file_name);
   if (!file.is_open())
       cerr <<"ERROR: THE FILE CANNOT BE OPENED: "<<file_name<<endl;
   assert (file.is_open() );
   int n_line=0;

   bool new_nodes_xy = true;


   while (file) {

      int go_on = true;

      // process line
      string line_string;
      getline(file, line_string);
      n_line++;

      if (syntactically_empty_line(line_string))
	continue;

      istringstream line(line_string);
      unchecked_scalar new_node;
      char separation_z;
      line >> new_node;
      if (line.fail()) {
         cout << "error reading node from file " << file_name
              << ", line " << n_line << endl;
         throw runtime_error("error reading table");
      }
      line >> separation_z;
      if (separation_z!='|') {
         cout << "error of separator in file " << file_name
	      << ", line " << n_line << endl;
	 throw runtime_error("error reading table");
      }

      // add node to the 'z' nodes vector
      vector_nodes_z.push_back(new_node);

      if (new_nodes_xy){

         while (line) {
            // extract node
            unchecked_scalar new_node;
            line >> new_node;

            // if it has passed, there are no more nodes
            if  (!line)
               continue;

            if (line.fail()) {
	       cout << "error reading node from file " << file_name
                    << ", line " << n_line << endl;
	       throw runtime_error("error reading table");
            }

            // add node to the 'x' nodes vector
            vector_nodes_x.push_back(new_node);
            //- cout << new_node << " ";
         }
         //- cout << endl;

         // load data from 'x' nodes in the base class Data_3D
         n_nodes_x=vector_nodes_x.size();
         scalar *nodes_x=new scalar[n_nodes_x];
         copy(vector_nodes_x.begin(), vector_nodes_x.end(), nodes_x);
         Data_3D::nodes_x=nodes_x;
      }
      // read the separation line with "=============="
      string separation;
      getline(file, separation);
      n_line++;
      while (syntactically_empty_line(separation)) {
         getline(file, separation);
         n_line++;
      }

   //- cout << "========================================"
   //-         "========================================" << endl;

   // process the rest of the lines, composed of a node, a separation
   // character, "|", and the values
      while (go_on) {
         // process new line
         string line_string;
         getline(file, line_string);
         n_line++;

         // ignore if it is empty or begins with "#"
	 if (syntactically_empty_line(line_string))
	   continue;

         // if the line begins with '=' search for z nodes again
         if (line_string.size() >= 1
		   && (line_string[0]=='=')){
	    new_nodes_xy = false;
	    go_on = false;
	    continue;
         }
         // extract node and separation
         istringstream line(line_string);
         unchecked_scalar new_node;
         char separation;
         line >> new_node;
         if (line.fail()) {
	    cout << "error reading node from file " << file_name
                 << ", line " << n_line << endl;
	    throw runtime_error("error reading table");
         }
         line >> separation;
         if (separation!='|') {
	    cout << "error of separator in file " << file_name
	         << ", line " << n_line << endl;
	    throw runtime_error("error reading table");
         }
         // add node to the 'y' nodes vector

         if (new_nodes_xy){
	    vector_nodes_y.push_back(new_node);
         }

         //- cout << new_node << " | ";

         // read the values
         unsigned int n_values=0;
         while (line) {
	    // extract value
	    unchecked_scalar new_value;
	    line >> new_value;

	    // if it has passed, go to the following line
	    if (!line)
	      continue;

	    if (line.fail()) {
	       cout << "error reading value from file " << file_name
                    << ", line " << n_line << endl;
	       throw runtime_error("error reading table");
            }

	    // add node to the 'y' nodes vector, and update counter in order
	    // to check that number of values in this line is equal to the
	    // number of 'x' nodes
	    n_values++;
	    vector_values.push_back(new_value);

	    //- cout << new_value << " ";
         }
         if (n_nodes_x!=n_values) {
	    cout << "error (no. nodes != no. values) in file "
	         << file_name << ", line " << n_line << endl;
	    throw runtime_error("error reading table");
         }

         //- cout << endl;
      }

   }
   n_nodes_y=vector_nodes_y.size();
   scalar *nodes_y=new scalar[n_nodes_y];
   copy(vector_nodes_y.begin(), vector_nodes_y.end(), nodes_y);
   Data_3D::nodes_y=nodes_y;

   n_nodes_z=vector_nodes_z.size();
   scalar *nodes_z=new scalar[n_nodes_z];
   copy(vector_nodes_z.begin(), vector_nodes_z.end(), nodes_z);
   Data_3D::nodes_z=nodes_z;

   scalar *values=new scalar[n_nodes_x*n_nodes_y*n_nodes_z];
   copy(vector_values.begin(), vector_values.begin()+
        n_nodes_x*n_nodes_y*n_nodes_z, values);

   Data_3D::values=values;
}

Data_3D_file::~Data_3D_file()
{
   delete[] nodes_x;
   delete[] nodes_y;
   delete[] nodes_z;
   delete[] values;
}

/* Table_3D ******************************************************************/

unsigned int Table_3D::posterior_index_x(scalar x) const
{
   return ::posterior_index(data->nodes_x, data->n_nodes_x, x);
}

unsigned int Table_3D::posterior_index_y(scalar y) const
{
   return ::posterior_index(data->nodes_y, data->n_nodes_y, y);
}

unsigned int Table_3D::posterior_index_z(scalar z) const
{
   return ::posterior_index(data->nodes_z, data->n_nodes_z, z);
}

scalar Table_3D::value(unsigned int index_x, unsigned int index_y,
                       unsigned int index_z) const
{
   return data->values[index_x+index_y*data->n_nodes_x+
                         index_z*data->n_nodes_x*data->n_nodes_y];
}

/* Table_3D_linear ***********************************************************/

scalar Table_3D_linear::operator()(scalar const &x,
                                   scalar const &y,
                                   scalar const &z) const
{
   unsigned i_post_x=posterior_index_x(x);
   scalar x_lim=x;
   if (i_post_x==0) {
      i_post_x=1;
      if (mode_x==limit)
	x_lim=data->nodes_x[0];
   }
   else if (i_post_x==data->n_nodes_x) {
      i_post_x=data->n_nodes_x-1;
      if (mode_x==limit)
	x_lim=data->nodes_x[data->n_nodes_x-1];
   }

   unsigned i_post_y=posterior_index_y(y);
   scalar y_lim=y;
   if (i_post_y==0) {
      i_post_y=1;
      if (mode_y==limit)
	y_lim=data->nodes_y[0];
   }
   else if (i_post_y==data->n_nodes_y) {
      i_post_y=data->n_nodes_y-1;
      if (mode_y==limit)
	y_lim=data->nodes_y[data->n_nodes_y-1];
   }

   unsigned i_post_z=posterior_index_z(z);
   scalar z_lim=z;
   if (i_post_z==0) {
      i_post_z=1;
      if (mode_z==limit)
	z_lim=data->nodes_z[0];
   }
   else if (i_post_z==data->n_nodes_z) {
      i_post_z=data->n_nodes_z-1;
      if (mode_z==limit)
	z_lim=data->nodes_z[data->n_nodes_z-1];
   }

   // It is interpolated through 'x', with 'y' constant for the previous 'z' value.

   scalar v_y1_z1=
     linear(x_lim,
	  data->nodes_x[i_post_x-1], value(i_post_x-1, i_post_y-1, i_post_z-1),
	  data->nodes_x[i_post_x], value(i_post_x, i_post_y-1, i_post_z-1));
   scalar v_y2_z1=
     linear(x_lim,
	  data->nodes_x[i_post_x-1], value(i_post_x-1, i_post_y, i_post_z-1),
	  data->nodes_x[i_post_x], value(i_post_x, i_post_y, i_post_z-1));
   // now, it is interpolated through 'y' between 'v_y1_z1' and 'v_y2_z1'
   scalar v_z1= linear(y_lim,
		       data->nodes_y[i_post_y-1], v_y1_z1,
		       data->nodes_y[i_post_y], v_y2_z1);

   // It is interpolated through 'x', with 'y' constant for the next 'z' value.

   scalar v_y1_z2=
     linear(x_lim,
	  data->nodes_x[i_post_x-1], value(i_post_x-1, i_post_y-1, i_post_z),
	  data->nodes_x[i_post_x], value(i_post_x, i_post_y-1, i_post_z));
   scalar v_y2_z2=
     linear(x_lim,
	  data->nodes_x[i_post_x-1], value(i_post_x-1, i_post_y, i_post_z),
	  data->nodes_x[i_post_x], value(i_post_x, i_post_y, i_post_z));

   // Now, it is interpolated through 'y' between 'v_y1_z2' and 'v_y2_z2'
   scalar v_z2= linear(y_lim,
		       data->nodes_y[i_post_y-1], v_y1_z2,
		       data->nodes_y[i_post_y], v_y2_z2);

//cout<<"The second value is: "<< v_z2<< endl;

   // Finally, it is interpolated between v_z1 and v_z2
   return  linear(z_lim,
		  data->nodes_z[i_post_z-1], v_z1,
		  data->nodes_z[i_post_z], v_z2);

}
