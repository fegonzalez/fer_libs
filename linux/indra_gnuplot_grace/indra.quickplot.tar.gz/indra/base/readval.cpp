#include "readval.h"


ReadValues::ReadValues(std::string file) {
  std::ifstream in(file.c_str());
  while (in) {
    std::string line_string;
    getline(in, line_string);
    std::string::size_type name_begin=
      line_string.find_first_not_of(" \t");
    if ((name_begin==std::string::npos) or (line_string[name_begin]=='#'))
      continue;
    std::string::size_type name_end=
      line_string.find_first_of(" \t", name_begin);
    std::string name(line_string, name_begin, name_end);
    std::string value(line_string,
                      line_string.find_first_not_of(" \t", name_end));
    map_name_value[name]=value;
  }
}

std::string find_substring(std::string const data,std::string const init_mark,
			   std::string const final_mark)  {

  std::string init = init_mark;
  std::string end = final_mark;

  size_t found_init = data.find(init);
  size_t found_end = data.find(final_mark,found_init+1);
  
  std::string value =data.substr(found_init+init.size(), 
				 found_end-found_init-init.size());

  return value;

}
