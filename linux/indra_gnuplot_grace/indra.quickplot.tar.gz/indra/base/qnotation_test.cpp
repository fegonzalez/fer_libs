#include "qnotation.h"

using namespace std;

int main(){

QNotation<8,7> q,p;
QNotation<8,23> r_8_23;

//TEST 1
cout<<"************************************"<<endl;
cout<<"TEST 1: Decimal to Binary conversor"<<endl;
cout<<"************************************"<<endl;

int container[16];

int size_container=sizeof(container)/sizeof(int);

cout <<"size of(container)="<<size_container<< endl;

for(int j=0;j<size_container;j++)
  	   container[j]=0;

for(int j=0;j<10;j++){

	int valor=j;
	decimal_to_binary(valor,container,size_container);

	cout << "binary("<<valor<<")=";
	for(int i=size_container;i>-1;i--)
		if(container[i])
			cout<< "1";
		else 
			cout<< "0";
	cout << endl;
}

//TEST 2
cout<<"****************************************************"<<endl;
cout<<"TEST 2: Integer and Fraccional Parts -> Qi.f noation"<<endl;
cout<<"****************************************************"<<endl;

#define printFracBin(x) \
   q.set_fractional(x); \
   cout << "fractional_bin(" #x << ") = ("; \
   q.print_fractional(); \
   cout << " )" << endl;

printFracBin(0.507);
printFracBin(0.5079);
printFracBin(0.992);
printFracBin(1.991);
printFracBin(-0.991);
printFracBin(-1.991);

#define printIntegerBin(x) \
   q.set_integer(x); \
   cout << "integer_bin(" #x << ") = ("; \
   q.print_integer(); \
   cout << " )" << endl;

printIntegerBin(1.991);
printIntegerBin(-0.991);
printIntegerBin(-1.991);


cout<<"**********************************************"<<endl;
cout << "TEST 3 : Transform: scalar --> Qi.f notation "<<endl;
cout<<"**********************************************"<<endl;
scalar x=11.875;
q=x;
cout << "integer_bin("<< x << ")="<<"(";
q.print_integer();
cout << ")" << endl;
cout << "fractional_bin("<< x << ")="<<"(";
q.print_fractional();
cout << ")" << endl;

cout << "qnotation("<< x << ")="<<"(";
q.print();
cout << ")" << endl;

cout<<"**********************************************"<<endl;
cout << "TEST 4 : Transform: Qi.f notation --> scalar"<<endl;
cout<<"**********************************************"<<endl;
int binary_zone[16]={0,0,0,0,0,1,0,1,1,1,1,1,0,0,0,0};
int size_binary_zone=sizeof(binary_zone)/sizeof(int);
p.set_binary(binary_zone,size_binary_zone);

cout << "get_integer(";
p.print(); cout << ")=" << p.get_integer() << endl;

cout << "get_fractional(";
	  p.print(); cout << ")=" << p.get_fractional() << endl;

cout << "get_scalar(";
	  p.print(); cout << ")=" << p.get_scalar() << endl;

int binary_zone_1[32]=
	{0,0,0,0,1,0,
	 0,1,0,0,0,1,
	 0,0,0,1,1,0,
	 1,1,1,1,1,0,
	 0,1,1,1,1,0,0,1};
size_binary_zone=sizeof(binary_zone_1)/sizeof(int);

r_8_23.set_binary(binary_zone_1,size_binary_zone);


cout << "get_integer(";
     r_8_23.print(); cout << ")=" << r_8_23.get_integer() << endl;


int binary_zone_2[32]=
	{0,1,0,1,0,1,0,
	1,0,0,1,1,0,
	0,0,0,1,1,1,
	1,1,1,1,1,1,
	0,1,1,0,0,1,
	 1};

size_binary_zone=sizeof(binary_zone_2)/sizeof(int);

r_8_23.set_binary(binary_zone_2,size_binary_zone);


cout << "get_integer(";
     r_8_23.print(); cout << ")=" << r_8_23.get_integer() << endl;

 

cout<<"*****************************************************************"<<endl;
cout << "TEST 5 : Get single Byte types                                 "<< endl;
cout<<"*****************************************************************"<<endl;

cout << "Get16bits (unsigned int):" << q.get_16bits() << endl;
cout << "Get32bits (unsigned long int):" << q.get_32bits() << endl;

cout << "GetBits (11.875):" << q.get_bits() << endl;

r_8_23=32.7011;
cout << "GetBits (32.7011):" << r_8_23.get_bits() << endl;
r_8_23=-97.0503;
cout << "GetBits (-97.0503):" << r_8_23.get_bits() << endl;


}

