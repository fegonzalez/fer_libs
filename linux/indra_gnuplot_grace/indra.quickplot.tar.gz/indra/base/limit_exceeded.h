#ifndef _LIMIT_EXCEEDED_H_
#define _LIMIT_EXCEEDED_H_

#include "scalar.h"
class Point
{
 public:
  Point(scalar _x, scalar _y){x=_x;y=_y;}
  Point():x(0.0), y(0.0){};
  ~Point(){}
  void SetX(scalar _x){x = _x;}
  void SetY(scalar _y){y = _y;}
  scalar GetX(void){return x;}
  scalar GetY(void){return y;}
 private:
  scalar x;
  scalar y;
};

/*--------------------- ConstantLimit -------------------------------------*/
/* Class to check if a given value is less than an imposed limit.
   The method CheckValue returns TRUE whether the porvided value is less
   than the imposed limit.
   -------------------------------------------------------------------------*/
class ConstantLimit
{
 public:
  // Constructor
  // The limit can be imposed by value or reference.
  ConstantLimit(scalar _limit);
  ConstantLimit(scalar *_limit);
  // Desctructor
  ~ConstantLimit(){}
  
  void SetLimit(scalar _limit){imposedLimit = _limit;}
  scalar GetLimit(void){return imposedLimit;}

  // Returns true when the provided is lower than the imposed limit
  bool CheckValue(scalar value){return(value<*pointerToLimit) ? true : false;}
 
 private:
  scalar imposedLimit;
  scalar *pointerToLimit;
};
typedef ConstantLimit UpperConstantLimit;

/*--------------------- ConstantLimitTimer ----------------------------------*/
/* Class to check if a given value exceed a imposed limit more than a 
   given time (_intervalTime in seconds).
   --------------------------------------------------------------------------*/
class ConstantLimitTimer:private ConstantLimit 
{
 public:
  ConstantLimitTimer(scalar _limit, scalar _intervalTime, scalar _dt);
  ConstantLimitTimer(scalar *_limit, scalar _intervalTime, scalar _dt);
  ~ConstantLimitTimer(){}
  bool CheckValueInTime(scalar value);
 private:
  scalar dt;
  scalar timeLimit;
  scalar currentTime;
  bool launchedTimer;
};

typedef ConstantLimitTimer UpperConstantLimitTimer;


/*--------------------- LowerConstantLimit -------------------------------------*/
/* Class to check if a given value is greater than an imposed limit.
   The method CheckValue returns TRUE whether the porvided value is greater
   than the imposed limit.
   -------------------------------------------------------------------------*/
class LowerConstantLimit
{
 public:
  // Constructor
  LowerConstantLimit(scalar _limit);
  LowerConstantLimit(scalar *_limit);
  // Desctructor
  ~LowerConstantLimit(){}
  
  void SetLimit(scalar _limit){imposedLimit = _limit;}
  scalar GetLimit(void){return imposedLimit;}

  // Returns true when the provided is lower than the imposed limit
  bool CheckValue(scalar value){return(value>*pointerToLimit) ? true : false;}
 
 private:
  scalar imposedLimit;
  scalar *pointerToLimit; 
};
  
/*--------------------- LowerConstantLimitTimer ------------------------------*/
/* Class to check if a given value is greater than an imposed limit more than a 
   given time (_intervalTime in seconds).
   --------------------------------------------------------------------------*/
class LowerConstantLimitTimer:private LowerConstantLimit 
{
 public:
  LowerConstantLimitTimer(scalar _limit, scalar _intervalTime, scalar _dt);
  LowerConstantLimitTimer(scalar *_limit, scalar _intervalTime, scalar _dt);
  ~LowerConstantLimitTimer(){}
  bool CheckValueInTime(scalar value);
 private:
  scalar dt;
  scalar timeLimit;
  scalar currentTime;
  bool launchedTimer;
};


/*--------------------- IntervalLimit -------------------------------------------------*/
/* Class to define an interval where we can check whether a point (x,y)  is
   inside the limit. The interval shall be defined through two points that define a line.
   This class provides a  method (inInterval) in order to check whether a point is inside 
   the area between the defined interval and the X axis.
  -------------------------------------------------------------------------------------*/
class IntervalLimit
{
 public:
  // Constructor. The limit shall be defined through two points which define a line
  IntervalLimit(Point _initialPoint, Point _finalPoint): initialPoint(_initialPoint), finalPoint(_finalPoint){}  
  IntervalLimit(void){}
  // Destructor
  ~IntervalLimit() {}
  
  // Returns TRUE if the (x,y) point is in the area between the defined interval and the X axis.
  bool inInterval(Point pointToCheck);

  void SetInitialPoint(Point i){initialPoint = i;}
  void SetFinalPoint(Point i){finalPoint = i;}

  Point GetInitialPoint(void){return initialPoint;}
  Point GetFinalPoint(void){return finalPoint;}

 private:
  // Initial point of the interval
  Point initialPoint;
  // Final point of the interval
  Point finalPoint;
  // Returns the increase of x
  scalar DeltaX(){return(finalPoint.GetX()-initialPoint.GetX());}
  // Returns the increase of y
  scalar DeltaY(){return(finalPoint.GetY()-initialPoint.GetY());}
};


/*------------------------ GraphLimit -------------------------------------------------*/
/* Builds a graph with a list of points 
   in order to check if a point is inside of 
   the region between the created graph and the x axis 
  -------------------------------------------------------------------------------------*/
class GraphLimit
{
 public:
 //Constructor
 GraphLimit(int numberOfPoints,Point* p_pointsList);

 // Destructor
 ~GraphLimit(){delete [] p_intervals;}
 
 // Returns TRUE if the (x,y) point is in the area between the defined interval graph and de X axis.
 bool CheckPoint(Point pointToCheck);

 // Shows the points that describe the graph
 void ShowData (void);

 private:
  int numberOfIntervals;
  IntervalLimit* p_intervals;
  scalar LowerLimitSlope(void);
  Point* p_points;
};


/*------------------------ GraphLimitTimer--------------------------------------------*/
/* Builds a GraphLimit including a timer to check whether the provided points are
   outside the graph limits more than a given time (_intervalTime in seconds).
   -----------------------------------------------------------------------------------*/
class GraphLimitTimer:private GraphLimit 
{
 public:
  GraphLimitTimer(int numberOfPoints, Point* p_pointList, scalar _intervalTime, scalar _dt);
  bool CheckPointInTime(Point pointToCheck);
 private:
  scalar dt;
  scalar timeLimit;
  scalar currentTime;
  bool launchedTimer;
};


#endif
