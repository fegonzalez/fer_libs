#ifndef TABLE_HEADER_
#define TABLE_HEADER_

#include "functor.h"
#include "base.h"
#include "autodel.h"
#include "shared_ptr.h"
#include "pointer_policy.h"
#include <map>
#include <vector>
#include <string>

class HeaderReaderDefault :
  public Functor_1<std::vector<std::string>, std::ifstream *> {
public:
  std::vector<std::string> operator()(std::ifstream * const & file) const;
};

/* The implementation of the search in tables is made in two levels. In the
 * first level, the table data is defined by its nodes and the values
 * in its nodes. In the second level, a function is defined, so that,
 * when evaluated in the nodes, the values specified in the table nodes
 * are returned. */

/* The following class is for defining one-dimensional tables, by means
 * of memory arrays. In order to define Data_1D, the number of nodes,
 * one array of nodes and one array of values in the nodes are passed to
 * the constructor. The nodes in the array have to be arranged in
 * increasing order. */

 class Data_1D {
 public:
   // nodes have to be arranged in increasing order
   Data_1D(scalar const nodes_x_[],
	    scalar const values_[],
	    unsigned int n_nodes_x_)
     : nodes_x(nodes_x_), values(values_), n_nodes_x(n_nodes_x_) { };
   virtual ~Data_1D() { };
 protected:
   Data_1D()
     : nodes_x(), values(), n_nodes_x() { };
 public:
   scalar const *nodes_x;
   scalar const *values;
   unsigned int n_nodes_x;
};

/* The following class is for defining one-dimensional tables, by means of
 * data read from a text file.
 *
 * File format. The file is formed by lines. The lines which only contain
 * gaps or which begin with "#" are ignored. Each line is formed by a node,
 * followed by the character "|" and the value in that node. Example:
 *
 *   0 |   0
 *   3 |   9
 *   6 |  36
 *   9 |  81
 *  12 | 144
 * */
class Data_1D_file
: public Data_1D {
 public:
   Data_1D_file(char const *file_name);
   ~Data_1D_file();
};


/* The following class is for defining one-dimensional tables. In this case
* the table have a copy of nodes and vaues arrays instead original Data_1D
* class. */
class Data_1D_copy
: public Data_1D {
 public:
   Data_1D_copy(scalar const nodes_x_[],
	    scalar const values_[],
	    unsigned int n_nodes_x_);
   ~Data_1D_copy();
};



class DataTimeHistoryFile {
 public:
  DataTimeHistoryFile(std::string const file_name,
		      pointer_type(Functor_1<std::vector<std::string>,
       		                   std::ifstream *>) read_header
                      =new_pointer(HeaderReaderDefault));
//   DataTimeHistoryFile(std::string const file_name);

  ~DataTimeHistoryFile() {
     for (std::map<std::string, std::vector<scalar> *>::const_iterator scan=value_ctr.begin(),
          end=value_ctr.end();
          scan!=end;
          ++scan) {

        if(scan->second) {delete scan->second; /*scan->second=0;*/}
     }
     value_ctr.clear();
  }

  scalar const *get(std::string name) const;
  unsigned int get_lenght() const;
  unsigned int get_lenght(std::string name) const;
  void clear() {value_ctr.clear();}
  void append(DataTimeHistoryFile const &dth,
              std::string time_label,
              bool shift_time=false, // by defalt, append with no time gap
              scalar time_shift=0.);
  bool is_variable_file(std::string variable) const;
  scalar initial_value(std::string const var);
  scalar last_value(std::string const var);

 protected:
  std::map<std::string, std::vector<scalar> *> value_ctr;
  std::string list_of_known_variables() const;
};

class Table_1D_linear;
class DataTimeHistoryTable: public DataTimeHistoryFile
{
public:

  DataTimeHistoryTable(std::string const file_name,
		       std::string const var_x,
		       pointer_type(Functor_1<std::vector<std::string>,
				    std::ifstream *>) read_header
		       =new_pointer(HeaderReaderDefault));
  
  ~DataTimeHistoryTable();

  scalar value(scalar var_x_value,std::string var_name);

private:

  std::map<std::string,indra_lib::shared_ptr<Table_1D_linear> > map_tables;
};


/* Abstract class for searching in oDne-dimensional tables of scalars. Data
 * is passed to the constructor by a Data_1D, and the way (mode) of searching
 * outside the table limits is indicated (limit or extrapolate). */
class Table_1D : public Functor_1<scalar> {
 public:
   enum mode { limit, extrapolate };
   Table_1D(pointer_type(Data_1D const) data_,
	    mode mode_x_)
     : data(data_), mode_x(mode_x_) { };
   ~Table_1D() { release_pointer(data); };
   scalar first_node(void) const {
     return data->nodes_x[0];
   }
   scalar last_node(void) const {
     return data->nodes_x[data->n_nodes_x-1];
   }

 protected:

   unsigned int posterior_index_x(scalar x) const;

   pointer_type(Data_1D const) data;
   mode const mode_x;
};

class Table_1D_linear : public Table_1D {
 public:
   // nodes have to be arranged in increasing order
   Table_1D_linear(pointer_type(Data_1D const) data_,
		   mode mode_x_)
     : Table_1D(data_, mode_x_) { };

   scalar operator()(scalar const &x) const;
};


/* Class for defining two-dimensional tables, by means of arrays in memory.
 * Similar to Data_2D. */
class Data_2D {
 public:
   // nodes have to be in increasing order
   Data_2D(scalar const nodes_x_[], // 'x' faster than 'y'
	    scalar const nodes_y_[],
	    scalar const values_[],
	    unsigned int n_nodes_x_,
	    unsigned int n_nodes_y_)
     : nodes_x(nodes_x_), nodes_y(nodes_y_), values(values_),
       n_nodes_x(n_nodes_x_), n_nodes_y(n_nodes_y_) { };
 protected:
   Data_2D()
     : nodes_x(), nodes_y(), values(),
       n_nodes_x(), n_nodes_y() { };
 public:
   scalar const *nodes_x;
   scalar const *nodes_y;
   scalar const *values;
   unsigned int n_nodes_x;
   unsigned int n_nodes_y;
};

/* The following class is for defining two-dimensional tables, by means of
 * data read from a text file.
 *
 * File format. The file is formed by lines. Lines which only contain gaps
 * or which begin with "#" are ignored. The first line is formed by the 'x'
 * nodes. The second line is formed by a continuous sequence of "="
 * characters. The following lines are formed by a 'y' node, followed by the
 * "|" character and the values corresponding to the 'y' node and to each
 * 'x' node of the first line. Example:
 *
 *         2    3    5    7   11
 *     =========================
 *   0 |   0    6   10   14   22
 *   3 |   9   15   19   23   31
 *   6 |  36   42   46   50   58
 *   9 |  81   87   91   95  103
 *  12 | 144  150  154  158  166
 * */
class Data_2D_file
: public Data_2D {
 public:
   Data_2D_file(char const *file_name);
   ~Data_2D_file();
};

/* The same as Table_2D, but in two dimensions: one Data_2D, and two
 * ways of searching (modes) outside the table. */
class Table_2D : public Functor_2<scalar> {
 public:
   enum mode { limit, extrapolate };
   Table_2D(pointer_type(Data_2D const) data_,
	    mode mode_x_,
	    mode mode_y_)
     : data(data_), mode_x(mode_x_), mode_y(mode_y_) { };
   ~Table_2D() { reset_pointer(data); };
   scalar first_node_x(void) const {
     return data->nodes_x[0];
   }
   scalar last_node_x(void) const {
     return data->nodes_x[data->n_nodes_x-1];
   }
   scalar first_node_y(void) const {
     return data->nodes_y[0];
   }
   scalar last_node_y(void) const {
     return data->nodes_y[data->n_nodes_y-1];
   }

 public:

   unsigned int posterior_index_x(scalar x) const;
   unsigned int posterior_index_y(scalar y) const;
   scalar value(unsigned int index_x, unsigned int index_y) const;

   pointer_type(Data_2D const) data;
   mode const mode_x;
   mode const mode_y;
};

class Table_2D_linear : public Table_2D {
 public:
   Table_2D_linear(pointer_type(Data_2D const) data_,
		   mode mode_x_,
		   mode mode_y_)
     : Table_2D(data_, mode_x_, mode_y_) { };

   scalar operator()(scalar const &x, scalar const &y) const;
};

/* Class for defining three-dimensional tables, by means of arrays stored in
 * memory. Similar to Data_2D. */

class Data_3D {
 public:
   // nodes have to be arranged in increasing order
   Data_3D(scalar const nodes_x_[], // 'x' faster than 'y'
	    scalar const nodes_y_[],
	    scalar const nodes_z_[],
	    scalar const values_[],
	    unsigned int n_nodes_x_,
	    unsigned int n_nodes_y_,
	    unsigned int n_nodes_z_)
   : nodes_x(nodes_x_), nodes_y(nodes_y_), nodes_z(nodes_z_), values(values_),
     n_nodes_x(n_nodes_x_), n_nodes_y(n_nodes_y_), n_nodes_z(n_nodes_z_) { };
 protected:
   Data_3D()
     : nodes_x(), nodes_y(), nodes_z(), values(),
       n_nodes_x(), n_nodes_y(), n_nodes_z() { };
 public:
   scalar const *nodes_x;
   scalar const *nodes_y;
   scalar const *nodes_z;
   scalar const *values;
   unsigned int n_nodes_x;
   unsigned int n_nodes_y;
   unsigned int n_nodes_z;
};

/* Class for defining three-dimensional tables, by means of data read from
 * a text file.
 * There'll be as many tables as 'z' node values.
 * File format. The file is formed by lines. Lines that only contain gaps or
 * that begin with "#" are ignored. The first line is formed by the 'z' node
 * value, one separation character and the 'x' nodes values. The second line
 * is formed by a continuous sequence of "=" characters. The following lines
 * are formed by a 'y' node, followed by the "|" character and the values
 * corresponding to the 'y' node and each 'x' node of the first line.
 * The end of the table is defined by a line with '=' characters.
 *
 * Example:
 *
 *   1 |   2    3    5    7   11
 *  ============================
 *   0 |   0    6   10   14   22
 *   3 |   9   15   19   23   31
 *   6 |  36   42   46   50   58
 *   9 |  81   87   91   95  103
 *  12 | 144  150  154  158  166
 *  ============================
  * */
class Data_3D_file
: public Data_3D {
 public:
   Data_3D_file(char const *file_name);
   ~Data_3D_file();
};

/* The same as Table_2D, but three-dimensional: one Data_3D, and two ways
 * of searching (two modes) outside the table. */

class Table_3D : public Functor_3<scalar> {
 public:
   enum mode { limit, extrapolate };
   Table_3D(pointer_type(Data_3D const) data_,
	    mode mode_x_,
	    mode mode_y_,
	    mode mode_z_)
     : data(data_), mode_x(mode_x_), mode_y(mode_y_), mode_z(mode_z_){ };
   ~Table_3D() { reset_pointer(data); };
   scalar first_node_x(void) const {
     return data->nodes_x[0];
   }
   scalar last_node_x(void) const {
     return data->nodes_x[data->n_nodes_x-1];
   }
   scalar first_node_y(void) const {
     return data->nodes_y[0];
   }
   scalar last_node_y(void) const {
     return data->nodes_y[data->n_nodes_y-1];
   }
   scalar first_node_z(void) const {
     return data->nodes_z[0];
   }
   scalar last_node_z(void) const {
     return data->nodes_z[data->n_nodes_z-1];
   }

 protected:

   unsigned int posterior_index_x(scalar x) const;
   unsigned int posterior_index_y(scalar y) const;
   unsigned int posterior_index_z(scalar z) const;

   scalar value(unsigned int index_x, unsigned int index_y,
                unsigned int index_z) const;

   pointer_type(Data_3D const) data;
   mode const mode_x;
   mode const mode_y;
   mode const mode_z;
};

class Table_3D_linear : public Table_3D {
 public:
   Table_3D_linear(pointer_type(Data_3D const) data_,
		   mode mode_x_,
		   mode mode_y_,
		   mode mode_z_)
     : Table_3D(data_, mode_x_, mode_y_, mode_z_) { };

   scalar operator()(scalar const &x, scalar const &y, scalar const &z) const;
};


// class TableTimeHistory : public Functor_1<scalar> {
//  public:
//   enum mode { limit, extrapole };
//   TableTimeHistory(DataTimeHistory const *data, mode mode_x)
//     : data(data), mode_x(mode_x) { };
//   ~TableTimeHistory() { delete data;};
//   scalar first_node(void) const {
//     return data->nodes_x[0];
//   }
//   scalar last_node(void) const {
//     return data->nodes_x[data->n_nodes_x-1];
//   }
//  protected:
//   unsigned int posterior_index_x(scalar x) const;

//   DataTimeHistory const *data;
//   mode const mode_x;
// };

// class TableTimeHistoryLinear : public TableTimeHistory {
//  public:
//   TableTimeHistoryLinear(DataTimeHistory const *data,
// 			 mode mode_x)
//     : TableTimeHistory(data, mode_x) { };

//   scalar operator()(scalar const &x) const;
// };

#endif
