#include "checked_scalar.h"

using namespace std;

#ifdef SIMDEBUG_NAN
bool scalar_throw_on_error=false;
int nan_number=0;
int counter_look_nan=50;


// zero() gets NaN value(such as zero()/zero()) without making the compiler
// notice  (the compiler returns a warning in the 0./0. case)
double zero() { return 0.; }


scalar::scalar() : value(zero()/zero()) {}

double scalar_reset_value=zero()/zero(); // quiet NaN

void scalar::set_throw()
{
   scalar_throw_on_error=true;
}

void scalar::unset_throw()
{
   scalar_throw_on_error=false;
}

void scalar::set_reset_value_nan()
{
   scalar::set_reset_value(zero()/zero());
}

void scalar::set_reset_value(double new_reset_value)
{
   scalar_reset_value=new_reset_value;
}

void scalar::error() const
{
   if (scalar_throw_on_error)
     throw "not finite value in scalar";
   value=scalar_reset_value;

   //

   nan_number+=1;
   if(counter_look_nan>0)
   {
      counter_look_nan--;
      cout <<"Nan's number:"<<nan_number<<endl<<flush;
   }
   //

}

#endif
