#ifndef DERIVATE_HEADER
#define DERIVATE_HEADER

#include "base.h"
#include <cmath>
#include <cfloat>

class Derivate {
public:
    Derivate(scalar dt)
        : Dt(dt) { };
    virtual ~Derivate();

    virtual scalar derive(scalar x)=0;
    virtual scalar operator()() const { return output; }
    virtual void initialise(scalar x)=0;
protected:
    scalar const Dt;
    scalar output;
};

class RearDerivate : public Derivate {
public:
    RearDerivate(scalar dt) : Derivate(dt), x_n_2(), x_n_1(), x_n() { };
    scalar derive(scalar x) {
        x_n_2=x_n_1;
        x_n_1=x_n;
        x_n=x;
        output=((3.*x_n-4.*x_n_1+x_n_2)/(2.*Dt));
	return output;
    };
    void initialise(scalar x) {
        x_n_2=x;
        x_n_1=x;
        x_n=x;
    };
private:
    scalar x_n_2;
    scalar x_n_1;
    scalar x_n;
};

#endif
