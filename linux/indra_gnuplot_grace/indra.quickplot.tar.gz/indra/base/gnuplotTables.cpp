#include <vector>
#include <iostream>
#include <fstream>

#include "gnuplotTables.h"


using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;

// Constructor of the object for processing the data of the datafile for 1
// dimensional datafiles
//filename_in: name of the filename where data are
//filename_out: name of the filename used for recording Gnuplot compatible
// data



GnuplotDataTable_1D::GnuplotDataTable_1D(char const *filename_in,
                                         char const *filename_out)
    :datafile_object_1D(filename_in),
     table_object(new_pointer(Data_1D_file(filename_in)), Table_1D::limit)
{
    // Number of nodes and number of values (Must be the same)
    int n_nodes_x = datafile_object_1D.n_nodes_x;

    ofstream datafile_gnuplot_out(filename_out);


    // Extracting  file
    for(int j=0;j<n_nodes_x; j++)
    {
        datafile_gnuplot_out << datafile_object_1D.nodes_x[j] << "   "
                             << datafile_object_1D.values[j] << endl;
//         std::cout << datafile_object_1D.nodes_x[j] << "   "
//                   << datafile_object_1D.values[j] << endl;
    }
}



void GnuplotDataTable_1D::interpolate( char const *filename_out ,
                                      int n_points_x )
{
    // Interpolation in the table
    ofstream file_out_object(filename_out);

    scalar delta_x;

    if ( fabs(n_points_x) > 0.01)
    {
        delta_x =
            ( datafile_object_1D.nodes_x[datafile_object_1D.n_nodes_x-1] -
              datafile_object_1D.nodes_x[0] ) / n_points_x;
    }
    else
    {
        delta_x =
            ( datafile_object_1D.nodes_x[datafile_object_1D.n_nodes_x-1] -
              datafile_object_1D.nodes_x[0] ) / 10.0;
    }


    // Extracting  file
    for(int j=0;j<=n_points_x; j++)
    {
        scalar x_value = datafile_object_1D.nodes_x[0] + j * delta_x;

        file_out_object << x_value << "   "
                        << table_object(x_value)
                        << endl;
    }
}




GnuplotDataTable_2D::GnuplotDataTable_2D(char const *filename_in,
                                         char const *filename_out)
    :datafile_object_2D(filename_in),
     table_object(new_pointer(Data_2D_file(filename_in)),
                  Table_2D::limit,
                  Table_2D::limit )

{
    // Number of nodes and number of values (Must be the same)
    int n_nodes_x = datafile_object_2D.n_nodes_x;
    int n_nodes_y = datafile_object_2D.n_nodes_y;

    ofstream datafile_gnuplot_out(filename_out);

    // Extracting  file
    for(int h=0; h<n_nodes_y; h++)
    {
        for(int j=0;j<n_nodes_x; j++)
        {
            datafile_gnuplot_out << datafile_object_2D.nodes_y[h] << "   "
                                 << datafile_object_2D.nodes_x[j] << "   "
                                 << datafile_object_2D.values[h*n_nodes_x+j]
                                 << endl;

//             std::cout << datafile_object_2D.nodes_y[h] << "   "
//                       << datafile_object_2D.nodes_x[j] << "   "
//                       << datafile_object_2D.values[h*n_nodes_x+j] << endl;
        }
        datafile_gnuplot_out << std::endl;
    }
}




// This function is used when you want to interpolate in the table, not just
// drawing the points of the table but drawing the table softly.
void GnuplotDataTable_2D::interpolate( char const *filename_out ,
                                      int n_points_x ,
                                      int n_points_y )
{
    // Interpolation in the table
    ofstream file_out_object(filename_out);

    scalar delta_x, delta_y;

    if ( fabs(n_points_x) > 0.01)
    {
        delta_x =
            ( datafile_object_2D.nodes_x[datafile_object_2D.n_nodes_x-1] -
              datafile_object_2D.nodes_x[0] ) / n_points_x;
    }
    else
    {
        delta_x =
            ( datafile_object_2D.nodes_x[datafile_object_2D.n_nodes_x-1] -
              datafile_object_2D.nodes_x[0] ) / 10.0;
    }

    if ( fabs(n_points_y) > 0.01)
    {
        delta_y =
            ( datafile_object_2D.nodes_y[datafile_object_2D.n_nodes_y-1] -
              datafile_object_2D.nodes_y[0] ) / n_points_y;
    }
    else
    {
        delta_y =
            ( datafile_object_2D.nodes_y[datafile_object_2D.n_nodes_y-1] -
              datafile_object_2D.nodes_y[0] ) / 10.0;
    }


    // Extracting  file
    for(int h=0; h<=n_points_y; h++)
    {
        scalar y_value  = datafile_object_2D.nodes_y[0] + h * delta_y;

        for(int j=0;j<=n_points_x; j++)
        {
            scalar x_value  = datafile_object_2D.nodes_x[0] + j * delta_x;

            file_out_object << y_value   << "   "
                            << x_value << "   "
                            << table_object(x_value, y_value)
                            << endl;
//             std::cout  << y_value   << "   "
//                        << x_value << "   "
//                        << table_object(y_value, x_value)
//                        << endl;

        }
    }
}
