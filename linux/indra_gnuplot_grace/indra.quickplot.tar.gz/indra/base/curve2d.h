#ifndef _CURVE2D_MATH_H
#define _CURVE2D_MATH_H

#include <stdio.h>
#include <vector>
#include "functor.h"
#include "../base/base.h"

//Class included
class ControlPoints;
class Polycurve2d;
class Spline2d;
class Bezied2d;

class Ramp {

 public :

  Ramp():
   init_pos(0.),
   init_value(0.0),
   end_pos(1.0),
   end_value(0.0)
 {}

  Ramp(scalar init_pos,
       scalar init_value,
       scalar end_pos,
       scalar end_value) :
        init_pos(init_pos),
        init_value(init_value),
        end_pos(end_pos),
        end_value(end_value) {}

  void define(scalar init_pos_,
              scalar init_value_,
              scalar end_pos_,
              scalar end_value_) {
       Ramp(init_pos_,init_value_,end_pos_,end_value_);
    return;
  }

  scalar eval(scalar value) {
   return ramp(value,init_pos,init_value,end_pos,end_value);
  }

  scalar operator()(scalar value) {return eval(value);}

 public :
  scalar init_pos;
  scalar init_value;
  scalar end_pos;
  scalar end_value;

};

struct _POINT {
	float x;
	float y;
	float arco;

    _POINT():x(0),y(0),arco(0){}

};

class ControlPoints {

  public :

  ControlPoints();
  ControlPoints(ControlPoints &last);
  ~ControlPoints();

  public :
  std::vector <_POINT> points;

  public :

  void add_controlpoint(float x,float y);
  void add_controlpoint(double x, double y)
    { add_controlpoint(float(x), float(y)); }
  void add_controlpoint(char *filename);
  void delete_controlpoint(int pos);
  void edit_controlpoint(int pos,float x,float y);

  int get_size(void);

  void  get_at(float *x,float *y,int pos);
  float get_x_at(int pos);
  float get_y_at(int pos);
  float get_y(float x);

  int get_xmaxvalue(float *value);
  int get_xminvalue(float *value);

  int get_ymaxvalue(float *value);
  int get_ymaxvalue(float *value,float x_from);
  int get_yminvalue(float *value);

  void get_buffered(float **buffered_pointer);
  void get_unbuffered(float ***unbuffered_pointer);
  void get_buffered(float *buffered_pointer_x,float *buffered_pointer_y );
  void get_unbuffered(float **unbuffered_pointer_x,float **unbuffered_pointer_y );

  void less_squares_fit(float *m,float *b);
  void poly2_fit(float *x0,float *x1,float *x2);

  void order_controlPoints(int type);//0 x_++,
                                     //1 x_--,
                                     //2 y_++,
                                     //3 y_--,
                                     //4 distance origin++
                                     //5 distance origin--

  void eliminate_same_controlpoints(int type);
                                              //0 same x and y
                                              //1 same x
                                              //2 same y
                                              //3 same x or y
  void clear_controlpoints();
  void typical_prepare_data(void) ; // Order x_++ and eliminate_same_controlpoints same x
  void print(char *filename);
  void print(void);

  void export_tecplot(char *filename);

  ControlPoints &operator=(ControlPoints &last);
  void operator+=(ControlPoints &last);
  void operator+=(float value);

  void operator-=(ControlPoints &last);
  void operator-=(float value);

  void operator*=(ControlPoints &last);
  void operator*=(float value);

  void operator/=(ControlPoints &last);
  void operator/=(float value);

  bool operator==(ControlPoints &last);
  bool operator!=(ControlPoints &last);

  public :
  float epsilon;
};

class Polycurve2d {

public :

Polycurve2d();
Polycurve2d(Polycurve2d &last);
~Polycurve2d();

private :

	ControlPoints *controlpoints;
	std::vector <_POINT> *points;
	bool _autopreparedata;
	int _resolution;
	float _lenght;
	bool _reference;
public :
	void add_controlpoint(float x,float y);
	void add_controlpoint(double x,double y)
          { add_controlpoint(float(x), float(y)); }
	void delete_controlpoint(int pos);
	void init_reference(ControlPoints *input);

	float get_lenght(void);
	int get_size(void);

	float get_x(float y_pos);
	float get_y(float x_pos) const;

	void get_x(float **x_cuts_unbuffered,float y_pos,int *size_cuts);
	void get_y(float **y_cuts_unbuffered,float x_pos,int *size_cuts);

	void get_xY(float *x,float *y,float param,bool UseArcoTrue_ParmaToUnitFalse);
	void get_xY(float *x,float *y,float arco);

	void printPoints(char *filename);
	void printPoints(void);
	void export_tecplot(char *filename);

	float integrate(int integratepoints);
	float integrate(int integratepoints,float minLimit,float maxLimit);
	float moment(float origin,int integratepoints);
	float application_point(float origin,int integratepoints);

	void set_autopreparedata(bool value);
	bool get_autopreparedata(void);

	ControlPoints *get_controlPoints(void);


	//Operaciones
	Polycurve2d &operator=(Polycurve2d &last);
	void operator+=(Polycurve2d &last);
	void operator+=(float value);

	void operator-=(Polycurve2d &last);
	void operator-=(float value);

	void operator*=(Polycurve2d &last);
	void operator*=(float value);

	void operator/=(Polycurve2d &last);
	void operator/=(float value);

	bool operator==(Polycurve2d &last);
        bool operator!=(Polycurve2d &last);

        float operator()(float arg) const{return get_y(arg);}
        float operator()(double arg) const { return operator()(float(arg)); }

	void _update(void);

	float fSeparator;
	bool bUseSeparator;
};

class Spline2d {
public :

Spline2d();
Spline2d(Spline2d &last);
~Spline2d();

private :

 ControlPoints *controlpoints;
 std::vector <_POINT> *points;

 bool _autopreparedata;
 int _resolution;
 float _lenght;

 bool _reference;

 void _destroy_auxvars(void);

 float *_y2;
 float _der_left,_der_right;

 int _type;

 bool _export_poly_control;

public :
 void _update(void);
 void add_controlpoint(char *filename);
 void add_controlpoint(float x,float y);
 void add_controlpoint(double x, double y)
   { add_controlpoint(float(x), float(y)); }
 void delete_controlpoint(int pos);
 void edit_controlpoint(int pos,float x,float y);
 void clear_controlpoints(void);


 void add_controlpoint(float x,float y,bool aupdate);
 void add_controlpoint(double x, double y, bool aupdate)
   { add_controlpoint(float(x), float(y), aupdate); }
 void delete_controlpoint(int pos,bool update);

 void init_reference(ControlPoints *input);

 float get_lenght(void);
 float get_lenght(float param_To_unit);
 float get_lenghtX(float x);

 int get_size(void);

 float get_y(float x_pos) const;
 void get_xY(float *x,float *y,float param_To_Unit);

 void printPoints(char *filename);
 void printPoints(void);
 void export_tecplot(char *filename);

 float integrate(int integratepoints);
 float moment(float origin,int integratepoints);
 float application_point(float origin,int integratepoints);

 void set_autopreparedata(bool value);
 bool get_autopreparedata(void);

 void set_resolution(int resol);
 int get_resolution(void);

 ControlPoints *get_controlPoints(void);

 char m_name[256];

 //Operaciones
 Spline2d &operator=(Spline2d &last);
 void operator+=(Spline2d &last);
 void operator+=(float value);
 void operator-=(Spline2d &last);
 void operator-=(float value);

 void operator*=(Spline2d &last);
 void operator*=(float value);

 void operator/=(Spline2d &last);
 void operator/=(float value);

 bool operator==(Spline2d &last);
 bool operator!=(Spline2d &last);

 float operator()(float arg) const {return get_y(arg);}
 float operator()(double arg) const { return operator()(float(arg)); }

};

class Bezied2d {

public :

Bezied2d();
Bezied2d(Bezied2d &last);
~Bezied2d();

private :

	ControlPoints *controlpoints;
	std::vector <_POINT> *points;

	int _resolution;
	float _lenght;

	bool _reference;

	void _update(void);

	void _destroy_auxvars(void);

	float *_comb;

	bool _export_poly_control;

public :

	void add_controlpoint(float x,float y);
        void add_controlpoint(double x, double y)
          { add_controlpoint(float(x), float(y)); }
	void delete_controlpoint(int pos);

	void add_controlpoint(float x,float y,bool update);
        void add_controlpoint(double x, double y, bool aupdate)
          { add_controlpoint(float(x), float(y), aupdate); }
	void delete_controlpoint(int pos,bool update);

	void init_reference(ControlPoints *input);

	float get_lenght(void);
	float get_lenght(float param_To_unit);

	int get_size(void);

	void get_xY(float *x,float *y,float param_To_Unit);

	void printPoints(char *filename);
	void printPoints(void);
	void export_tecplot(char *filename);

	ControlPoints *get_controlPoints(void);

	//Operaciones
	Bezied2d &operator=(Bezied2d &last);
	void operator+=(Bezied2d &last);
	void operator+=(float value);

	void operator-=(Bezied2d &last);
	void operator-=(float value);

	void operator*=(Bezied2d &last);
	void operator*=(float value);

	void operator/=(Bezied2d &last);
	void operator/=(float value);

	bool operator==(Bezied2d &last);
        bool operator!=(Bezied2d &last);
};

float _linearExtrapolation(float x_point,float y_point,float x_dir,float y_dir,float x_pos);
float _LinearInterpolation(int size,float **x_point,float **y_point,float x_pos,bool ordered);
float _LinearInterpolationX(std::vector <_POINT> *points,float x_pos,bool ordered);
float _LinearInterpolationY(std::vector <_POINT> *points,float y_pos,bool ordered);
void deletedoublepointer(void ***pointer,int size);
float factor(int value);


class FunctorSpline : public Functor_1<scalar >{
  public :
   void add_point(scalar aoa,scalar value) {spline2d.add_controlpoint(aoa,value);}
   void clear(){spline2d.clear_controlpoints();}
   Spline2d *spline(){return &spline2d;}
   scalar operator()(scalar const &value) const {return spline2d(value);}
  private : 
   Spline2d spline2d;
};

#endif
