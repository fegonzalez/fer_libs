#include "algebra.h"
#include <iostream>

using std::cout;
using std::endl;

using namespace Algebra;

int main()
{

  Vector<double,4> a;
  Vector<double,4> b;

  a(0) = 1;
  a(1) = 1;
  a(2) = 1;
  a(3) = 1;
  
  b(0) = 2;
  b(1) = 1;
  b(2) = 1;
  b(3) = 2;


  cout<< " Vectors " << endl;

  cout << "a = " << a << endl;
  cout << "b = " << b << endl;

  cout << "2 * a = " << 2*a << endl;
  cout << "-a = " << -a << endl;

  cout << "a + b = " << a+b << endl;
  cout << "a - b = " << a-b << endl;
  cout << "a + (- b) = " << a+(-b) << endl;
  cout << "a * b = " << a*b << endl;  
  // cout << "a � b = " << scalprod(a,b) << endl;
  a+=b;
  cout << "a += b; a = " << a << endl;
  cout << endl;


  cout<< " Matrix NxM" << endl;

  Matrix<double,3,4> A;
  
  A(0)(0) = 1; A(0)(1) = 2; A(0)(2) = 3; A(0)(3) = 4;
  A(1)(0) = 2; A(1)(1) = 4; A(1)(2) = 6; A(1)(3) = 8;
  A(2)(0) = 3; A(2)(1) = 6; A(2)(2) = 9; A(2)(3) = 12;
  // A(3)(0) = 4; A(3)(1) = 8; A(3)(2) = 12; A(3)(3) = 16;

  Matrix<double,4,3> B;
  
  B(0)(0) = 1; B(0)(1) = 2; B(0)(2) = 3; //B(0)(3) = 4;
  B(1)(0) = 3; B(1)(1) = 6; B(1)(2) = 9; //B(1)(3) = 12;
  B(2)(0) = 9; B(2)(1) = 18; B(2)(2) = 27; //B(2)(3) = 36;
  B(3)(0) = 27; B(3)(1) = 54; B(3)(2) = 81; //B(3)(3) = 108;

  Matrix<double,4,4> I; 
  I(0)(0) = 1; I(0)(1) = 0; I(0)(2) = 0; I(0)(3) = 0;
  I(1)(0) = 0; I(1)(1) = 1; I(1)(2) = 0; I(1)(3) = 0;
  I(2)(0) = 0; I(2)(1) = 0; I(2)(2) = 1; I(2)(3) = 0;
  I(3)(0) = 0; I(3)(1) = 0; I(3)(2) = 0; I(3)(3) = 1;

  cout<< "A= "<< A << endl;
  cout<< "B= "<< B << endl;
  cout<< "I= "<< I << endl;

  cout << "2 * A = " << 2*A << endl;
  cout << "trans(A) = " << trans(A) << endl;
  cout << "trans(B) = " << trans(B) << endl;
  cout << "(trans(trans(B)) = " << trans(trans(B)) << endl;
  cout << "A * B = " << A*B << endl;
  cout << "A * a = " << A*a << endl;

  
  Matrix<double,4,4> C;
  
  C(0)(0) = 1; C(0)(1) = 2; C(0)(2) = 3; C(0)(3) = 4;
  C(1)(0) = 2; C(1)(1) = 4; C(1)(2) = 6; C(1)(3) = 8;
  C(2)(0) = 3; C(2)(1) = 6; C(2)(2) = 9; C(2)(3) = 12;
  C(3)(0) = 4; C(3)(1) = 8; C(3)(2) = 12; C(3)(3) = 16;

  Matrix<double,4,4> D;
  
  D(0)(0) = 1; D(0)(1) = 2; D(0)(2) = 3; D(0)(3) = 4;
  D(1)(0) = 3; D(1)(1) = 6; D(1)(2) = 9; D(1)(3) = 12;
  D(2)(0) = 9; D(2)(1) = 18; D(2)(2) = 27; D(2)(3) = 36;
  D(3)(0) = 27; D(3)(1) = 54; D(3)(2) = 81; D(3)(3) = 108;

  cout<< " \nMatrix NxN" << endl;
  cout<< "C= "<< C << endl;
  cout<< "D= "<< D << endl; 
  cout << "C + D = " << C+D << endl;
  cout << "C - D = " << C-D << endl;
  
  cout << "trans(C) = " << trans(C) << endl;
  cout << "trans(D) = " << trans(D) << endl;
  cout << "(trans(trans(C)) = " << trans(trans(C)) << endl;

  cout<< "-C= "<< -C << endl;

  cout << "C + (- D) = " << C+(-D) << endl;

  cout << "I * a = " << I*a << endl;
  cout << "C * a = " << endl << C*a << endl;
  cout << "C * I = " << endl << C*I << endl;
  cout << "C * D = " << endl << C*D << endl;

  std::cout<<"\n\n LU descomposition " << std::endl;
  
  Matrix<double,5,5> AA;
  
  AA(0)(0) = 6; AA(0)(1) = 2; AA(0)(2) = 8; AA(0)(3) = 6; AA(0)(4) = 5;
  AA(1)(0) = 4; AA(1)(1) = 9; AA(1)(2) = 8; AA(1)(3) = 7; AA(1)(4) = 2;
  AA(2)(0) = 9; AA(2)(1) = 7; AA(2)(2) = 5; AA(2)(3) = 3; AA(2)(4) = 0;
  AA(3)(0) = 1; AA(3)(1) = 4; AA(3)(2) = 1; AA(3)(3) = 2; AA(3)(4) = 10;
  AA(4)(0) = 4; AA(4)(1) = 1; AA(4)(2) = 0; AA(4)(3) = 0; AA(4)(4) = 4;
  
  Matrix<double,5,5> AAA;
  
  AAA(0)(0) = 6; AAA(0)(1) = 2; AAA(0)(2) = 8; AAA(0)(3) = 6; AAA(0)(4) = 5;
  AAA(1)(0) = 4; AAA(1)(1) = 9; AAA(1)(2) = 8; AAA(1)(3) = 7; AAA(1)(4) = 2;
  AAA(2)(0) = 9; AAA(2)(1) = 7; AAA(2)(2) = 5; AAA(2)(3) = 3; AAA(2)(4) = 0;
  AAA(3)(0) = 1; AAA(3)(1) = 4; AAA(3)(2) = 1; AAA(3)(3) = 2; AAA(3)(4) = 10;
  AAA(4)(0) = -4; AAA(4)(1) = -1; AAA(4)(2) = -0; AAA(4)(3) = -0; AAA(4)(4) = -4;

  cout << "AA = " << AA << endl;

  cout << "Expected: \n"
       << "L= \n"
       << "|  1.000  0.000  0.000  0.000  0.000 | \n"
       << "|  0.444  1.000  0.000  0.000  0.000 | \n"
       << "|  0.667 -0.453  1.000  0.000  0.000 | \n"
       << "|  0.444 -0.358 -0.021  1.000  0.000 | \n"
       << "|  0.111  0.547 -0.373  1.217  1.000 | \n"
    
       << "U= \n"
       << "| 9.000 7.000 5.000 3.000 0.000 | \n"
       << "| 0.000 5.889 5.778 5.667 2.000 | \n"
       << "| 0.000 0.000 7.283 6.566 5.906 | \n"
       << "| 0.000 0.000 0.000 0.834 4.839 | \n"
       << "| 0.000 0.000 0.000 0.000 5.217 | \n\n" << endl;
  
  cout << "LU(AA) = " << LU<double,5>(AA) << endl;

  cout<< "\n Determinant: "<< endl;
 
  cout << "det(C) = " << det(C) <<" Expected 0 "<< endl;
  cout << "det(D) = " << det(D) <<" Expected 0 "<< endl;
  cout << "det(AA) = " << det(AA) <<" Expected 1680 " << endl;
  cout << "det(-AA) = " << det(-AA) <<" Expected -1680 " << endl;
  cout << "det(AAA) = " << det(AAA) <<" Expected -1680 " << endl;

  cout << "det(I) = " << det(I) <<" Expected 1 "<< endl;

  cout<< "\n Solve: "<< endl;

  Matrix<double,3,3> S;

  S(0)(0) = 2; S(0)(1) = 1; S(0)(2) =-1; 
  S(1)(0) =-3; S(1)(1) =-1; S(1)(2) = 2; 
  S(2)(0) =-2; S(2)(1) = 1; S(2)(2) = 2; 

  Vector<double,3> bb;

  bb(0)=8;
  bb(1)=-11;
  bb(2)=-3;

  cout << "Expected x= 2 3 -1 ---> x: " << solve<double,3>(S,bb) << endl;

  Matrix<double,6,6> S6;

  S6(0)(0) = 1; S6(0)(1) = 2; S6(0)(2) = 3; S6(0)(3) = 4; S6(0)(4) = 5; S6(0)(5) = 6;
  S6(1)(0) = 5; S6(1)(1) = 3; S6(1)(2) = 0; S6(1)(3) = 4; S6(1)(4) = 5; S6(1)(5) = 6;
  S6(2)(0) = 1; S6(2)(1) = 2; S6(2)(2) = 3; S6(2)(3) = 4; S6(2)(4) = 4; S6(2)(5) = 0;
  S6(3)(0) = 1; S6(3)(1) = 2; S6(3)(2) = 3; S6(3)(3) = 8; S6(3)(4) = 4; S6(3)(5) = 0;
  S6(4)(0) = 1; S6(4)(1) = 2; S6(4)(2) = 0; S6(4)(3) = 8; S6(4)(4) = 4; S6(4)(5) = 0;
  S6(5)(0) = 1; S6(5)(1) = 2; S6(5)(2) = 0; S6(5)(3) = 8; S6(5)(4) = 4; S6(5)(5) = 1;

  Vector<double,6> b6;
  b6(0)=91;
  b6(1)=88;
  b6(2)=50;
  b6(3)=66;
  b6(4)=57;
  b6(5)=63;

  cout << "Expected x= 1 2 3 4 5 6 ---> x: " << solve<double,6>(S6,b6) << endl;


  cout<< "\n Inverse: "<< endl;

  Matrix<double,3,3> inv;

  inv(0)(0) = 2; inv(0)(1) =-2; inv(0)(2) = 1; 
  inv(1)(0) =-1; inv(1)(1) = 1; inv(1)(2) = 1; 
  inv(2)(0) =-1; inv(2)(1) = 3; inv(2)(2) = 5; 
  
  
  cout << "inverse = "<< inverse(inv)  << endl;

  cout<< "\n Inverse2: "<< endl;

  Matrix<double,3,3> inv2;

  inv2(0)(0) = 1; inv2(0)(1) = 2; inv2(0)(2) = 3; 
  inv2(1)(0) = 2; inv2(1)(1) = 1; inv2(1)(2) = 4; 
  inv2(2)(0) = 3; inv2(2)(1) = 4; inv2(2)(2) = 1; 
  
  
  cout << "inverse = "<< inverse(inv2)  << endl;

  cout << "inverse = \n"<< S6*inverse(S6)  << endl;
  cout << "inverse = \n"<< S*inverse(S)  << endl;

  cout << "inverse = \n"<< AA*inverse(AA)  << endl;
  cout << "inverse = \n"<< AAA*inverse(AAA)  << endl;
  cout << "inverse = \n"<< I*inverse(I)  << endl;



}
