#include "base.h"
#include <limits>
#include <iostream>

using namespace std;

#define compare_a_b(operation, a, b)                                         \
cout << #operation "(" << #a << ", " << #b << "): " << operation(a, b) << endl


#define compare(a, b)                                                   \
  compare_a_b(permissive_eq, a, b);                                     \
  compare_a_b(strict_ne, a, b);                                         \
  compare_a_b(permissive_less_than, a, b);                              \
  compare_a_b(permissive_greater_than, a, b);                           \
  compare_a_b(strict_less_than, a, b);                                  \
  compare_a_b(strict_greater_than, a, b);                               \
  cout << endl;


int main() {
  cout << std::boolalpha;
  scalar tiny_bit=100.*std::numeric_limits<scalar>::epsilon();
  compare(3., 3.);
  compare(3., 3.+tiny_bit);
  compare(3., 3.-tiny_bit);
  compare(3.+tiny_bit, 3.);
  compare(3.-tiny_bit, 3.);
  compare(3., 4.);
  compare(4., 3.);

  std::cout << "\n\n Other functions : round" << std::endl;

  scalar x = 1.11635716;
  std::cout << x <<" "<< round_to_the_n_decimal(x, 5) << std::endl;
  std::cout << x <<" "<< round_to_the_n_decimal(x, 4) << std::endl;
  std::cout << x <<" "<< round_to_the_n_decimal(x, 3) << std::endl;
  std::cout << x <<" "<< round_to_the_n_decimal(x, 2) << std::endl;
  std::cout << x <<" "<< round_to_the_n_decimal(x, 1) << std::endl;

  std::cout << permissive_eq(0., 0.) << std::endl;
  std::cout
    << permissive_eq(1., 1.+.5*sqrt(std::numeric_limits<double>::epsilon()))
    << std::endl;
  std::cout
    << permissive_eq(1., 1.+2.*sqrt(std::numeric_limits<double>::epsilon()))
    << std::endl;

  std::cout
    << permissive_eq(
         .01, .01*(1.+.5*sqrt(std::numeric_limits<double>::epsilon())))
    << std::endl;
  std::cout
    << permissive_eq(
         .01, .01*(1.+2.*sqrt(std::numeric_limits<double>::epsilon())))
    << std::endl;

  std::cout
    << permissive_eq(
         .01, .01*(1.+.5*sqrt(std::numeric_limits<double>::epsilon())), 1.)
    << std::endl;
  std::cout
    << permissive_eq(
         .01, .01*(1.+2.*sqrt(std::numeric_limits<double>::epsilon())), 1.)
    << std::endl;
  std::cout
    << permissive_eq(
         .01, .01+2.*sqrt(std::numeric_limits<double>::epsilon()), 1.)
    << std::endl;
  std::cout << permissive_eq(6e-18, 0., 1.) << std::endl;

  cout << boolalpha;
  Bool a;
  cout << a << endl;
  a=true;
  cout << a << endl;
  if (a)
    cout << "a is true" << endl;
  Bool b;
  if (a or b)
    cout << "a or b is true" << endl;
  if (a and b)
    cout << "a and b is true, but shouldn't" << endl;
  b=a and a;
  if (a and b)
    cout << "a and b is true" << endl;

  {
    auto_init<scalar> a;
    scalar b;
    cout << a << endl;
    b=a;
    cout << b << endl;
    a=b;
    cout << a << endl;
    a=2.;
    cout << a << endl;
    a+=3.;
    cout << a << endl;
    cout << (a>b) << endl;

    auto_init<bool> c;
    bool d;
    cout << c << endl;
    d=c;
    cout << d << endl;
    c=d;
    cout << c << endl;
    c=true;
    cout << c << endl;
    cout << (not c) << endl;
    cout << (c or d) << endl;
    cout << (c and d) << endl;
  }

  for (scalar x=0; x<3.; x+=.5)
    cout << "ramp(" << x << ", 1., 11., 2., 12.): "
         << ramp(x, 1., 11., 2., 12.) << endl;
  for (scalar x=0; x<3.; x+=.5)
    cout << "ramp(" << x << ", 2., 11., 1., 12.): "
         << ramp(x, 2., 11., 1., 12.) << endl;
  for (scalar x=0; x<3.; x+=.5)
    cout << "ramp(" << x << ", 1.5, 11.5, 1.5, 11.5): "
         << ramp(x, 1.5, 11.5, 1.5, 11.5) << endl;
  cout << "sign (-50.) = " << sign (-50.) << endl;
  cout << "sign (20.) = " << sign (20.) << endl;
}
