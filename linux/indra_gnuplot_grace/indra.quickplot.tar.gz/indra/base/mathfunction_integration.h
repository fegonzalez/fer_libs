#ifndef _MATH_FUNCTION_INTEGRATION_H
#define _MATH_FUNCTION_INTEGRATION_H

#include "../base/base.h"
#include "../base/functor.h"

class Integral {
 public :
  Integral(scalar x_init,scalar x_end,int steps,Functor_1<scalar> *function)
    : x_init(x_init),x_end(x_end),steps(steps),function(function),integral(0.0) {}
  virtual ~Integral() {}
  virtual scalar integrate()=0;
  scalar integrate(scalar x_init_,scalar x_end_) {x_init=x_init_;x_end=x_end_;integral=integrate();return integral;}
  scalar get_integral(void) {return integral;}
 protected :
  scalar x_init,x_end;
  int steps;
  Functor_1<scalar> *function;
  scalar integral;
};


class TrapeziumIntegral : public Integral {

public :
 TrapeziumIntegral(scalar x_init,scalar x_end,int steps,Functor_1<scalar> *function) 
  : Integral(x_init,x_end,steps,function) {}

 scalar integrate();
 scalar integrate(scalar a,scalar b) {return Integral::integrate(a,b);}

};

class SimpsonIntegral : public Integral {

 public :
  SimpsonIntegral(scalar x_init,scalar x_end,int steps,Functor_1<scalar> *function) 
  : Integral(x_init,x_end,steps,function) {}

  scalar integrate();
  scalar integrate(scalar a,scalar b) {return Integral::integrate(a,b);}

};

#endif

