#ifndef ALGEBRA_FUNCTOR_HEADER
#define ALGEBRA_FUNCTOR_HEADER

#include "functor.h"
#include "subscription.h"


template <class Ret>
class Lineal_0: public Functor_0<Ret>
{
public:

  // Function y = m*x + n
  Lineal_0(Functor_0<Ret> const *x,
	   Functor_0<Ret> const *m,
	   Functor_0<Ret> const *n):x(x),m(m),n(n){}

  Ret operator()() const { return (x->function()*m->function()) + (n->function());}

private:

  Functor_0<Ret> const *x;
  Functor_0<Ret> const *m;
  Functor_0<Ret> const *n;

};

template <class Ret>
class Summatory_0: public Functor_0<Ret>,
		   public Subscriptable< Summatory_0<Ret>, Functor_0<Ret> >
{
 public:

  Summatory_0(){};

  typedef Functor_0<Ret> Functor;
  typedef Summatory_0<Ret> Summatory;
  typedef Subscriptable< Summatory, Functor > SubscriptableSumFunctor;
  typedef SubscriptableBase<Summatory_0<double>,Functor_0<double> > SubscriptableSumFunctorBase;
  typedef SubscriptableBase<Summatory_0<double>,Functor_0<double> >::Handle Handle;

  Handle subscribe_functor(pointer_type(Functor) functor)
  { return SubscriptableSumFunctor::subscribe(functor); }

  void unsubscribe_functor(Handle handle)
  { SubscriptableSumFunctor::unsubscribe(handle); }


  Ret operator()() const
  {
    Ret total;
    for ( SubscriptableSumFunctorBase::const_iterator scan=SubscriptableSumFunctorBase::begin();
	 scan!= SubscriptableSumFunctorBase::end(); ++scan)
      {
	if(scan==SubscriptableSumFunctorBase::begin())
	  {
	    total = (*scan)->function();
	  }
	else
	  {
	    total+=(*scan)->function();
	  }
      }

    return total;
  }


};

template <class Ret>
class Product_0: public Functor_0<Ret>,
		 public Subscriptable< Product_0<Ret>, Functor_0<Ret> >
{
 public:

  Product_0(){};

  typedef Functor_0<Ret> Functor;
  typedef Product_0<Ret> Productory;
  typedef Subscriptable< Productory, Functor > SubscriptableProdFunctor;
  typedef SubscriptableBase<Product_0<double>,Functor_0<double> > SubscriptableProdFunctorBase;
  typedef SubscriptableBase<Product_0<double>,Functor_0<double> >::Handle Handle;

  Handle subscribe_functor(pointer_type(Functor) functor)
  { return SubscriptableProdFunctor::subscribe(functor); }

  void unsubscribe_functor(Handle handle)
  { SubscriptableProdFunctor::unsubscribe(handle); }


  Ret operator()() const
  {

    SubscriptableProdFunctorBase::const_iterator const scan1=SubscriptableProdFunctorBase::begin();
    SubscriptableProdFunctorBase::const_iterator const scan2=SubscriptableProdFunctorBase::end();


    SubscriptableProdFunctorBase::const_iterator previous = scan1;

    Ret total;
    for ( SubscriptableProdFunctorBase::const_iterator scan=SubscriptableProdFunctorBase::begin();
	 scan!= SubscriptableProdFunctorBase::end(); ++scan)
      {
	if(previous == scan)
	  {
	    total = (*scan)->function() ;
	  }
	else
	  {
	    total=total * (*scan)->function();
	  }


	previous = scan;
      }

    return total;
  }




 private:

};




#endif
