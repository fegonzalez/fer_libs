#ifndef INDRA_BASE_SHARED_PTR_HEADER_
#define INDRA_BASE_SHARED_PTR_HEADER_

#include <cassert>

namespace indra_lib {

  template <typename T>
  class shared_ptr {
  public:
    shared_ptr() : weak_reference(false) { construct((T *)(0)); }
  private:
    explicit shared_ptr(T *p) : weak_reference(false) { construct(p); }

    struct WeakReference { };
    shared_ptr(T *p, WeakReference) : weak_reference(true) { construct(p); }

  public:
    template <typename U>
    shared_ptr(shared_ptr<U> const &sp)
      : weak_reference(sp.weak_reference) { construct(sp); }
    shared_ptr(shared_ptr<T> const &sp)
      : weak_reference(sp.weak_reference) { construct(sp); }

    template <typename U>
    shared_ptr<T> &operator=(shared_ptr<U> const &sptr)
      { return assign(sptr); }
    shared_ptr<T> &operator=(shared_ptr<T> const &sptr)
      { return assign(sptr); }

    ~shared_ptr() { check_invariant(); resign(); }

    T &operator*() const { check_invariant(); return *obj_ptr; }
    T *operator->() const { check_invariant(); return obj_ptr; }

    void reset() { assign(shared_ptr<T>(0)); }
    bool is_nonnull() const {return obj_ptr!=0;}
    shared_ptr<T> weak() const
      { return shared_ptr<T>(obj_ptr, WeakReference()); }

  private:

    typedef long int CountType;

    template <typename U>
    friend class shared_ptr;

    template <typename U>
    friend shared_ptr<U> new_shared_ptr(U *);
    template <typename U>
    friend shared_ptr<U> weak_shared_ptr(U *);
    template <typename D, typename U>
    friend shared_ptr<D> shared_ptr_dynamic_cast(shared_ptr<U>);

    struct DynamicCast { };

    template <typename D>
    shared_ptr<D> dynamic_as(D *) const {
      return shared_ptr<D>(*this, DynamicCast());
    }

    template <typename B>
    shared_ptr(shared_ptr<B> const &sp, typename shared_ptr<B>::DynamicCast)
      : weak_reference(sp.weak_reference) { construct_dynamic(sp); }

    template <typename U>
    void construct(U *ptr) {
      obj_ptr=ptr;
      if (not weak_reference and obj_ptr) count_ptr=new CountType(1);
      else count_ptr=0;
      check_invariant();
    }

    template <typename U>
    void construct(shared_ptr<U> const &sptr) {
      sptr.check_invariant();
      obj_ptr=sptr.obj_ptr;
      if (not weak_reference and obj_ptr) {
        count_ptr=sptr.count_ptr;
        ++(*count_ptr);
      }
      else count_ptr=0;
      check_invariant();
    }

    template <typename B>
    void construct_dynamic(shared_ptr<B> const sptr) {
      sptr.check_invariant();
      obj_ptr=dynamic_cast<T *>(sptr.obj_ptr);
      if (not weak_reference and obj_ptr) {
        count_ptr=sptr.count_ptr;
        ++(*count_ptr);
      }
      else count_ptr=0;
      check_invariant();
    }

    template <typename U>
    shared_ptr<T> &assign(shared_ptr<U> const &sptr) {
      check_invariant();
      sptr.check_invariant();
      if (not weak_reference) {
        if (obj_ptr!=sptr.obj_ptr) {
          resign();
          weak_reference=sptr.weak_reference;
          construct(sptr);
        }
      }
      else {
        weak_reference=sptr.weak_reference;
        construct(sptr);
      }
      check_invariant();
      return *this;
    }

    void resign() {
      if (not weak_reference and obj_ptr) {
        --(*count_ptr);
        if ((*count_ptr)==0) {
          delete count_ptr;
          delete obj_ptr;
        }
      }
    }

    void check_invariant() const {
      assert((weak_reference and (count_ptr==0))
             or (not weak_reference and ((obj_ptr==0)==(count_ptr==0))));
    }

    T *obj_ptr;
    CountType *count_ptr;
    bool weak_reference;
  };

  template <typename T>
  shared_ptr<T> new_shared_ptr(T *p) {
    return shared_ptr<T>(p);
  }

  template <typename T>
  shared_ptr<T> weak_shared_ptr(T *p) {
    return shared_ptr<T>(p, typename shared_ptr<T>::WeakReference());
  }

  template <typename D, typename T>
  shared_ptr<D> shared_ptr_dynamic_cast(shared_ptr<T> p) {
    return p.dynamic_as((D *)(0));
  }

}

#endif
