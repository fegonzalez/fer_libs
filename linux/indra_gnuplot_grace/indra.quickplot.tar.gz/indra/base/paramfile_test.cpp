#include "paramfile.h"
#include "string_cast.h"
#include "scalar.h"
#include <iostream>

using namespace std;

int main(){

string file("paramfile_test.txt");
string month("October");

try{
   ParameterFile paramfile(file);
   if(paramfile.exists(month)){
      cout << "The name of the parameter is \""+month+"\"" << endl;
  	   cout << "The value of the parameter is " 
           << paramfile.parameter<scalar>(month) << endl;}
   else
      cout << "Parameter does not exist" << endl;

   month="September";
   cout << "The name of the parameter is \""+month+"\"" << endl;
   cout << "The value of the parameter is " 
           << paramfile.parameter<scalar>(month) << endl;
 
	cout <<paramfile.parameter<scalar>("Septembers");
   }
catch(string s){
   cout << s << endl;}
}
