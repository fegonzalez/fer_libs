#ifndef BASE_FUNCTOR_LINK_HEADER_
#define BASE_FUNCTOR_LINK_HEADER_

#include "functor.h"
#include "link.h"

/* Output<> the same as InOutput<>, but instead of repeating the value
 * of another Output<>, it repeats the value that is returned by a Functor_0
 * (of the same type of the class parameter). */ 
template <class Type>
class FwdFunctor
: public Output<Type> {
 public:
   FwdFunctor() : link(0) { };
   FwdFunctor(Functor_0<Type> const *output)
     : link(output) { }
   void link_to(Functor_0<Type> const *output)
     { link=output; };
 private:
   Type compute_value() const
     { assert(link!=0); return link->function(); };
   Functor_0<Type> const *link;
};
  

template <class Type, class Source>
FwdFunctor<Type> *new_consultor_link(Source const *source, Type (Source::*consultor)() const) {
  return new FwdFunctor<Type>(new ConsultorRepeater <Type, Source>(source, consultor));
}
  
#endif
