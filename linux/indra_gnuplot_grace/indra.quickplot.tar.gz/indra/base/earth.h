#ifndef EARTH_HEADER_
#define EARTH_HEADER_

#include "base.h"
#include "geometry.h"

/* Implementation of the WGS84 ellipsoidal earth model. */

/* lat_lon_alt in sexagesimal degrees and meters */
class lat_lon_alt {
 public:
   lat_lon_alt() : latitude(0.), longitude(0.), altitude(0.) { }
   lat_lon_alt(scalar _latitude, scalar _longitude, scalar _altitude)
     : latitude(_latitude), longitude(_longitude), altitude(_altitude)
     { };
   scalar lat() const { return latitude; };
   scalar lon() const { return longitude; };
   scalar alt() const { return altitude; };
 private:
   scalar latitude, longitude, altitude;
};

Quaternion ref_local_horizon(lat_lon_alt pos_geographic);

std::ostream &operator<<(std::ostream &os, lat_lon_alt lla); // write a lla
std::istream &operator>>(std::istream &is, lat_lon_alt &lla);

class Earth {
 public:
   Earth(scalar semimajor_axis,
	  scalar semiminor_axis)
     : a(semimajor_axis), b(semiminor_axis),
       f((a-b)/a), e_2(2*f-square(f))
     { };

   lat_lon_alt inertial_to_earth(Vector pos_inertial) const;
   Vector earth_to_inertial(lat_lon_alt pos_geographic) const;
   Quaternion ref_local_horizon(lat_lon_alt pos_geographic) const {
     return ::ref_local_horizon(pos_geographic);
   }

 private:
   scalar a, b, f, e_2;
};

extern Earth const WGS84;

#endif
