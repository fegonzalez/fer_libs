#ifndef BASE_MODELO_HEADER_
#define BASE_MODELO_HEADER_

#include "subscription.h"
#include "scalar.h"

// A Model can be subscribed to another Model through the method
// "subscribe_to()".  A Model, when it is run through its method "run()", first
// runs its "pre_model()" method, then its subscribed models, and then its own
// model (its abstract method "model()").  A Model can be unsubscribed through
// its method "unsubscribe()".  It is an error to subscribe a Model that is
// already subscribed.  It is a no-op to unsubscribe a Model that is not
// subscribed to any Model.  Upon destruction, a Model unsubscribes itself, and
// unsuscribes all Models subscribed to it.  A Model does _not_ own the Models
// subscribed to it (i.e., it does not delete them upon its own deletion).
//
// As for model state, if you have to separate the computation of the
// observable state from its update, implement the first in "model()" and the
// latter in "show_state()"; the state computed in "model()" should be kept by
// the model so that it is transferred to the observable interface in
// "show_state()"; thus, "show_state()" should consist only of direct
// assignments of the values kept to the variables that make up the observable
// state.

class Model
: public Subscriptable<Model> {
public:
  void run();
  void initialise();
  // current simulation time; by default a Model asks the Model to which it is
  // subscribed in order to get it; if you use it, you have to install at the
  // top of the subscription hierarchy a Model that really knows how to obtain
  // simulation time
  virtual scalar get_t() const;
  // simulation time step of the Model; same forwarding philosophy as t()
  virtual scalar get_dt() const;
protected:
  virtual void pre_initialise_model() { }
  virtual void initialise_model() { }
  virtual void pre_model() { }
  virtual void model() { }
  virtual void show_state() { }

  // message passing downwards through a Model tree; a message to be passed
  // must be derived from "Model::Message", and can contain any additional
  // payload (attributes and methods); it must be passed by reference to a
  // Model through "pass_message()", and the Model then forwards it by
  // reference recursively to all other Model instances subscribed to it; a
  // Model implementation can detect and honour a message by overloading
  // "accept_message()"; inside "accept_message()", the type of a message can
  // be tested for by using "concrete_message_is<>()", and the message with its
  // concrete type can be retrieved by using "contrete_message<>()"; see
  // "modeltest.cpp" for an example; whether "accept_message()" is overloaded
  // or not, and whether it detects or not a message, the message is always
  // forwarded downwards
public:
  struct Message { virtual ~Message() { } };
  void pass_message(Message const &message);
protected:
  template <typename ConcreteMessage>
  static ConcreteMessage const &concrete_message(Message const &message)
    { return dynamic_cast<ConcreteMessage const &>(message); }
  template <typename ConcreteMessage>
  static bool concrete_message_is(Message const &message)
    { return dynamic_cast<ConcreteMessage const *>(&message); }
  virtual void accept_message(Message const &) { }

private:
  void run_but_do_not_show_state(); // ... unless there isn't any harm to it
  void show_state_after_having_computed_it(); // ... if this hasn't been done
};

// a freshly created Model can be subscribed on-the-fly; this makes it easy to
// write a Model instantiation and its subscription in the same command, thus
// reducing the risk of forgetting to subscribe
template <typename ConcreteModel>
pointer_type(ConcreteModel) subscribe(pointer_type(ConcreteModel) subscribed,
                                      pointer_type(Model) owner) {
  subscribed->subscribe_to(owner, subscribed);
  return subscribed;
}

class ConstantDtModel
  : public Model {
public:
  ConstantDtModel(scalar dt) : simulation_time_step(dt) { }
  scalar get_dt() const { return simulation_time_step; }
private:
  scalar const simulation_time_step;
};

class ConstantDtClockModel
  : public ConstantDtModel {
public:
  ConstantDtClockModel(scalar dt)
  : ConstantDtModel(dt), simulation_time(0.) { }
  scalar get_t() const { return simulation_time; }
protected:
  virtual void pre_model() { simulation_time+=get_dt(); }
private:
  scalar simulation_time;
};

template <typename ObservableState>
class SynchronizedModel
  : public Model {
  SynchronizedModel() : state(private_state) { }
protected:
  ObservableState computed_state; // this is the one to update in model()
  ObservableState const &state; // this one you can read but cannot write to
private:
  ObservableState private_state;
  void show_state() { private_state=computed_state; }
};

#endif
