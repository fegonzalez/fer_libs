#ifndef SCALAR_HEADER_
#define SCALAR_HEADER_



typedef double unchecked_scalar;



#ifdef SIMDEBUG_NAN  //Compilation flag for checking Nan's

   #include "checked_scalar.h"

#else  //The Nan's checking flag is not activated

   typedef double scalar;

   template <typename type>
   inline type if_then_else(bool condition, type true_val, type false_val)
   { if (condition) return true_val; else return false_val;}

   inline scalar if_then_else(bool condition, scalar true_val, scalar false_val)
   { if (condition) return true_val; else return false_val;}
   inline scalar if_then_else(bool condition, scalar true_val, int false_val)
   { if (condition) return true_val; else return false_val;}
   inline scalar if_then_else(bool condition, int true_val, scalar false_val)
   { if (condition) return true_val; else return false_val;}


#endif



#endif
