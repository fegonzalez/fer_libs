#include "control_messages.h"
#include <iostream>


using namespace std;
using namespace ControlMessages;

struct DataExample
{
  DataExample():n(0),x(999){};

  int n;
  float x;
  
};

int main()
{

  MessageControl<DataExample> a; // send
  MessageControl<DataExample> b(1,.25); // receive
  
  // Connection

  b.connection(&a);
  std::cout<<" construction: "<< std::endl;   
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;

  // Changed in a:
  a.data.n=10;
  a.data.x=45;
  a.write();

  std::cout<<" write: "<< std::endl;
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;

  std::cout<<" read: "<< std::endl;
  b.get_message();
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;

/// after 5 more reads TIMEOUT should be detected
  b.get_message();
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;
  b.get_message();
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;
  b.get_message();
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;
  b.get_message();
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;
  b.get_message();
  std::cout<<"a values: "<< a.data.n << " "<< a.data.x << std::endl;
  std::cout<<"b values: "<< b.data.n << " "<< b.data.x << std::endl;
  std::cout<<"b TIMEOUT: "<< b.TIMEOUT << std::endl;


  
  return (0);
}
