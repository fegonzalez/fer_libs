#include "../testing/utils.h"
#include "model.h"
#include "functor.h"

//Define class for print a specific char
class Print_char_a : public Model {
    void model() {cout << "a" << endl;}
    void initialise_model() {cout << "i_a" << endl;}
};

class Print_char_b : public Model {
    void pre_model() {cout << "b_pre" << endl; }
    void model() {cout << "b" << endl;}
    void initialise_model() {cout << "i_b" << endl;}
};

class Print_char_c : public Model {
    void model() {cout << "c" << endl;}
    void initialise_model() {cout << "i_c" << endl;}
};

class Print_char_d : public Model {
    void model() {cout << "d" << endl;}
    void initialise_model() {cout << "i_d" << endl;}
};

class ModelTest {
public:
    ModelTest() {}
    ~ModelTest() {}

    void test_suscription();
    void test_initialisation();
    void test_clock();
    void test_message();
private:
};

void ModelTest::test_suscription(void) {

    //Create different models
    pointer_type(Print_char_a) model_a = new_pointer(Print_char_a);
    pointer_type(Print_char_b) model_b = new_pointer(Print_char_b);
    pointer_type(Print_char_c) model_c = new_pointer(Print_char_c);
    pointer_type(Print_char_d) model_d = new_pointer(Print_char_d);

    cout << "A is the parent. B,C and D are subscribed to A" << endl;
    //Model_a will be the parent
    model_b->subscribe_to(model_a);
    model_c->subscribe_to(model_a);
    model_d->subscribe_to(model_a);

    model_a->run();

    cout << endl;
    cout << "A is the parent. C is unsubscribed" << endl;
    model_c->unsubscribe();

    model_a->run();

    cout << endl;
    cout << "A is the parent. C is subscribed to B" << endl;
    model_c->subscribe_to(model_b);

    model_a->run();

    cout << endl;
    cout << "A is the parent. B is unsubscribed" << endl;
    model_b->unsubscribe();

    model_a->run();

    cout << endl;
    cout << "A is the parent. B is subscribed to D" << endl;
    model_b->subscribe_to(model_d);

    model_a->run();

    cout << endl;
    cout << "A is the parent. D is unsubscribed and subscribed to B" << endl;
    model_d->unsubscribe();
    model_d->subscribe_to(model_b);

    model_a->run();

    cout << endl;
    cout << "A is the parent. B is unsubscribed and subscribed to A" << endl;
    model_b->unsubscribe();
    model_b->subscribe_to(model_a);

    model_a->run();
}

void ModelTest::test_initialisation(void) {

    //Create different models
    pointer_type(Print_char_a) model_a = new_pointer(Print_char_a);
    pointer_type(Print_char_b) model_b = new_pointer(Print_char_b);
    pointer_type(Print_char_c) model_c = new_pointer(Print_char_c);
    pointer_type(Print_char_d) model_d = new_pointer(Print_char_d);

    cout << "A is the parent. B,C and D are subscribed to A" << endl;
    //Model_a will be the parent
    model_b->subscribe_to(model_a);
    model_c->subscribe_to(model_a);
    model_d->subscribe_to(model_a);

    model_a->initialise();

    cout << endl;
    cout << "A is the parent. C is unsubscribed" << endl;
    model_c->unsubscribe();

    model_a->initialise();

    cout << endl;
    cout << "A is the parent. C is subscribed to B" << endl;
    model_c->subscribe_to(model_b);

    model_a->initialise();

    cout << endl;
    cout << "A is the parent. B is unsubscribed" << endl;
    model_b->unsubscribe();

    model_a->initialise();

    cout << endl;
    cout << "A is the parent. B is subscribed to D" << endl;
    model_b->subscribe_to(model_d);

    model_a->initialise();

    cout << endl;
    cout << "A is the parent. D is unsubscribed and subscribed to B" << endl;
    model_d->unsubscribe();
    model_d->subscribe_to(model_b);

    model_a->initialise();

    cout << endl;
    cout << "A is the parent. B is unsubscribed and subscribed to A" << endl;
    model_b->unsubscribe();
    model_b->subscribe_to(model_a);

    model_a->initialise();
}

class ShowTime
  : public Model {
public:
  void model()
  { cout << "current_time: " << get_t() << "; dt: " << get_dt() << endl; }
};

void ModelTest::test_clock(void) {
  pointer_type(Model) clock=new_pointer(ConstantDtClockModel(.1));
  subscribe(new_pointer(ShowTime), clock);
  clock->initialise();
  clock->run();
  clock->run();
  clock->run();
}

struct UpdateParameters
  : public Model::Message {
  UpdateParameters(std::string const &version)
    : version(version) { }
  std::string const version;
};

class ModelWithUpdatableParameters
  : public Model {
public:
  ModelWithUpdatableParameters(Functor_0<scalar> const * x,
                               Functor_0<scalar> const * y)
    : x(x), y(y) {
    load_parameters("initial");
  }
  void model() {
    cout << "version: " << parameter_version
         << ", product: " << product
         << ", sum: " << sum << endl;
  }
  void accept_message(Message const &message) {
    if (concrete_message_is<UpdateParameters>(message))
      load_parameters(concrete_message<UpdateParameters>(message).version);
  }
private:
  Functor_0<scalar> const *const x;
  Functor_0<scalar> const *const y;
  std::string parameter_version;
  scalar product;
  scalar sum;
  void load_parameters(std::string version) {
    parameter_version=version;
    scalar x_value=(*x)();
    scalar y_value=(*y)();
    product=x_value*y_value;
    sum=x_value+y_value;
  }
};

void ModelTest::test_message() {
  pointer_type(Model) root=new_pointer(Model);
  scalar x=3.14;
  subscribe(new_pointer(ModelWithUpdatableParameters(
              new VariableRepeater<scalar>(&x),
              new Constant_0<scalar>(2.72))),
            root);
  root->run();

  x=42.;
  root->run();
  root->pass_message(UpdateParameters("improved"));
  root->run();
}

int main() {
    ModelTest test_class;
    run_static_test(suscription);
    run_static_test(initialisation);
    run_static_test(clock);
    run_static_test(message);
}
