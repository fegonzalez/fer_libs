#ifndef IGNORE_HEADER_
#define IGNORE_HEADER_
template <typename T>
inline void ignore (T const &) {}
#endif
