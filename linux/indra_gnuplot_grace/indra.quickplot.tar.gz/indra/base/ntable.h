#ifndef INDRA_BASE_NTABLE_HEADER_
#define INDRA_BASE_NTABLE_HEADER_

#include "string_cast.h"
#include <map>
#include <string>

// list of arguments; must be constructed in reverse order

struct ArgumentListNil { } argument_nil;

template <typename CarT, typename CdrT>
struct ArgumentList {
  typedef CarT Car;
  typedef CdrT Cdr;

  ArgumentList(Car car, Cdr cdr) : car(car), cdr(cdr) { }

  template <typename ArgumentT>
  inline
  ArgumentList<ArgumentT, ArgumentList<Car, Cdr> >
  tabarg(ArgumentT arg) const {
    return ArgumentList<ArgumentT, ArgumentList<Car, Cdr> >(arg, *this);
  }

  Car car;
  Cdr cdr;
};

template <typename ArgumentT>
inline
ArgumentList<ArgumentT, ArgumentListNil>
tabarg(ArgumentT arg) {
  return ArgumentList<ArgumentT, ArgumentListNil>(arg, argument_nil);
}

// argument list of homogeneous elements

template <typename ArgumentT, unsigned int N>
struct RepeatedArgumentList {
  typedef ArgumentList<ArgumentT,
                       typename RepeatedArgumentList<ArgumentT, N-1>::Type>
    Type;
};

template <typename ArgumentT>
struct RepeatedArgumentList<ArgumentT, 0> {
  typedef ArgumentListNil Type;
};

// table

template <typename ArgumentListT, typename ValueT>
struct Table {
  typedef std::map<typename ArgumentListT::Car,
                   Table<typename ArgumentListT::Cdr, ValueT> > Data;

  template <typename ArgumentTCompat>
  void insert(ArgumentTCompat argument, ValueT value) {
    data[argument.car].insert(argument.cdr, value);
  }

  template <typename ArgumentTCompat>
  ValueT access(ArgumentTCompat argument) const {
    if (data.size()<2)
      throw
	std::string("not enough breakpoints in table at point ")
	+to_string(argument.car);

    typename Data::const_iterator upper=data.upper_bound(argument.car);
    if (upper==data.end())
      --upper;
    else if (upper==data.begin())
      ++upper;
    typename Data::const_iterator lower=upper; --lower;

    typename ArgumentListT::Car lower_breakpoint=lower->first;
    typename ArgumentListT::Car upper_breakpoint=upper->first;
    ValueT lower_data;
    try {
      lower_data=lower->second.access(argument.cdr);
    }
    catch (std::string const &error) {
      throw error+" "+to_string(lower_breakpoint)+" (lower)";
    }
    ValueT upper_data;
    try {
      upper_data=upper->second.access(argument.cdr);
    }
    catch (std::string const &error) {
      throw error+" "+to_string(upper_breakpoint)+" (upper)";
    }

    return linear(argument.car,
                  lower_breakpoint, lower_data,
                  upper_breakpoint, upper_data);
  }
private:
  Data data;

  // This function is valid for types like: float, double, Vector
  template <typename Arg, typename Val>
  inline static Val linear(Arg x, Arg x1, Val y1, Arg x2, Val y2) {
	return y2*(x-x1)/(x2-x1)+ y1*(x2-x)/(x2-x1);
  }
};

template <typename ValueT>
struct Table<ArgumentListNil, ValueT> {
  typedef ValueT Data;

  void insert(ArgumentListNil, ValueT value) {
    data=value;
  }

  ValueT access(ArgumentListNil) const {
    return data;
  }
private:
  Data data;
};

#endif
