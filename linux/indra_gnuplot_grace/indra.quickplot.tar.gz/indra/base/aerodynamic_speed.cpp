#include "aerodynamic_speed.h"
#include "base.h"

// default constructor
AerodynamicSpeed::AerodynamicSpeed():
  gamma(1.4), R(287.05),
  true_airspeed(0.0),

  pressure(101325.0),
  temperature(288.15),
  
  sea_level_pressure(101325.),
  sea_level_temperature(288.15)  
{

}

// constructor with atmospheric parameters
AerodynamicSpeed::AerodynamicSpeed( scalar temperature, scalar pressure,
                                    scalar sea_level_temperature=288.15,
                                    scalar sea_level_pressure=101325.):
  gamma(1.4), R(287.05),
  true_airspeed(0.0),

  pressure(pressure),
  temperature(temperature),
    
  sea_level_pressure(sea_level_pressure),
  sea_level_temperature(sea_level_temperature)
{

}

scalar AerodynamicSpeed::density() const 
{ 
  return pressure/(R*temperature);
}

scalar AerodynamicSpeed::sea_level_density() const 
{ 
  return sea_level_pressure/(R*sea_level_temperature);
}

scalar AerodynamicSpeed::local_sound_speed() const 
{
  return sqrt(gamma * R * temperature);
}

scalar AerodynamicSpeed::mach() const
{
  return true_airspeed / local_sound_speed();
};

void AerodynamicSpeed::set_atmospheric_parameters(scalar static_pressure,
                                                  scalar dynamic_pressure_,                                                  scalar temperature_)
{
   pressure = static_pressure;
   temperature = temperature_;
   
   true_airspeed = square_root(2. * (dynamic_pressure_)/density());

   
}


void AerodynamicSpeed::set_true_airspeed(scalar tas)
{
   true_airspeed = tas;
   
}

void AerodynamicSpeed::set_calibrated_airspeed(scalar cas)
{
   scalar const temporary_1 = sqrt(gamma*R*temperature*2./(gamma-1));
   scalar const temporary_2 = 1.+(gamma-1.)/2.*pow(cas,2.)/(gamma*R*sea_level_temperature);
   scalar const temporary_3 = (sea_level_pressure/pressure)*(pow(temporary_2,gamma/(gamma-1.))-1.);
   scalar const temporary_4 = sqrt((pow((temporary_3+1.), (gamma-1)/gamma))-1.);
   true_airspeed = temporary_1 * temporary_4;  
}

void AerodynamicSpeed::set_mach(scalar M)
{
  true_airspeed = M * local_sound_speed();

};


void AerodynamicSpeed::set_sea_level_atmospheric_parameters(scalar sea_level_temperature_,
                                                            scalar sea_level_pressure_)
{
   sea_level_pressure = sea_level_pressure_;
   sea_level_temperature = sea_level_temperature_;

   
}

scalar AerodynamicSpeed::eas()const 
{
  return true_airspeed * sqrt(density()/sea_level_density());
}

scalar AerodynamicSpeed::cas() const 
{
   scalar const Ptt = pressure * pow(1+(gamma-1.)/2.*mach()*mach(), gamma/(gamma-1));
   scalar const delta_pressure = Ptt - pressure;

   scalar const calibrated_airspeed = sqrt(2.0/(gamma-1)*gamma*R*sea_level_temperature) *
      pow( pow (delta_pressure/sea_level_pressure + 1., (gamma-1)/gamma) -1.0, 0.5);

  return calibrated_airspeed;
}
