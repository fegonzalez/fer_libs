#include "../base/periodic_functions.h"
#include <cmath>
#include <iostream>
#include <fstream>

using namespace std;

PeriodicFunctions::PeriodicFunctions(int spline_resolution,
                                     int spline_peaks_dete_resolution,
                                     scalar spline_peaks_minimum_offset_) :
           spline_res(spline_resolution),
           period(0.0),
           t12(0.0),
           amp_C(0.0),
           amp_lambda(0.0),
           crop_mode(0),
           crop_begin(0.0),
           crop_end(0.0),
           spline_peaks_detection_res(spline_peaks_dete_resolution),
           spline_peaks_minimum_offset(spline_peaks_minimum_offset_),
           t0(0.0),
           tf(0.0),
           m_am_line(0.0),
           b_am_line(0.0),
           n(0.0),
           w(0.0),
           damping(0.0),
           mean_exp_line_C(0.0),
           mean_exp_lambda(0.0),
           polyfit_x0(0.0),
           polyfit_x1(0.0),
           polyfit_x2(0.0),
           mean_line_m(2)
            {}

PeriodicFunctions::PeriodicFunctions() :
           spline_res(25),
           period(0.0),
           t12(0.0),
           amp_C(0.0),
           amp_lambda(0.0),
           crop_mode(0),
           crop_begin(0.0),
           crop_end(0.0),
           spline_peaks_detection_res(300),
           spline_peaks_minimum_offset(0.0),
           t0(0.0),
           tf(0.0),
           m_am_line(0.0),
           b_am_line(0.0),
           n(0.0),
           w(0.0),
           damping(0.0),
           mean_exp_line_C(0.0),
           mean_exp_lambda(0.0),
           polyfit_x0(0.0),
           polyfit_x1(0.0),
           polyfit_x2(0.0)

            {}


//  ~PeriodicFunctions();
 //create
void PeriodicFunctions::add_point(scalar x,scalar y) {
 points.add_controlpoint(float(x),float(y));
 return;
}
void PeriodicFunctions::reset_points(void) {
 points.clear_controlpoints();
return;
}


void PeriodicFunctions::crop(scalar t0_,scalar tf_,int mode) { //0_off_1_begin_2_end_3_both

 crop_mode=mode;
 crop_begin=t0_;
 crop_end=tf_;

return;
}
 //update
void PeriodicFunctions::compute() {

 //create spline

  points.typical_prepare_data();
  int size_points=points.get_size();

  t0=points.get_x_at(0);
  if(crop_mode==1 || crop_mode==3) t0=crop_begin;
  tf=points.get_x_at(size_points-1);
  if(crop_mode==2 || crop_mode==3) tf=crop_end;

  scalar dt=(tf-t0)/scalar(spline_res);

  scalar t=t0;
 for(int i=0 ;i<spline_res+1;i++) {
    spline.add_controlpoint(float(t),points.get_y(float(t)));
    t+=dt;
 }

 //maxs and mins detection

  dt=(tf-t0)/scalar(spline_peaks_detection_res);
  t=t0;

  scalar t1=t;
  scalar ft1=spline(float(t));

  t+=dt;
  scalar t2=t;
  scalar ft2=spline(float(t));

  t+=dt;
  scalar t3=t;
  scalar ft3=spline(float(t));

 for(int i=3 ;i<spline_peaks_detection_res;i++) {

    if((ft2>ft1 && ft2>ft3) || (ft2<ft1 && ft2<ft3)){
     if (peaks.get_size()==0 || fabs(peaks.get_x_at(peaks.get_size()-1)-t2)>spline_peaks_minimum_offset )
       peaks.add_controlpoint(float(t2),float(ft2));
    }
    t+=dt;

    t1=t2;
    t2=t3;

    ft1=ft2;
    ft2=ft3;

    t3=t;
    ft3=spline(float(t));

 }



 //mean amplitude straight line
 ControlPoints amplitude_line;
 ControlPoints amplitude_line_log;
  int is_odd;
  if(2*int(float(peaks.get_size())/2.0)==peaks.get_size()) is_odd=0;
  is_odd=1;

  for(int i=0;i<peaks.get_size()-is_odd;i=i+2) {

    scalar mean_point=(peaks.get_y_at(i) +  peaks.get_y_at(i+1) ) / 2.0;

    amplitude_line.add_controlpoint((peaks.get_x_at(i)+peaks.get_x_at(i+1))/2.0f,
                                    float(mean_point));

    amplitude_line_log.add_controlpoint((peaks.get_x_at(i)+peaks.get_x_at(i+1))/2.0f,
                                        log(float(mean_point)));

   }

   m_am_line=0;
   b_am_line=0;
   amplitude_line.less_squares_fit(&m_am_line,&b_am_line);
   amplitude_line.poly2_fit(&polyfit_x0,&polyfit_x1,&polyfit_x2);

   float m_log,b_log;
   amplitude_line_log.less_squares_fit(&m_log,&b_log);

   mean_exp_line_C=exp(b_log);
   mean_exp_lambda=m_log;


 //amplitude
 ControlPoints amplitude;
 ControlPoints amplitude_log;

  for(int i=0;i<peaks.get_size()-is_odd;i=i+2) {

   scalar mean_point1(0.0);
   scalar mean_point2(0.0);

   switch (mean_line_m)  {

    case 0 :  mean_point1=(peaks.get_x_at(i)+peaks.get_x_at(i+1))/2.0;
              mean_point2=(peaks.get_x_at(i)+peaks.get_x_at(i+1))/2.0;
              break;
    case 1 :  mean_point1=get_mean_line(peaks.get_x_at(i));
              mean_point2=get_mean_line(peaks.get_x_at(i+1));
              break;
    case 2 :  mean_point1=get_mean_poly_2(peaks.get_x_at(i));
              mean_point2=get_mean_poly_2(peaks.get_x_at(i+1));
              break;
    case 3 :  mean_point1=get_mean_exponential_line(peaks.get_x_at(i));
              mean_point2=get_mean_exponential_line(peaks.get_x_at(i+1));
              break;
   }

    amplitude.add_controlpoint((peaks.get_x_at(i)+peaks.get_x_at(i+1))/2.0f,
                               fabs((peaks.get_y_at(i+1)-float(mean_point2)) - (peaks.get_y_at(i)-float(mean_point1)) ));

    amplitude_log.add_controlpoint((peaks.get_x_at(i)+peaks.get_x_at(i+1))/2.0f,
                                   log(fabs((peaks.get_y_at(i+1)-float(mean_point2)) - (peaks.get_y_at(i)-float(mean_point1)) )));

   }

   float m_amb,b_amb;
   amplitude_log.less_squares_fit(&m_amb,&b_amb);

   amp_C=exp(b_amb);
   amp_lambda=m_amb;

   t12=-log(2.0)/amp_lambda;


  //period
  scalar local_w=0;
  for(int i=0;i<peaks.get_size()-1;i++)
    local_w+=fabs(peaks.get_x_at(i+1)-peaks.get_x_at(i));

  period=2*local_w/float(peaks.get_size()-1);


 //Final values
    w=2*M_PI/period;
    n=-log(2.0)/t12;
    damping=-n/sqrt(n*n+w*w);


return;
}

 //results
scalar PeriodicFunctions::get_period(void) {
 return period;
}

scalar PeriodicFunctions::get_t12() {
 return t12;
}

scalar PeriodicFunctions::get_n(void) {
 return n;
}

scalar PeriodicFunctions::get_w(void) {
 return w;
}

scalar PeriodicFunctions::get_damping_ratio(void) {
 return damping;
}
 //curves
scalar PeriodicFunctions::get_spline(scalar t) {
  return spline(float(t));
}

scalar PeriodicFunctions::get_amplitude(scalar t) {
 return amp_C*exp(amp_lambda*t);
}

scalar PeriodicFunctions::get_mean_exponential_line(scalar t) {
 return mean_exp_line_C*exp(mean_exp_lambda*t);
}

scalar PeriodicFunctions::get_mean_line(scalar t) {
 return m_am_line*t+b_am_line;
}

scalar PeriodicFunctions::get_mean_poly_2(scalar t) {
 return polyfit_x0 + polyfit_x1*t + polyfit_x2*t*t;
}


ControlPoints *PeriodicFunctions::get_peaks(void) {
 return &peaks;
}


void PeriodicFunctions::report(scalar dt) {

  std::cout << "#period = " << get_period() << "\n";
  std::cout << "#w = " <<  get_w() << "\n";
  std::cout << "#t12 = " << get_t12() << "\n";
  std::cout << "#damping_ratio = " << get_damping_ratio() << "\n";

 scalar t=t0;
 if(dt < 0.01) dt = 0.01;

 int size=int((tf-t0)/dt);
 for (int i=0;i<size;i++) {
  std::cout << t << '\t'
            << get_spline(t) << '\t'
            << get_peaks()->get_y(float(t)) << '\t'
            << get_mean_poly_2(t) << '\t'
            << "\n";

  t+=dt;
 }

return;
}

void PeriodicFunctions::report(std::string filename,scalar dt) {

 std::ofstream file;
 file.open(filename.c_str());
 file << "#period = " << get_period() << "\n";
 file << "#w = " << get_w() << "\n";
 file << "#t12 = " << get_t12() << "\n";
 file << "#damping_ratio = " << get_damping_ratio() << "\n";


 scalar t=t0;
 if(dt < 0.01) dt = 0.01;

 int size=int((tf-t0)/dt);
 for (int i=0;i<size;i++) {
  file << t << '\t'
            << get_spline(t) << '\t'
            << get_peaks()->get_y(float(t)) << '\t'
            << get_amplitude(t) << '\t'
             << get_mean(t) << '\t'
            << "\n";
  t+=dt;
 }

 file.close();
return;
}

void PeriodicFunctions::mean_line_mode(int mode) { // 0 point - 1 linear - 2 poly2 - 3 exp
mean_line_m = mode;
return;
}

scalar PeriodicFunctions::get_mean(scalar t) {

switch (mean_line_m)  {

 case 0 : return 0.0;
 case 1 : return get_mean_line(t);
 case 2 : return get_mean_poly_2(t);
 case 3 : return get_mean_exponential_line(t);

}

return 0.0;
}

