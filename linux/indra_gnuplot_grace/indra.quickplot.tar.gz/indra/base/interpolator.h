#ifndef INTERPOLATOR_HEADER_
#define INTERPOLATOR_HEADER_

#include "scalar.h"
#include <vector>
#include <cmath>

scalar polLagrange(std::vector<scalar> const &xi, std::vector<scalar> const &yi,
                                                                     scalar x);
  // Lagrange interpolating polynomial,which passes through the points (xi, yi)
  // the polynomial order is equal to the data vector dimension



/////////////////////////////////////////////////////////
//
// Class: Interpolation
//
/////////////////////////////////////////////////////////  
class LinearInterpolation {

 public:

  LinearInterpolation(){};
  ~LinearInterpolation(){};
 
  double interpolationGetY(scalar const x1,scalar const y1,
			   scalar const x2,scalar const y2,
			   scalar const x)
    {
      scalar y;
      scalar m=(y2 - y1)/(x2 - x1);      
      return y= y1 + m*(x - x1);
    }

  double interpolationGetX(scalar const x1,scalar const y1,
			   scalar const x2,scalar const y2,
			   scalar const y)
    {
      scalar x;
      scalar m=(x2 - x1)/(y2 - y1);      
      return x= x1 + m*(y - y1);
    }

  bool interval(scalar const x1, scalar const x2,
		scalar const x)
    {
      if(x<x1)
	{ return 0;}
      else if( (x>=x1) && (x<=x2) )
	{ return 1;}
      else if( x>x2 )
	{ return 0;}
      else
	{
	  return 0;
	}
    }

};



#endif
