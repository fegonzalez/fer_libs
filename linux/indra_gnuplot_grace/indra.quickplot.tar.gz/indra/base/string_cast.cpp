#include "string_cast.h"

using std::string;

string integer_to_string(int number) {
  std::ostringstream ss;
  ss << number;
  return ss.str();
}

int string_to_integer(string string_number) {
  std::istringstream ss(string_number);
  int number;
  ss >> number;
  return number;
}

scalar string_to_scalar(string string_number) {
  std::istringstream ss(string_number);
  scalar number;
  ss >> number;
  return number;
}
