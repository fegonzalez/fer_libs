#ifndef PARAMETER_FILE_HEADER_
#define PARAMETER_FILE_HEADER_

#include <map>
#include <iosfwd>
#include "string_cast.h"

/* The class "ParameterFile" reads a list of parameters values from a file, and
 * can be later consulted for them.  The file must consist of lines containing
 * the name of the parameter, followed by whitespace, and then, until the end
 * of the line, the value of the parameter:
 *
 *     name_1 value_1
 *     name_2 value_2
 *       .      .
 *       .      .
 *       .      .
 *     name_n value_n
 *
 * Lines starting with a '#' character are discarded.
 *
 * Queries for parameter values are templatised on the expected parameter
 * type.  Thus, if a parameter "foo_factor" is expected to be a "scalar", its
 * value can be obtained from the "ParameterFile" object "pars" with the
 * following invocation:
 *
 *     pars.parameter<scalar>("foo_factor")
 *
 * If the "parameter()" method is invoked only with the parameter name, and a
 * parameter with the given name is not found, an error is thrown.  A second
 * argument can be given to the "parameter()" method, which is the default
 * value for the parameter, i.e. the value returned if a parameter with the
 * given name is not found; thus, the two-argument "parameter()" method never
 * throws.
 */
class ParameterFile {
public:
  ParameterFile(std::string file_name);
  bool exists(std::string parameter_name) const;
  template <typename Type>
  Type parameter(std::string parameter_name) const {
    if (not exists(parameter_name))
      throw "parameter "+parameter_name+" not found in "+file_name;
    return string_to<Type>(map_name_value.find(parameter_name)->second);
  }
  template <typename Type, typename DefaultType>
  Type parameter(std::string parameter_name,
                 DefaultType const &default_value) const {
    if (not exists(parameter_name))
      return default_value;
    else
      return parameter<Type>(parameter_name);
  }
private:
  std::string file_name;
  std::map<std::string, std::string> map_name_value;
  friend std::ostream &operator<<(std::ostream &os, ParameterFile const &pf);

};

extern std::ostream &operator<<(std::ostream &os, ParameterFile const &pf);

#endif
