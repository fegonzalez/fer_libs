#include "modifiable_parameter.h"
#include "base.h"
#include "geometry.h"
#include <iostream>

using namespace cppfunct;
using namespace std;

struct FlightArgument {
  int aleph;
  scalar beth;
  Vector gimel;
  Quaternion daleth;
};

int main() {
try {
  FlightArgument flight_argument;
  flight_argument.beth=0.;
  ModifiableParameterDictionary<scalar (), FlightArgument>
    mpd(&flight_argument);

  scalar time=1.;
  Function<scalar ()> t=mpd.function("time", variable(&time));
  cout << "time: " << time << ", modified to: " << t() << endl;
  mpd.modify("time", 2.*arg<1, scalar>());
  cout << "time: " << time << ", modified to: " << t() << endl;

  mpd.modify("ability", .5*arg<1, scalar>()+42.);
  scalar stamina=0.;
  scalar skill=0.;
  Function<scalar ()> ability=variable(&stamina)+variable(&skill);
  Function<scalar ()> a=
    mpd.function("ability", ability);

  time=3.;
  stamina=100.;
  skill=23.;
  cout << "time: " << time << ", modified to: " << t() << endl;
  cout << "ability: " << ability() << ", modified to: " << a() << endl;
  mpd.modify("time",
             77.
             +arg<1, scalar>()
             +bind_arg<1>(attribute(&FlightArgument::beth),
                          arg<2, FlightArgument>()));
  cout << "time: " << time << ", modified to: " << t() << endl;
  flight_argument.beth=200.;
  cout << "time: " << time << ", modified to: " << t() << endl;
  modify_by_factor_offset(mpd, "time", 10., .3333);
  cout << "time: " << time << ", modified to: " << t() << endl;
  flight_argument.beth=3.;
  cout << "time: " << time << ", modified to: " << t() << endl;
  modify_by_factor_offset(mpd, "time",
                          arg_el(&FlightArgument::beth)-1., 0.);
  cout << "time: " << time << ", modified to: " << t() << endl;

  cout << "list of modifiable parameters:" << endl;
  list<string> name_list=mpd.name_list();
  for (list<string>::const_iterator scan=name_list.begin();
       scan!=name_list.end();
       ++scan)
    cout << "    " << *scan << endl;
} catch (std::string const &error) {
  cout << "catched error \"" << error << "\"" << endl;
  throw;
} catch (char const *
         error) {
  cout << "catched error \"" << error << "\"" << endl;
  throw;
}
}
