#ifndef WATCH_HEADER_
#define WATCH_HEADER_

#include "model.h"
#include "base.h"

class Watch
 : public Model {
public:
   Watch(scalar dt) : dt(dt), counter(0.) {}
   void model() { counter = counter + dt; }
   void reset() { counter = 0.; }
   scalar get_counter() { return counter; }
private:
   scalar const dt;
   scalar counter;
};
#endif
