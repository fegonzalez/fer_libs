#include "curve2d.h"
#include <cmath>
#include <cstring>

using namespace std;

bool is_equal(float a,float b,float error) {
 if(a > (b-error) && (a < b+error)) return true;
 return false;
}

ControlPoints::ControlPoints(){
 points.clear();
 points.empty();

 epsilon=1e-5f;
}

ControlPoints::ControlPoints(ControlPoints &last) {
 *this=last;
 epsilon=1e-5f;
}

ControlPoints::~ControlPoints(){
 points.clear();
 points.empty();
}

void ControlPoints::clear_controlpoints() {
 points.clear();
 points.empty();
return;
}

void ControlPoints::add_controlpoint(float x,float y) {
 _POINT t;
 t.x=x;
 t.y=y;
 points.push_back(t);
return;
}

void ControlPoints::add_controlpoint(char *filename) {

 FILE *fil=NULL;

 fil=fopen(filename,"r+");
 if(!fil) return;
 float xx=0.0,yy=0.0;

 while(1) {

  if(feof(fil)!=0) break;

  if(fscanf(fil,"%f",&xx)==0) break;
  if(fscanf(fil,"%f",&yy)==0) break;
  _POINT t;
  t.x=xx;
  t.y=yy;
  points.push_back(t);

 }
 fclose(fil);
return;
}

void ControlPoints::edit_controlpoint(int pos,float x,float y) {
  points.at(pos).x=x;
  points.at(pos).y=y;
return;
}

void ControlPoints::delete_controlpoint(int pos) {
 if((pos<0) || (pos >= (int) points.size() )) return;
 if(get_size()<=1) {clear_controlpoints();return;}
 points.erase(points.begin()+pos);
 return;
}

int ControlPoints::get_size(void) {
	return (int) points.size();
}

void  ControlPoints::get_at(float *x,float *y,int pos) {

 int size=(int) points.size();
 if(size<=0.0f) return;

 *x=points.at(pos).x;
 *y=points.at(pos).y;

return;
}

float  ControlPoints::get_x_at(int pos) {

 int size=(int) points.size();
 if(size<=0.0f) return 0.0;

 return points.at(pos).x;
}

float  ControlPoints::get_y_at(int pos) {

 int size=(int) points.size();
 if(size<=0.0f) return 0.0;

 return points.at(pos).y;
}

float  ControlPoints::get_y(float x_pos) {


 int size=(int) points.size();

 if (size == 1 ) return points.at(0).y;
 if (size == 0 ) return 0.0f;

  //Exact point?
  for(int i=0;i<size;i++) {
   if(is_equal(x_pos,points.at(i).x,epsilon)) return points.at(i).y;
  }

   //Extrapolation ?
   if(x_pos < points.at(0).x) {
     for(int i=1;i<size;i++) {

       if( (!is_equal(points.at(0).x,points.at(i).x,epsilon)) ||
           (!is_equal(points.at(0).y,points.at(i).y,epsilon)) ) {
             return points.at(0).y +
                    (points.at(0).y-points.at(i).y)*(x_pos-points.at(0).x) /
                    (points.at(0).x-points.at(i).x);
       }

    }
    return  points.at(0).y;
   }
   if(x_pos > points.at(size-1).x) {
     for(int i=size-2;i>=0;i--) {
       if( (!is_equal(points.at(size-1).x,points.at(i).x,epsilon)) ||
           (!is_equal(points.at(size-1).y,points.at(i).y,epsilon)) ) {

           return points.at(size-1).y +
                  (points.at(size-1).y-points.at(i).y)*(x_pos-points.at(size-1).x) /
                  (points.at(size-1).x-points.at(i).x);
       }
     }
    return points.at(size-1).y;
   }

 //  Interpolation
     for(int i=0;i<size;i++) {
       if( (x_pos > points.at(i).x ) &&
           (x_pos < points.at(i+1).x)) {

           if(is_equal(points.at(i+1).x,points.at(i).x,epsilon) ) return  points.at(i).x;
           else return points.at(i).y +
                       ( points.at(i+1).y-points.at(i).y ) /
                       ( points.at(i+1).x-points.at(i).x ) *
                       (x_pos-points.at(i).x);
                         }

      }

return points.at(size-1).y;
}

int ControlPoints::get_xmaxvalue(float *out) {

 int index_temp;

 if((int) points.size() <=0) return -1;
 *out=points.at(0).x;
 index_temp=0;

 for(int i=0;i<(int) points.size();i++) {

	  if(points.at(i).x > *out) {
		 *out=points.at(i).x;
		 index_temp=i;
	 }

 }

 return index_temp;

}

int ControlPoints::get_xminvalue(float *out) {

 int index_temp;

 if((int) points.size() <=0) return -1;
 *out=points.at(0).x;
 index_temp=0;

 for(int i=0;i<(int) points.size();i++) {
   if(points.at(i).x < *out) {
 	 *out=points.at(i).x;
	 index_temp=i;
   }
 }
 return index_temp;
}

int ControlPoints::get_ymaxvalue(float *out) {

 int index_temp;

 if((int) points.size() <=0) return -1;
 *out=points.at(0).y;
  index_temp=0;

 for(int i=0;i<(int) points.size();i++) {
	  if(points.at(i).y > *out) {
		 *out=points.at(i).y;
		 index_temp=i;
	 }

 }

 return index_temp;
}

int ControlPoints::get_ymaxvalue(float *out,float from) {

 int index_temp;

 if((int) points.size() <=0) return -1;
 *out=points.at(0).y;
  index_temp=0;

 for(int i=0;i<(int) points.size();i++) {

	  if(points.at(i).y > *out && points.at(i).x > from) {
		 *out=points.at(i).y;
		 index_temp=i;
	 }

 }

 return index_temp;

}


int ControlPoints::get_yminvalue(float *out) {

 int index_temp=0;

 if((int) points.size() <=0) return -1;
 *out=points.at(0).y;
 index_temp=0;

 for(int i=0;i<(int) points.size();i++) {

	 if(points.at(i).y < *out) {
		 *out=points.at(i).y;
		 index_temp=i;
	 }

 }

 return index_temp;

 }

void ControlPoints::get_buffered(float **buffered_pointer) {

	for(int i=0;i<(int) points.size();i++) {

		buffered_pointer[i][0]=points.at(i).x;
		buffered_pointer[i][1]=points.at(i).y;

	}
return;
}

void ControlPoints::get_unbuffered(float ***unbuffered_pointer) {

int i;
(*unbuffered_pointer)=new float *[(int) points.size()];


 for(i=0;i<(int) points.size();i++) (*unbuffered_pointer)[i]=new float[2];


	for(i=0;i<(int) points.size();i++) {

		(*unbuffered_pointer)[i][0]=points.at(i).x;
		(*unbuffered_pointer)[i][1]=points.at(i).y;
	}
return;
}


void ControlPoints::get_buffered(float *buffered_pointer_x,float *buffered_pointer_y ) {

	for(int i=0;i<(int) points.size();i++) {

		buffered_pointer_x[i]=points.at(i).x;
		buffered_pointer_y[i]=points.at(i).y;
	}

return;
}

void ControlPoints::get_unbuffered(float **unbuffered_pointer_x,float **unbuffered_pointer_y ) {

	*unbuffered_pointer_x=new float[(int)points.size()];
	*unbuffered_pointer_y=new float[(int)points.size()];

	for(int i=0;i<(int) points.size();i++) {

		(*unbuffered_pointer_x)[i]=points.at(i).x;
		(*unbuffered_pointer_y)[i]=points.at(i).y;

	}

return;
}



void ControlPoints::order_controlPoints(int type) {
						//0 x_++,
						//1 x_--,
						//2 y_++,
						//3 y_--,
						//4 distance origin++
						//5 distance origin--

if(type<0) return;
if(type>5) return;

  int i;
  _POINT temp;

  switch(type) {


	//x++
    case 0:

		for(i=0;i<(int) points.size()-1;i++) {

			if(points.at(i+1).x < points.at(i).x) {

				temp=points.at(i);
				points.at(i)=points.at(i+1);
				points.at(i+1)=temp;

				i=-1;

			}

		}

	break;

	//x--
	case 1:

		for(i=0;i<(int) points.size()-1;i++) {

			if(points.at(i+1).x > points.at(i).x) {

				temp=points.at(i);
				points.at(i)=points.at(i+1);
				points.at(i+1)=temp;

				i=-1;

			}

		}

	break;

	//y++
	case 2:

		for(i=0;i<(int) points.size()-1;i++) {

			if(points.at(i+1).y < points.at(i).y) {

				temp=points.at(i);
				points.at(i)=points.at(i+1);
				points.at(i+1)=temp;

				i=-1;

			}

		}

	break;

	//y--
	case 3:

		for(i=0;i<(int) points.size()-1;i++) {

			if(points.at(i+1).y > points.at(i).y) {

				temp=points.at(i);
				points.at(i)=points.at(i+1);
				points.at(i+1)=temp;

				i=-1;

			}

		}

	break;

	//distance origin++
	case 4:

		for(i=0;i<(int) points.size()-1;i++) {

			if( (points.at(i+1).y*points.at(i+1).y+
				 points.at(i+1).x*points.at(i+1).x) <
				(points.at(i).y*points.at(i).y+
				 points.at(i).x*points.at(i).x)
			   )

			  {

				temp=points.at(i);
				points.at(i)=points.at(i+1);
				points.at(i+1)=temp;

				i=-1;

			}

		}

	break;


	//distance origin--
	case 5:

		for(i=0;i<(int) points.size()-1;i++) {

			if( (points.at(i+1).y*points.at(i+1).y+
				 points.at(i+1).x*points.at(i+1).x) >
				(points.at(i).y*points.at(i).y+
				 points.at(i).x*points.at(i).x)
			   )

			  {

				temp=points.at(i);
				points.at(i)=points.at(i+1);
				points.at(i+1)=temp;

				i=-1;

			}

		}

	break;


	}


return;
}

void ControlPoints::less_squares_fit(float *m,float *b) {

 float sum_x(0.0);
 float sum_y(0.0);
 float sum_xy(0.0);
 float sum_xx(0.0);

 for(int i=0;i<int(points.size());i++) {

  sum_x+=points.at(i).x;
  sum_y+=points.at(i).y;
  sum_xx+=points.at(i).x*points.at(i).x;
  sum_xy+=points.at(i).x*points.at(i).y;

 }
 float nn=float(points.size());

  *m=(nn*sum_xy-sum_x*sum_y)/(nn*sum_xx-sum_x*sum_x);
  *b=(sum_xx*sum_y-sum_x*sum_xy)/(nn*sum_xx-sum_x*sum_x);

return;
}


void ControlPoints::poly2_fit(float *x0,float *x1,float *x2) {

 float ii;
 float sum_xi(0.0);
 float sum_xi2(0.0);
 float sum_xi3(0.0);
 float sum_xi4(0.0);
 float sum_yi(0.0);
 float sum_xiyi(0.0);
 float sum_xi2yi(0.0);

 ii=float(int(points.size()));

 for(int i=0;i<int(points.size());i++) {

  sum_xi+=points.at(i).x;
  sum_xi2+=points.at(i).x*points.at(i).x;
  sum_xi3+=points.at(i).x*points.at(i).x*points.at(i).x;
  sum_xi4+=points.at(i).x*points.at(i).x*points.at(i).x*points.at(i).x;
  sum_yi+=points.at(i).y;
  sum_xiyi+=points.at(i).x*points.at(i).y;
  sum_xi2yi+=points.at(i).x*points.at(i).x*points.at(i).y;

 }

 float a[3][3];

 a[0][0]=ii;
 a[0][1]=sum_xi;
 a[0][2]=sum_xi2;

 a[1][0]=sum_xi;
 a[1][1]=sum_xi2;
 a[1][2]=sum_xi3;

 a[2][0]=sum_xi2;
 a[2][1]=sum_xi3;
 a[2][2]=sum_xi4;

 float b[3];

 b[0]=sum_yi;
 b[1]=sum_xiyi;
 b[2]=sum_xi2yi;


 //computing inverse matrix
 float Det = (a[0][0]*a[1][1]*a[2][2] + a[1][0]*a[2][1]*a[0][2] + a[0][1]*a[1][2]*a[2][0] ) -
             (a[2][0]*a[1][1]*a[0][2] + a[2][1]*a[1][2]*a[0][0] + a[1][0]*a[0][1]*a[2][2] );


 float inv_a[3][3];

 inv_a[0][0]=( a[1][1]*a[2][2]-a[2][1]*a[1][2] ) / Det;
 inv_a[0][1]=(-1)*( a[1][0]*a[2][2]-a[1][2]*a[2][0] ) / Det;
 inv_a[0][2]=( a[1][0]*a[2][1]-a[2][0]*a[1][1] ) / Det;


 inv_a[1][0]=(-1)*( a[0][1]*a[2][2]-a[0][2]*a[2][1] ) / Det;
 inv_a[1][1]=( a[0][0]*a[2][2]-a[0][2]*a[2][0] ) / Det;
 inv_a[1][2]=(-1)*( a[0][0]*a[2][1]-a[2][0]*a[0][1] ) / Det;


 inv_a[2][0]=( a[0][1]*a[1][2]-a[1][1]*a[0][2] ) / Det;
 inv_a[2][1]=(-1)*( a[0][0]*a[1][2]-a[1][0]*a[0][2] ) / Det;
 inv_a[2][2]=( a[0][0]*a[1][1]-a[1][0]*a[0][1] ) / Det;


 float out_coef[3];
 out_coef[0]=0.0;
 out_coef[1]=0.0;
 out_coef[2]=0.0;

 for(int i=0;i<3;i++) {
  out_coef[0]+=inv_a[0][i]*b[i];
  out_coef[1]+=inv_a[1][i]*b[i];
  out_coef[2]+=inv_a[2][i]*b[i];
 }


 *x0=out_coef[0];
 *x1=out_coef[1];
 *x2=out_coef[2];


return;
}




void ControlPoints::eliminate_same_controlpoints(int type) {
						 //0 same x and y
						 //1 same x
						 //2 same y
						 //3 same x or y

 if(points.size()==0) return;
 if(type<0) return;
 if(type>3) return;

 bool cond=false;

 for(int i=0;i<int(points.size());i++) {
    for( int j=0;j<(int) points.size();j++) {

        if(i==j) continue;
	  //condition
	  switch(type) {
	      case 0:  cond= (is_equal(points.at(j).x,points.at(i).x,epsilon) &&
                              is_equal(points.at(j).y,points.at(i).y,epsilon));break;

	      case 1:  cond=is_equal(points.at(j).x,points.at(i).x,epsilon);break;

              case 2:  cond=is_equal(points.at(j).y,points.at(i).y,epsilon);break;

              case 3:  cond= (is_equal(points.at(j).x,points.at(i).x,epsilon)||
		              is_equal(points.at(j).y,points.at(i).y,epsilon));break;
		  }
              if(cond) {
                    delete_controlpoint(i);
                    i=-1;
	            break;
		  }

	  }
  }

return;
}


void ControlPoints::typical_prepare_data(void)  {

 eliminate_same_controlpoints(1);
 order_controlPoints(0);

return;
}


void ControlPoints::print(char *filename) {

FILE *fil=NULL;
fil=fopen(filename,"w");

for(int i=0;i<(int) points.size();i++) fprintf(fil,"%f %f\n",points.at(i).x,points.at(i).y);

fclose(fil);

return;
}

void ControlPoints::print(void) {


	for(int i=0;i<(int) points.size();i++) printf("%f %f\n",points.at(i).x,points.at(i).y);


return;
}


void ControlPoints::export_tecplot(char *filename) {

 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;

 fprintf(fil,"TITLE=\"Curve2dMath Export Data.Control points\"\n");
 fprintf(fil,"VARIABLES=\"X\" \"Y\" \n");

 fprintf(fil,"ZONE ,T= Curve2D , I= %d \n",(int) points.size());

 for(i=0;i<(int) points.size();i++) fprintf(fil,"%f %f\n",points.at(i).x,points.at(i).y);

 fclose(fil);

return;
}



ControlPoints &ControlPoints::operator=(ControlPoints &last) {

	points.clear();
	points.empty();

	for(int i=0;i<(int) last.points.size();i++) points.push_back(last.points.at(i));

return *this;
}

void ControlPoints::operator+=(ControlPoints &last) {

int size_min;

size_min=(int)points.size();
if((int) last.points.size()< size_min) size_min=(int) last.points.size();

for(int i=0;i<size_min;i++) {

	points.at(i).x+=last.points.at(i).x;
	points.at(i).y+=last.points.at(i).y;
}



return;
}

void ControlPoints::operator+=(float value) {

for(int i=0;i<(int)points.size();i++) {

	points.at(i).y+=value;

}


return;
}

void ControlPoints::operator-=(ControlPoints &last) {


int size_min;

size_min=(int)points.size();
if((int) last.points.size()< size_min) size_min=(int) last.points.size();

for(int i=0;i<size_min;i++) {

	points.at(i).x-=last.points.at(i).x;
	points.at(i).y-=last.points.at(i).y;
}


return;
}
void ControlPoints::operator-=(float value) {

for(int i=0;i<(int)points.size();i++) {

	points.at(i).y-=value;

}


return;
}

void ControlPoints::operator*=(ControlPoints &last) {

int size_min;

size_min=(int)points.size();
if((int) last.points.size()< size_min) size_min=(int) last.points.size();

for(int i=0;i<size_min;i++) {

	points.at(i).x*=last.points.at(i).x;
	points.at(i).y*=last.points.at(i).y;
}


return;
}

void ControlPoints::operator*=(float value) {

for(int i=0;i<(int)points.size();i++) {

	points.at(i).y*=value;

}


return;
}

void ControlPoints::operator/=(ControlPoints &last) {

int size_min;

size_min=(int)points.size();
if((int) last.points.size()< size_min) size_min=(int) last.points.size();

for(int i=0;i<size_min;i++) {

	if(!is_equal(last.points.at(i).x,0.0,epsilon)) points.at(i).x/=last.points.at(i).x;
	if(!is_equal(last.points.at(i).y,0.0,epsilon)) points.at(i).y/=last.points.at(i).y;
}


return;
}


void ControlPoints::operator/=(float value) {

if(is_equal(value,0,epsilon)) return;

for(int i=0;i<(int)points.size();i++) {

	points.at(i).y/=value;

}

return;
}

bool ControlPoints::operator==(ControlPoints &last) {

	if((int) points.size()!= (int) last.points.size()) return false;

	for(int i=0;i<(int) points.size();i++) {

		if(!is_equal(points.at(i).x,last.points.at(i).x,epsilon)) return false;
		if(!is_equal(points.at(i).y,last.points.at(i).y,epsilon)) return false;

	}

return true;
}

bool ControlPoints::operator!=(ControlPoints &last) {

	if(*this==last) return false;

return true;
}

//**********************************************************
//						 POLYCURVE
//**********************************************************

Polycurve2d::Polycurve2d() {

	controlpoints = new ControlPoints;
	points= &controlpoints->points;

	_resolution=100;
	_lenght=0.0f;
	_autopreparedata=false;

	_reference=false;

	fSeparator=-0.999990e+05;
	bUseSeparator=false;


return;
}


Polycurve2d::Polycurve2d(Polycurve2d &last) {


controlpoints = new ControlPoints;
points= &controlpoints->points;

_autopreparedata=false;
_reference=false;

*this=last;
_update();

}

Polycurve2d::~Polycurve2d() {

	if(!_reference) {
		if(controlpoints) {delete controlpoints;controlpoints=NULL;}
	}

}

void Polycurve2d::_update(void) {


if(_autopreparedata) controlpoints->typical_prepare_data();


 int i;
 float sum=0.0f;

 //Calcular arco en puntos de control
 points->at(0).arco=0.0f;

 sum=0.0f;
 for(i=1;i<(int)points->size();i++) {

  sum+=float(sqrt(
		         (points->at(i).x-points->at(i-1).x)*(points->at(i).x-points->at(i-1).x)+
				 (points->at(i).y-points->at(i-1).y)*(points->at(i).y-points->at(i-1).y)
				)
			);

  points->at(i).arco=sum;
 }


 _lenght=sum;

return;
}

void Polycurve2d::add_controlpoint(float x,float y) {

 controlpoints->add_controlpoint(x,y);
 _update();

return;
}

void Polycurve2d::delete_controlpoint(int pos) {

 controlpoints->delete_controlpoint(pos);
 _update();

return;
}

void Polycurve2d::init_reference(ControlPoints *input) {

	_reference=true;
	if(controlpoints) {delete controlpoints;controlpoints=NULL;}

	controlpoints=input;
	points= &controlpoints->points;


	return;
}


float Polycurve2d::get_lenght(void) {

	return _lenght;
}

int Polycurve2d::get_size(void) {

	return controlpoints->get_size();
}

float Polycurve2d::get_x(float y_pos) {

return _LinearInterpolationY(&(*points),y_pos,true);

}


float Polycurve2d::get_y(float x_pos)const {

return _LinearInterpolationX(&(*points),x_pos,true);

}


void Polycurve2d::get_x(float **x_cuts,float y_pos,int *size_cuts) {

_POINT t;
int i;

std::vector <_POINT> cuts;

//Punto exacto
for(i=0;i<(int) points->size();i++) {


	if(is_equal(points->at(i).y,y_pos,1e-5f)) {

		t.x=points->at(i).x;
		t.y=points->at(i).y;

		cuts.push_back(t);
	}

}

//Cuts
//Linear
for(i=0;i<(int) points->size()-1;i++) {

	if((points->at(i).y<y_pos) &&
		(points->at(i+1).y>y_pos) &&
		(!is_equal(points->at(i).y,points->at(i+1).y,1e-5f)) ) {

		t.y=y_pos;
		t.x=points->at(i).x+
			(points->at(i+1).x-points->at(i).x)/
			(points->at(i+1).y-points->at(i).y)*
			(y_pos-points->at(i).y);

		cuts.push_back(t);
	}
}


//salida
*(x_cuts)=new float[cuts.size()];


for(i=0;i< (int) cuts.size();i++) {

	(*x_cuts)[i]=cuts.at(i).x;

}

*size_cuts=(int) cuts.size();

return;
}


void Polycurve2d::get_y(float **y_cuts,float x_pos,int *size_cuts) {

_POINT t;
int i;

std::vector <_POINT> cuts;

//Punto exacto
for(i=0;i<(int) points->size();i++) {


	if(is_equal(points->at(i).x,x_pos,1e-5f)) {

		t.x=points->at(i).x;
		t.y=points->at(i).y;

		cuts.push_back(t);
	}

}

//Cuts
 //Linear

for(i=0;i<(int) points->size()-1;i++) {

	if((points->at(i).x<x_pos) &&
		(points->at(i+1).x>x_pos) &&
		(!is_equal(points->at(i).x,points->at(i+1).x,1e-5f)) ) {

		t.x=x_pos;
		t.y=points->at(i).y+
			(points->at(i+1).y-points->at(i).y)/
			(points->at(i+1).x-points->at(i).x)*
			(x_pos-points->at(i).x);

		cuts.push_back(t);
	}
}




//Salida
*(y_cuts)=new float[cuts.size()];


for(i=0;i< (int) cuts.size();i++) {

	(*y_cuts)[i]=cuts.at(i).y;

}

*size_cuts=(int) cuts.size();

return;
}

float Polycurve2d::moment(float origin,int integratepoints) {


 int size = (int)points->size();

 float sum;
 float xmin,xmax,dx;

 xmin=points->at(0).x;
 xmax=points->at(size-1).x;

 if(integratepoints<=2) return (xmax-xmin)*(points->at(0).y+points->at(size-1).y)/2.0f;

 //Simpson

 //Siempre impar
 if(integratepoints%2==0) integratepoints++;

 //Intervalo
 dx=(xmax-xmin)/float(integratepoints-1);

 sum=0.0f;
 //Extremos
 sum+=points->at(0).y;
 sum+=points->at(size-1).y;

 //Impares
 for(int i=1;i<integratepoints-1;i+=2) {

   sum+=4.0f*get_y(points->at(0).x+float(i)*dx)*(points->at(0).x+float(i)*dx-origin);
 }

 //Pares
 for(int i=2;i<integratepoints-1;i+=2) {

   sum+=2.0f*get_y(points->at(0).x+float(i)*dx)*(points->at(0).x+float(i)*dx-origin);
 }

return sum*dx/3.0f;

}

float Polycurve2d::application_point(float origin,int integratepoints) {

return moment(origin,integratepoints)/integrate(integratepoints);
}



void Polycurve2d::get_xY(float *x,float *y,
						 float param,
						 bool UseArcoTrue_ParmaToUnitFalse) {

int i;
int size=(int) points->size();
if(size<=0.0f) return;

if(size==1) {
	*x=points->at(0).x;
	*y=points->at(0).y;
}

if(!UseArcoTrue_ParmaToUnitFalse) param=_lenght*param;

//Puntos exactos
for(i=0;i<size;i++) {

	if(is_equal(param,points->at(i).arco,1e-5f)) {

		*x=points->at(i).x;
		*y=points->at(i).y;

		return;

	}
}

//Extrapolaciones
int index_2;
index_2=1;
float mod=0;

if(param<0.0) {


		for(i=1;i<size;i++) {

			mod=sqrt(
				(points->at(i).x-points->at(0).x)*(points->at(i).x-points->at(0).x) +
		        (points->at(i).y-points->at(0).y)*(points->at(i).y-points->at(0).y)
				);

			if(!is_equal(mod,0.0f,1e-5f)) {index_2=i;break;}

		}

		*x=points->at(0).x+param*(points->at(index_2).x-points->at(0).x)/mod;
		*y=points->at(0).y+param*(points->at(index_2).y-points->at(0).y)/mod;
		return;


}


if(param > points->at(size-1).arco) {


		for(i=size-1;i>=0;i--) {

			mod=sqrt( (points->at(size-1).x-points->at(i).x)*(points->at(size-1).x-points->at(i).x) +
		              (points->at(size-1).y-points->at(i).y)*(points->at(size-1).y-points->at(i).y)
					 );

			if(!is_equal(mod,0.0f,1e-5f)) {index_2=i;break;}

		}

		*x=points->at(size-1).x+param*(points->at(size-1).x-points->at(index_2).x)/mod;
		*y=points->at(size-1).y+param*(points->at(size-1).y-points->at(index_2).y)/mod;

		return;

}


//Caso general
//Linear
int index_1=0;

for(i=1;i<size;i++) {

	if(param<points->at(i).arco) {
		index_2=i;
		break;
	}

}

for(i=size-2;i>=0;i--) {

	if(param > points->at(i).arco) {
		index_1=i;
		break;
	}

}



*x=points->at(index_1).x+(param-points->at(index_1).arco)*(points->at(index_2).x-points->at(index_1).x)/(points->at(index_2).arco-points->at(index_1).arco);
*y=points->at(index_1).y+(param-points->at(index_1).arco)*(points->at(index_2).y-points->at(index_1).y)/(points->at(index_2).arco-points->at(index_1).arco);


return;
}

void  Polycurve2d::get_xY(float *x,float *y,float arco) {

	get_xY(x,y,arco,true);

return;
}


void Polycurve2d::export_tecplot(char *filename) {

 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;


 fprintf(fil,"TITLE=\"Curve2dMath Export Data\"\n");
 fprintf(fil,"VARIABLES=\"X\" \"Y\" \n");

 fprintf(fil,"ZONE ,T= Curve2D , I= %d \n",_resolution + 1);

 float x,y,t,dt;

 t=0.0f;
 dt=_lenght/float(_resolution);

 for(i=0;i<_resolution;i++) {

	 get_xY(&x,&y,t);

	 fprintf(fil,"%f %f\n",x,y);

	 t+=dt;

 }

 fprintf(fil,"%f %f\n",points->at(points->size()-1).x,points->at(points->size()-1).y);
 fclose(fil);

return;
}


void Polycurve2d::printPoints(char *filename) {


 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;

 float x,y,t,dt;

 t=0;
 dt=_lenght/float(_resolution);

 for(i=0;i<_resolution;i++) {

	 get_xY(&x,&y,t);

	 fprintf(fil,"%f %f\n",x,y);

	 t+=dt;

 }

 fprintf(fil,"%f %f\n",points->at(points->size()-1).x,points->at(points->size()-1).y);
 fclose(fil);

return;
}


void Polycurve2d::printPoints(void) {

 int i;

 float x,y,t,dt;

 t=0;
 dt=_lenght/float(_resolution);

 for(i=0;i<_resolution;i++) {

	 get_xY(&x,&y,t);

	 printf("%f %f\n",x,y);

	 t+=dt;

 }

 printf("%f %f\n",points->at(points->size()-1).x,points->at(points->size()-1).y);


return;
}

float Polycurve2d::integrate(int integratepoints) {


if(integratepoints<1) return 0.0f;

 Polycurve2d integratecurve;

 integratecurve=*this;

 integratecurve.controlpoints->typical_prepare_data();

 int size = (int)points->size();

 float sum;
 float xmin,xmax,dx;

 xmin=integratecurve.points->at(0).x;
 xmax=integratecurve.points->at(size-1).x;

 if(integratepoints<=2) return (xmax-xmin)*(integratecurve.points->at(0).y+
											integratecurve.points->at(size-1).y)/2.0f;

 //Simpson

 //Siempre impar
 if(integratepoints%2==0) integratepoints++;

 //Intervalo
 dx=(xmax-xmin)/float(integratepoints-1);

 sum=0.0f;
 //Extremos
 sum+=integratecurve.points->at(0).y;
 sum+=integratecurve.points->at(size-1).y;

 //Impares
 for(int i=1;i<integratepoints-1;i+=2) {

	 sum+=4.0f*get_y(integratecurve.points->at(0).x+float(i)*dx);
 }

 //Pares
 for(int i=2;i<integratepoints-1;i+=2) {

	 sum+=2.0f*get_y(integratecurve.points->at(0).x+float(i)*dx);
 }

return sum*dx/3.0f;

}

float Polycurve2d::integrate(int integratepoints,float minLimit,float maxLimit) {

if(integratepoints<1) return 0.0f;

 Polycurve2d integratecurve;

 integratecurve=*this;

 integratecurve.controlpoints->typical_prepare_data();

 int size = (int)points->size();

 float sum;
 float xmin,xmax,dx;

 xmin=minLimit;
 xmax=maxLimit;

 if(minLimit<integratecurve.points->at(0).x) xmin=integratecurve.points->at(0).x;
 if(maxLimit>integratecurve.points->at(size-1).x) xmax=integratecurve.points->at(size-1).x;


 if(integratepoints<=2) return (xmax-xmin)*(integratecurve.points->at(0).y+
											integratecurve.points->at(size-1).y)/2.0f;

 //Simpson

 //Siempre impar
 if(integratepoints%2==0) integratepoints++;

 //Intervalo
 dx=(xmax-xmin)/float(integratepoints-1);

 sum=0.0f;

 //Extremos
 sum+=integratecurve.get_y(xmin);
 sum+=integratecurve.get_y(xmax);

 //Impares
 for(int i=1;i<integratepoints-1;i+=2) {

	 sum+=4.0f*get_y(xmin+float(i)*dx);
 }

 //Pares
 for(int i=2;i<integratepoints-1;i+=2) {

	 sum+=2.0f*get_y(xmin+float(i)*dx);
 }

return sum*dx/3.0f;


}

void Polycurve2d::set_autopreparedata(bool value) {

	_autopreparedata=value;

return;
}

bool Polycurve2d::get_autopreparedata(void) {

	return _autopreparedata;
}

ControlPoints *Polycurve2d::get_controlPoints(void) {

	return controlpoints;
}

Polycurve2d &Polycurve2d::operator=(Polycurve2d &last) {

	_resolution=last._resolution;
	_lenght=last._lenght;
	_autopreparedata=last._autopreparedata;

	if(_reference ) controlpoints=last.controlpoints;
	if(!_reference && last._reference) {

		if(controlpoints) {
			delete controlpoints;
			controlpoints=NULL;
		}

	   controlpoints=last.controlpoints;
	}

	if(!_reference && !last._reference) *controlpoints=*last.controlpoints;

	_reference=last._reference;

	points= &controlpoints->points;

	_update();

return *this;
}

void Polycurve2d::operator+=(Polycurve2d &last) {

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)+=(*last.controlpoints);
_update();

return;
}


void Polycurve2d::operator+=(float value){

if(!controlpoints) return;

(*controlpoints)+=value;
_update();

return;
}

void Polycurve2d::operator-=(Polycurve2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)-=(*last.controlpoints);
_update();

return;
}
void Polycurve2d::operator-=(float value){

if(!controlpoints) return;

(*controlpoints)-=value;
_update();

return;
}

void Polycurve2d::operator*=(Polycurve2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)*=(*last.controlpoints);
_update();

return;
}
void Polycurve2d::operator*=(float value){

if(!controlpoints) return;

(*controlpoints)*=value;
_update();

return;
}

void Polycurve2d::operator/=(Polycurve2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)/=(*last.controlpoints);
_update();

return;
}
void Polycurve2d::operator/=(float value){

if(!controlpoints) return;

(*controlpoints)/=value;
_update();

return;
}

bool Polycurve2d::operator==(Polycurve2d &last) {

	if(!controlpoints) return false;
	if(!last.controlpoints) return false;

	if((*controlpoints)!=(*last.controlpoints)) return false;

	if(_resolution!=last._resolution) return false;
	if(!is_equal(_lenght,last._lenght,1e-5f)) return false;


return true;
}

bool Polycurve2d::operator!=(Polycurve2d &last) {

	if(!last.controlpoints) return true;

	if(*this==last) return false;

return true;
}



//**********************************************************
//						 SPLINES CUBICOS
//**********************************************************

Spline2d::Spline2d() {

 controlpoints = new ControlPoints;
 points= &controlpoints->points;
 _resolution=100;
 _lenght=0.0f;
 _y2=NULL;
 _der_left=1e31f;
 _der_right=1e31f;
 _type=2;
 _autopreparedata=true;
 _export_poly_control=true;
 _reference=false;
 strcpy(m_name,"");

return;
}


Spline2d::Spline2d(Spline2d &last) {

controlpoints = new ControlPoints;
points= &controlpoints->points;
_reference=false;

*this=last;
_update();

}

Spline2d::~Spline2d() {

	if(!_reference) {
		if(controlpoints) {delete controlpoints;controlpoints=NULL;}
	}

	_destroy_auxvars();
}

void Spline2d::_destroy_auxvars(void) {

 if(_y2) {delete [] _y2;_y2=NULL;}

return;
}

void Spline2d::clear_controlpoints(void) {

 controlpoints->clear_controlpoints();

return;

}
void Spline2d::_update(void) {

 if(!controlpoints) return;

 int np=(int) points->size();
 if(np<2) return;

 if(_autopreparedata) controlpoints->typical_prepare_data();

 if(np==2) return;

 if(is_equal(points->at(1).x,points->at(0).x,1e-5f)) return;

 _destroy_auxvars();

 _y2= new float [np];
 float *_u = new float [np-1];

 for(int k=0;k<np;k++)   _y2[k]=0.0f;
 for(int k=0;k<np-1;k++) _u[k]=0.0f;

 if (_der_left > 0.99e30) _y2[0]=_u[0]=0.0;
 else {
  _y2[0] = -0.5f;
  _u[0]=(3.0f/(points->at(1).x-points->at(0).x))*
       ((points->at(1).y-points->at(0).y)/(points->at(1).x-points->at(0).x)-_der_left);
 }

 float sig,p,un,qn;
 for (int i=1;i<np-1;i++) {

   sig=(points->at(i).x-points->at(i-1).x)/(points->at(i+1).x-points->at(i-1).x);
   p=sig*_y2[i-1]+2.0f;
   _y2[i]=(sig-1.0f)/p;
   _u[i]=(points->at(i+1).y-points->at(i).y)/(points->at(i+1).x-points->at(i).x) -
         (points->at(i).y-points->at(i-1).y)/(points->at(i).x-points->at(i-1).x);
   _u[i]=(6.0f*_u[i]/(points->at(i+1).x-points->at(i-1).x)-sig*_u[i-1])/p;

 }

 if (_der_right > 0.99e30) qn=un=0.0;
 else {
  qn=0.5f;
  un=(3.0f/(points->at(np-1).x-points->at(np-2).x))*
     (_der_right-(points->at(np-1).y-points->at(np-2).y)/(points->at(np-1).x-points->at(np-2).x));
 }
 _y2[np-1]=(un-qn*_u[np-2])/(qn*_y2[np-2]+1.0f);
 for (int k=np-2;k>=0;k--) _y2[k]=_y2[k]*_y2[k+1]+_u[k];

 if(_u) {delete [] _u;_u=NULL;}

 float param=0;

  for(int i=1;i<(int)points->size();i++) {
	 param=(points->at(i).x-points->at(0).x)/(points->at((int)points->size()-1).x-points->at(0).x);
	 points->at(i).arco=get_lenght(param);
  }

 _lenght=points->at((int)points->size()-1).arco;

 return;
}

void Spline2d::add_controlpoint(float x,float y) {

 controlpoints->add_controlpoint(x,y);
 _update();

return;
}

void Spline2d::add_controlpoint(char *filename) {

 controlpoints->add_controlpoint(filename);
 _update();

return;
}

void Spline2d::edit_controlpoint(int pos,float x,float y) {

 controlpoints->edit_controlpoint(pos,x,y);
 _update();

return;
}

void Spline2d::delete_controlpoint(int pos) {

 controlpoints->delete_controlpoint(pos);
 _update();

return;
}

void Spline2d::add_controlpoint(float x,float y,bool autou) {

 controlpoints->add_controlpoint(x,y);
 if(autou) _update();

return;
}

void Spline2d::delete_controlpoint(int pos,bool autou) {

 controlpoints->delete_controlpoint(pos);
 if(autou) _update();

return;
}


void Spline2d::init_reference(ControlPoints *input) {

 _reference=true;
 if(controlpoints) {delete controlpoints;controlpoints=NULL;}

 controlpoints=input;
 points= &controlpoints->points;

 return;
}

float Spline2d::get_lenghtX(float x_pos) {


 float x_min;
 float x_max;
 float dx,x,y,x0,y0,d;
 int size;

 size=(int)points->size();
 x_min=points->at(0).x;

 x_max=points->at(size-1).x;
 x_max=x_pos;

 x=x_min;

 x0=x_min;
 y0=points->at(0).y;

 dx=(x_max-x_min)/float(_resolution);

 d=0.0f;

 for(int i=0;i<_resolution;i++) {

  x+=dx;
  y=get_y(x);
  d+=(float) sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0));
  x0=x;
  y0=y;

}

return d;

}

float Spline2d::get_lenght(float param_To_unit) {

 return get_lenghtX(points->at(0).x+
  param_To_unit*(points->at(points->size()-1).x-points->at(0).x));
}

float Spline2d::get_lenght(void) {

 return _lenght;
}

int Spline2d::get_size(void) {

 return controlpoints->get_size();
}

void  Spline2d::set_resolution(int resol) {

 if(resol<1) return;

 _resolution=resol;

return;
}

int  Spline2d::get_resolution(void) {

 return _resolution;
}

float Spline2d::get_y(float x_pos) const {

 if(!controlpoints) return 9999999.99f;

 int np =(int) points->size();
 int size = np;

// if(np<0) return 9999999.99f;;
 if(np<0) return 0.0f;;
 if(np==0) return 0.0f;;
 if(np==1) return points->at(0).y;

 if(np==2 && is_equal(points->at(0).x,points->at(1).x,1e-5f)) return points->at(0).y;

 if(np==2) {

  //Truncated Extrapolations
  if(x_pos < points->at(0).x) return points->at(0).y;
  if(x_pos > points->at(1).x) return points->at(1).y;

    return points->at(0).y + ( points->at(1).y -points->at(0).y) /
                                    ( points->at(1).x -points->at(0).x) *
                                    ( x_pos-points->at(0).x);

  }

 //exact point
 for(int k=0;k<np;k++) {
  if(is_equal(points->at(k).x,x_pos,1e-5f)) return points->at(k).y;
 }

//Linear Extrapolations
 int index_2;
 index_2=1;
 float mod=0;

//Truncated Extrapolations
if(x_pos<points->at(0).x) return points->at(0).y;

if(x_pos<points->at(0).x) {

  for(int i=1;i<size;i++) {
 		mod=sqrt(
			(points->at(i).x-points->at(0).x)*(points->at(i).x-points->at(0).x) +
		        (points->at(i).y-points->at(0).y)*(points->at(i).y-points->at(0).y)
			);

			if(!is_equal(mod,0.0f,1e-5f)) {index_2=i;break;}
		}

       return _linearExtrapolation(points->at(0).x,points->at(0).y,
                                   points->at(index_2).x-points->at(0).x,
                                   points->at(index_2).y-points->at(0).y,
                                   x_pos);
}

//Truncated Extrapolations
if(x_pos > points->at(size-1).x) return points->at(size-1).y;

if(x_pos > points->at(size-1).x) {


  for(int i=size-1;i>=0;i--) {

    mod=sqrt( (points->at(size-1).x-points->at(i).x)*(points->at(size-1).x-points->at(i).x) +
	      (points->at(size-1).y-points->at(i).y)*(points->at(size-1).y-points->at(i).y)
	    );

        if(!is_equal(mod,0.0f,1e-5f)) {index_2=i;break;}

	 }

	return _linearExtrapolation(points->at(size-1).x,points->at(size-1).y,
                                    points->at(size-1).x-points->at(index_2).x,
                                    points->at(size-1).y-points->at(index_2).y,
                                    x_pos);
}

 int klo,khi,k;
 float h,b,a;
 klo=0;
 khi=np-1;

 while (khi-klo > 1) {
   k=(khi+klo) >> 1;
   if (points->at(k).x > x_pos) khi=k;
   else klo=k;
  }

  h=points->at(khi).x-points->at(klo).x;
  if (is_equal(h,0.0,1e-5f)) return -99999.99f;
  a=(points->at(khi).x-x_pos)/h;
  b=(x_pos-points->at(klo).x)/h;
  return a*points->at(klo).y+b*points->at(khi).y+((a*a*a-a)*_y2[klo]+(b*b*b-b)*_y2[khi])*(h*h)/6.0f;

}


void Spline2d::get_xY(float *x,float *y,float paramToUnit) {

 float xmin;
 float xmax;
 float t;

 int size=(int) points->size();
 xmin=points->at(0).x;
 xmax=points->at(size-1).x;

 t=xmin+paramToUnit*(xmax-xmin);

 *x=t;
 *y=get_y(t);

return;
}


void Spline2d::export_tecplot(char *filename) {

 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;


 fprintf(fil,"TITLE=\"Curve2dMath Export Data\"\n");
 fprintf(fil,"VARIABLES=\"X\" \"Y\" \n");

 fprintf(fil,"ZONE ,T= Curve2D , I= %d \n",_resolution );

 float x,y=0,dx;

 x=points->at(0).x;

 dx=(points->at((int) points->size()-1).x-points->at(0).x)/
	float(_resolution);

 for(i=0;i<_resolution;i++) {

	 y=get_y(x);

	 fprintf(fil,"%f %f\n",x,y);

	 x+=dx;

 }

  fprintf(fil,"%f %f\n",x,y);

  if(_export_poly_control) {

   fprintf(fil,"ZONE ,T= Control_Poly , I= %d \n",
		   (int) controlpoints->points.size() );

   for(i=0;i<(int) controlpoints->points.size();i++) {

	  x=controlpoints->points.at(i).x;
	  y=controlpoints->points.at(i).y;

	  fprintf(fil,"%f %f\n",x,y);

   }

 }


  fclose(fil);

return;
}



void Spline2d::printPoints(char *filename) {

 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;

 float x,y=0,dx;

 x=points->at(0).x;

 dx=(points->at((int) points->size()-1).x-points->at(0).x)/
	float(_resolution);

 for(i=0;i<_resolution;i++) {

	 y=get_y(x);

	 fprintf(fil,"%f %f\n",x,y);

	 x+=dx;

 }

  fprintf(fil,"%f %f\n",x,y);


 fclose(fil);

return;
}


void Spline2d::printPoints(void) {

 int i;

 float x,y=0,dx;

 x=points->at(0).x;

 dx=(points->at((int) points->size()-1).x-points->at(0).x)/
	float(_resolution);

 for(i=0;i<_resolution;i++) {

	 y=get_y(x);

	 printf("%f %f\n",x,y);

	 x+=dx;

 }

  printf("%f %f\n",x,y);



return;
}

float Spline2d::integrate(int integratepoints) {

 int size = (int)points->size();

 float sum;
 float xmin,xmax,dx;

 xmin=points->at(0).x;
 xmax=points->at(size-1).x;

 if(integratepoints<=2) return (xmax-xmin)*(points->at(0).y+points->at(size-1).y)/2.0f;

 //Simpson

 //Siempre impar
 if(integratepoints%2==0) integratepoints++;

 //Intervalo
 dx=(xmax-xmin)/float(integratepoints-1);

 sum=0.0f;
 //Extremos
 sum+=points->at(0).y;
 sum+=points->at(size-1).y;

 //Impares
 for(int i=1;i<integratepoints-1;i+=2) {

	 sum+=4.0f*get_y(points->at(0).x+float(i)*dx);
 }

 //Pares
 for(int i=2;i<integratepoints-1;i+=2) {

	 sum+=2.0f*get_y(points->at(0).x+float(i)*dx);
 }

return sum*dx/3.0f;
}

void Spline2d::set_autopreparedata(bool value) {

	_autopreparedata=value;

return;
}

bool Spline2d::get_autopreparedata(void) {

	return _autopreparedata;
}

ControlPoints *Spline2d::get_controlPoints(void) {

	return controlpoints;
}

Spline2d &Spline2d::operator=(Spline2d &last) {

	_resolution=last._resolution;
	_lenght=last._lenght;
	_autopreparedata=last._autopreparedata;
	_export_poly_control=last._export_poly_control;

	if(_reference ) controlpoints=last.controlpoints;
	if(!_reference && last._reference) {

		if(controlpoints) {
			delete controlpoints;
			controlpoints=NULL;
		}

	   controlpoints=last.controlpoints;
	}

	if(!_reference && !last._reference) *controlpoints=*last.controlpoints;

	_reference=last._reference;

	points= &controlpoints->points;

	_update();


return *this;
}


void Spline2d::operator+=(Spline2d &last) {

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)+=(*last.controlpoints);
_update();

return;
}


void Spline2d::operator+=(float value){

if(!controlpoints) return;

(*controlpoints)+=value;
_update();

return;
}

void Spline2d::operator-=(Spline2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)-=(*last.controlpoints);
_update();

return;
}
void Spline2d::operator-=(float value){

if(!controlpoints) return;

(*controlpoints)-=value;
_update();

return;
}

void Spline2d::operator*=(Spline2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)*=(*last.controlpoints);
_update();

return;
}
void Spline2d::operator*=(float value){

if(!controlpoints) return;

(*controlpoints)*=value;
_update();

return;
}

void Spline2d::operator/=(Spline2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)/=(*last.controlpoints);
_update();

return;
}
void Spline2d::operator/=(float value){

if(!controlpoints) return;

(*controlpoints)/=value;
_update();

return;
}

bool Spline2d::operator==(Spline2d &last) {

	if(!controlpoints) return false;
	if(!last.controlpoints) return false;

	if((*controlpoints)!=(*last.controlpoints)) return false;

	if(_resolution!=last._resolution) return false;
	if(!is_equal(_lenght,last._lenght,1e-5f)) return false;


return true;
}


bool Spline2d::operator!=(Spline2d &last) {

	if(!last.controlpoints) return true;

	if(*this==last) return false;

return true;
}

float Spline2d::moment(float origin,int integratepoints) {


 int size = (int)points->size();

 float sum;
 float xmin,xmax,dx;

 xmin=points->at(0).x;
 xmax=points->at(size-1).x;

 if(integratepoints<=2) return (xmax-xmin)*(points->at(0).y+points->at(size-1).y)/2.0f;

 //Simpson

 //Siempre impar
 if(integratepoints%2==0) integratepoints++;

 //Intervalo
 dx=(xmax-xmin)/float(integratepoints-1);

 sum=0.0f;
 //Extremos
 sum+=points->at(0).y;
 sum+=points->at(size-1).y;

 //Impares
 for(int i=1;i<integratepoints-1;i+=2) {

	 sum+=4.0f*get_y(points->at(0).x+float(i)*dx)*(points->at(0).x+float(i)*dx-origin);
 }

 //Pares
 for(int i=2;i<integratepoints-1;i+=2) {

	 sum+=2.0f*get_y(points->at(0).x+float(i)*dx)*(points->at(0).x+float(i)*dx-origin);
 }

return sum*dx/3.0f;

}

float Spline2d::application_point(float origin,int integratepoints) {

return moment(origin,integratepoints)/integrate(integratepoints);
}

//**********************************************************
//						 BEZIER 2D
//**********************************************************

Bezied2d::Bezied2d() {

	controlpoints = new ControlPoints;
	points= &controlpoints->points;

	_resolution=100;
	_lenght=0.0f;

	_comb=NULL;

	_reference=false;

	_export_poly_control=true;


return;
}


Bezied2d::Bezied2d(Bezied2d &last) {

controlpoints = new ControlPoints;
points= &controlpoints->points;
_reference=false;

*this=last;
_update();

}

Bezied2d::~Bezied2d() {

	if(!_reference) {
		if(controlpoints) {delete controlpoints;controlpoints=NULL;}
	}

	_destroy_auxvars();
}

void Bezied2d::_destroy_auxvars(void) {

 if(_comb) {delete [] _comb;_comb=NULL;}

return;
}

void Bezied2d::_update(void) {

//Reserva de memoria para los asistentes de los puntos de control

 if(!controlpoints) return;

  _destroy_auxvars();

//Coeficientes de los polinomios
  int i=0;
  int np=(int)points->size();
  _comb=new float[np];

  for(i=0;i<np;i++) {

	  _comb[i]=factor(np-1)/( factor(i)*factor(np-1-i) );
  }




/*
//OJO AQUI!!!!!
 float param;
 for(i=1;i<(int)points->size();i++) {

	 param=(points->at(i).x-points->at(0).x)/(points->at((int)points->size()-1).x-points->at(0).x);

	 points->at(i).arco=get_lenght(param);

 }

 _lenght=points->at((int)points->size()-1).arco;
*/


return;
}



void Bezied2d::add_controlpoint(float x,float y) {

 controlpoints->add_controlpoint(x,y);
 _update();

return;
}

void Bezied2d::delete_controlpoint(int pos) {

 controlpoints->delete_controlpoint(pos);
 _update();

return;
}

void Bezied2d::add_controlpoint(float x,float y,bool autou) {

 controlpoints->add_controlpoint(x,y);
 if(autou) _update();

return;
}

void Bezied2d::delete_controlpoint(int pos,bool autou) {

 controlpoints->delete_controlpoint(pos);
 if(autou) _update();

return;
}


void Bezied2d::init_reference(ControlPoints *input) {

	_reference=true;
	if(controlpoints) {delete controlpoints;controlpoints=NULL;}

	controlpoints=input;
	points= &controlpoints->points;

	return;
}


/*
float Spline2d::get_lenght(float param_To_unit) {

 return get_lenghtX(points->at(0).x+
					  param_To_unit*(points->at(points->size()-1).x-points->at(0).x)
					  );

}



float Spline2d::get_lenght(void) {

	return _lenght;
}
*/

int Bezied2d::get_size(void) {

	return controlpoints->get_size();
}



void Bezied2d::get_xY(float *x,float *y,
						 float paramToUnit) {

 int i;
 int np=(int)points->size();
 float u;
 float sumx=0.0f,sumy=0.0f,prod=1.0f;
 u=paramToUnit;


 for(i=0;i<np;i++) {

  prod=_comb[i];
  prod*=float( pow(u,float(i)));
  prod*=float(pow(1-u,float(np-1-i)));
  sumx+=prod*points->at(i).x;
  sumy+=prod*points->at(i).y;

 }

 *x=sumx;
 *y=sumy;

return;
}


void Bezied2d::export_tecplot(char *filename) {

 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;


 fprintf(fil,"TITLE=\"Curve2dMath Export Data\"\n");
 fprintf(fil,"VARIABLES=\"X\" \"Y\" \n");

 fprintf(fil,"ZONE ,T= Curve2D , I= %d \n",_resolution );

 float u,du,x=0,y=0;

 u=0.0f;

 du=1.0f/float(_resolution);

 for(i=0;i<_resolution;i++) {

	 get_xY(&x,&y,u);

	 fprintf(fil,"%f %f\n",x,y);

	 u+=du;

 }

  get_xY(&x,&y,u);
  fprintf(fil,"%f %f\n",x,y);

  if(_export_poly_control) {

   fprintf(fil,"ZONE ,T= Control_Poly , I= %d \n",
		   (int) controlpoints->points.size() );

   for(i=0;i<(int) controlpoints->points.size();i++) {

	  x=controlpoints->points.at(i).x;
	  y=controlpoints->points.at(i).y;

	  fprintf(fil,"%f %f\n",x,y);

   }

 }


  fclose(fil);

return;
}

void Bezied2d::printPoints(char *filename) {

 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;

 float u,du,x=0,y=0;

 u=0.0f;

 du=1.0f/float(_resolution);

 for(i=0;i<_resolution;i++) {

	 get_xY(&x,&y,u);

	 fprintf(fil,"%f %f\n",x,y);

	 u+=du;

 }

  get_xY(&x,&y,u);
  fprintf(fil,"%f %f\n",x,y);

  fclose(fil);

return;
}



/*
void Bezied2d::printPoints(char *filename) {


 int i;
 FILE *fil;
 fil=fopen(filename,"w");
 if(!fil) return;

 float x,y,dx;

 x=points->at(0).x;

 dx=(points->at((int) points->size()-1).x-points->at(0).x)/
	float(_resolution);

 for(i=0;i<_resolution;i++) {

	 y=get_y(x);

	 fprintf(fil,"%f %f\n",x,y);

	 x+=dx;

 }

  fprintf(fil,"%f %f\n",x,y);


 fclose(fil);

return;
}


void Bezied2d::printPoints(void) {

 int i;

 float x,y,dx;

 x=points->at(0).x;

 dx=(points->at((int) points->size()-1).x-points->at(0).x)/
	float(_resolution);

 for(i=0;i<_resolution;i++) {

	 y=get_y(x);

	 printf("%f %f\n",x,y);

	 x+=dx;

 }

  printf("%f %f\n",x,y);



return;
}

*/


ControlPoints *Bezied2d::get_controlPoints(void) {

	return controlpoints;
}


Bezied2d &Bezied2d::operator=(Bezied2d &last) {

	_resolution=last._resolution;
	_lenght=last._lenght;
	_export_poly_control=last._export_poly_control;

	if(_reference ) controlpoints=last.controlpoints;
	if(!_reference && last._reference) {

		if(controlpoints) {
			delete controlpoints;
			controlpoints=NULL;
		}

	   controlpoints=last.controlpoints;
	}

	if(!_reference && !last._reference) *controlpoints=*last.controlpoints;

	_reference=last._reference;

	points= &controlpoints->points;

	_update();


return *this;
}

void Bezied2d::operator+=(Bezied2d &last) {

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)+=(*last.controlpoints);
_update();

return;
}


void Bezied2d::operator+=(float value){

if(!controlpoints) return;

(*controlpoints)+=value;
_update();

return;
}

void Bezied2d::operator-=(Bezied2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)-=(*last.controlpoints);
_update();

return;
}
void Bezied2d::operator-=(float value){

if(!controlpoints) return;

(*controlpoints)-=value;
_update();

return;
}

void Bezied2d::operator*=(Bezied2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)*=(*last.controlpoints);
_update();

return;
}
void Bezied2d::operator*=(float value){

if(!controlpoints) return;

(*controlpoints)*=value;
_update();

return;
}

void Bezied2d::operator/=(Bezied2d &last){

if(!controlpoints) return;
if(!last.controlpoints) return;

(*controlpoints)/=(*last.controlpoints);
_update();

return;
}
void Bezied2d::operator/=(float value){

if(!controlpoints) return;

(*controlpoints)/=value;
_update();

return;
}


bool Bezied2d::operator==(Bezied2d &last) {

	if(!controlpoints) return false;
	if(!last.controlpoints) return false;

	if((*controlpoints)!=(*last.controlpoints)) return false;

	if(_resolution!=last._resolution) return false;
	if(!is_equal(_lenght,last._lenght,1e-5f)) return false;


return true;
}


bool Bezied2d::operator!=(Bezied2d &last) {

	if(!last.controlpoints) return true;

	if(*this==last) return false;

return true;
}


//**********************************************************
//						 FUNCIONES AUXILIARES
//**********************************************************


float _linearExtrapolation(float x_point,float y_point,float x_dir,float y_dir,float x_pos) {

	if (is_equal(x_dir,0.0f,1e-5f)) return x_pos;


	return y_point+y_dir*(x_pos-x_point)/x_dir;
}

float _LinearInterpolation(int size,float **x_point,float **y_point,float x_pos,bool ordered) {

	int i;

	//Chequeos de validez

	if (size == 1 ) return (*y_point)[0];

	if (size < 2 ) return 0.0f;

	for(i=0;i<size;i++) {

		if(!x_point[i]) return 0.0f;
		if(!y_point[i]) return 0.0f;
	}


	//Punto exacto
		for(i=0;i<size;i++) {

			if(is_equal(x_pos,(*x_point)[i],1e-5f)) return (*y_point)[i];

		}

	//Datos ordenados
	if(ordered) {


		//Posible extrapolaci�n
		if(x_pos < (*x_point)[0]) {


			for(i=1;i<size;i++) {

				if( ( !is_equal((*x_point)[0],(*x_point)[i],1e-5f) ) || (!is_equal((*y_point)[0],(*y_point)[i],1e-5f)) ) {

					return _linearExtrapolation((*x_point)[0],(*y_point)[0],
						(*x_point)[0]-(*x_point)[i],(*y_point)[0]-(*y_point)[i],x_pos);

				}

			}


		return 0.0f;

		}

		if(x_pos > (*x_point)[size-1]) {

			for(i=size-2;i>=0;i--) {

				if( (!is_equal((*x_point)[size-1],(*x_point)[i],1e-5f)) || (!is_equal((*y_point)[size-1],(*y_point)[i],1e-5f)) ) {

					return _linearExtrapolation((*x_point)[size-1],(*y_point)[size-1],
												(*x_point)[size-1]-(*x_point)[i],
												(*y_point)[size-1]-(*y_point)[i],x_pos);

				}

			}


		return 0.0f;

		}

		//Valor interpolado

		for(i=0;i<size;i++) {

			if( (x_pos > (*x_point)[i] ) && (x_pos < (*x_point)[i+1]) && !is_equal((*x_point)[i+1],(*x_point)[i],1e-5f) )

				return (*y_point)[i] +
				       ( (*y_point)[i+1]-(*y_point)[i] ) /
				       ( (*x_point)[i+1]-(*x_point)[i] ) *
				       (x_pos-(*x_point)[i]);

		}


	}

	//Si no estan ordenados interpolar por distancias
	else {

      int stationinit=0;
      int stationlast=1;

      float dist=(float) fabs(2*((*x_point)[size-1]-(*x_point)[0]));

     //busqueda de punto inferior
    for(i=0;i<size;i++) {

	 if(x_pos > (*x_point)[i])
	 {
		if(fabs(x_pos-(*x_point)[i])<dist) {
			dist=float(fabs(x_pos-(*x_point)[i]));
			stationinit=i;
		}
	 }

	}


   dist=(float)fabs(2*((*x_point)[size-1]-(*x_point)[0]));

   //busqueda de punto superior
   for(i=0;i<size;i++) {

	if(x_pos < (*x_point)[i])
	 {
		if( (fabs(x_pos-(*x_point)[i]) < dist) &&( i!=stationinit)) {
			dist=float(fabs(x_pos-(*x_point)[i]));
			stationlast=i;
		}
	 }

    }


  float xinit,xlast,yinit,ylast;

  xinit=(*x_point)[stationinit];
  xlast=(*x_point)[stationlast];

  yinit=(*y_point)[stationinit];
  ylast=(*y_point)[stationlast];

 return yinit+(x_pos-xinit)*(ylast-yinit)/(xlast-xinit);

}


return 0.0f;
}



float _LinearInterpolationX(std::vector <_POINT> *points,float x_pos,bool ordered) {

	int i;

	if(!points) return 0.0f;

	int size=(int) points->size();

	//Chequeos de validez

	if (size == 1 ) return points->at(0).y;

	if (size < 2 ) return 0.0f;


	//Punto exacto
		for(i=0;i<size;i++) {

			if(is_equal(x_pos,points->at(i).x,1e-5f)) return points->at(i).y;

		}

	//Datos ordenados
	if(ordered) {


	 //Posible extrapolaci�n
		if(x_pos < points->at(0).x) {


			for(i=1;i<size;i++) {

				if( (!is_equal(points->at(0).x,points->at(i).x,1e-5f)) || (!is_equal(points->at(0).y,points->at(i).y,1e-5f)) ) {

					return _linearExtrapolation(points->at(0).x,points->at(0).y,
						points->at(0).x-points->at(i).x,points->at(0).y-points->at(i).y,x_pos);

				}

			}


		return 0.0f;

		}

		if(x_pos > points->at(size-1).x) {

			for(i=size-2;i>=0;i--) {

				if( (!is_equal(points->at(size-1).x,points->at(i).x,1e-5f)) || (!is_equal(points->at(size-1).y,points->at(i).y,1e-5f)) ) {

					return _linearExtrapolation(points->at(size-1).x,points->at(size-1).y,
												points->at(size-1).x-points->at(i).x,
												points->at(size-1).y-points->at(i).y,x_pos);

				}

			}


		return 0.0f;

		}

		//Valor interpolado

		for(i=0;i<size;i++) {

			if( (x_pos > points->at(i).x ) && (x_pos < points->at(i+1).x) && !is_equal(points->at(i+1).x,points->at(i).x,1e-5f) )

				return points->at(i).y +
				       ( points->at(i+1).y-points->at(i).y ) /
				       ( points->at(i+1).x-points->at(i).x ) *
				       (x_pos-points->at(i).x);

		}


	}

	//Si no estan ordenados interpolar por distancias
	else {

      int stationinit=0;
      int stationlast=1;

      float dist=(float) fabs(2*(points->at(size-1).x-points->at(0).x));

     //busqueda de punto inferior
    for(i=0;i<size;i++) {

	 if(x_pos > points->at(i).x)
	 {
		if(fabs(x_pos-points->at(i).x)<dist) {
			dist=float(fabs(x_pos-points->at(i).x));
			stationinit=i;
		}
	 }

	}


   dist=(float)fabs(2*(points->at(size-1).x-points->at(0).x));

   //busqueda de punto superior

   stationlast=stationinit+1;

   for(i=0;i<size;i++) {

	if(x_pos < points->at(i).x)
	 {
		if( (fabs(x_pos-points->at(i).x) < dist) &&( i!=stationinit)) {
			dist=float(fabs(x_pos-points->at(i).x));
			stationlast=i;
		}
	 }

    }


  float xinit,xlast,yinit,ylast;

  xinit=points->at(stationinit).x;
  xlast=points->at(stationlast).x;

  yinit=points->at(stationinit).y;
  ylast=points->at(stationlast).y;

 return yinit+(x_pos-xinit)*(ylast-yinit)/(xlast-xinit);

}


return 0.0f;
}

float _LinearInterpolationY(std::vector <_POINT> *points,float y_pos,bool ordered) {

	int i;

	if(!points) return 0.0f;

	int size=(int) points->size();

	//Chequeos de validez

	if (size == 1 ) return points->at(0).x;

	if (size < 2 ) return 0.0f;


	//Punto exacto
		for(i=0;i<size;i++) {

			if(is_equal(y_pos,points->at(i).y,1e-5f)) return points->at(i).x;

		}

	//Datos ordenados
	if(ordered) {


		//Posible extrapolaci�n
		if(y_pos < points->at(0).y) {


			for(i=1;i<size;i++) {

				if( (!is_equal(points->at(0).y,points->at(i).y,1e-5f)) || (!is_equal(points->at(0).x,points->at(i).x,1e-5f)) ) {

					return _linearExtrapolation(points->at(0).y,points->at(0).x,
						points->at(0).y-points->at(i).y,points->at(0).x-points->at(i).x,y_pos);

				}

			}


		return 0.0f;

		}

		if(y_pos > points->at(size-1).y) {

			for(i=size-2;i>=0;i--) {

				if( (!is_equal(points->at(size-1).y,points->at(i).y,1e-5f)) || (!is_equal(points->at(size-1).x,points->at(i).x,1e-5f)) ) {

					return _linearExtrapolation(points->at(size-1).y,points->at(size-1).x,
												points->at(size-1).y-points->at(i).y,
												points->at(size-1).x-points->at(i).x,y_pos);

				}

			}


		return 0.0f;

		}

		//Valor interpolado

		for(i=0;i<size;i++) {

			if( (y_pos > points->at(i).y ) && (y_pos < points->at(i+1).y) && !is_equal(points->at(i+1).y,points->at(i).y,1e-5f) )

				return points->at(i).x +
				       ( points->at(i+1).x-points->at(i).x ) /
				       ( points->at(i+1).y-points->at(i).y ) *
				       (y_pos-points->at(i).y);

		}


	}

	//Si no estan ordenados interpolar por distancias
	else {

      int stationinit=0;
      int stationlast=1;

      float dist=(float) fabs(2*(points->at(size-1).y-points->at(0).y));

     //busqueda de punto inferior
    for(i=0;i<size;i++) {

	 if(y_pos > points->at(i).y)
	 {
		if(fabs(y_pos-points->at(i).y)<dist) {
			dist=float(fabs(y_pos-points->at(i).y));
			stationinit=i;
		}
	 }

	}


   dist=(float)fabs(2*(points->at(size-1).y-points->at(0).y));

   //busqueda de punto superior

   stationlast=stationinit+1;

   for(i=0;i<size;i++) {

	if(y_pos < points->at(i).y)
	 {
		if( (fabs(y_pos-points->at(i).y) < dist) &&( i!=stationinit)) {
			dist=float(fabs(y_pos-points->at(i).y));
			stationlast=i;
		}
	 }

    }


  float xinit,xlast,yinit,ylast;

  xinit=points->at(stationinit).y;
  xlast=points->at(stationlast).y;

  yinit=points->at(stationinit).x;
  ylast=points->at(stationlast).x;

 return yinit+(y_pos-xinit)*(ylast-yinit)/(xlast-xinit);

}


return 0.0f;
}


/*
void deletedoublepointer(void ***pointer,int size) {

	for(int i=0;i<size;i++) {


		if(pointer) {

			if( (*pointer)[i] ) {

			delete [] (*pointer)[i];
 			(*pointer)[i]=NULL;

		   }

			if(pointer) {
				delete [] pointer;
				pointer=NULL;
			}
		}
    }

return;

 }
*/
float factor(int value) {

 if (value==1) return 1.0f;
 if (value==0) return 1.0f;
 if (value<0) return 1.0f;

 double sum;
 sum=1.0f;

 do {
  sum=sum*value;
  value--;
 }while(value>1);

return float(sum);
}
