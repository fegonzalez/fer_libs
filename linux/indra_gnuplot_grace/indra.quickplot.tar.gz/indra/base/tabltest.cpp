#include "table.h"
#include "base.h"
#include <iostream>

using std::cout;
using std::endl;

int main()
{
   scalar nodes_1[]=   { 2, 3, 5, 6 };
   scalar values_1[]= { 1, 3, 4, 2 };
     {
	cout << "Table_1D_linear(limit)" << endl;
	Table_1D_linear t1dl(new_pointer(Data_1D(nodes_1, values_1, 4)),
			     Table_1D::limit);
	cout << "t1dl(1.) = " << t1dl(1.) << endl;
	cout << "t1dl(2.) = " << t1dl(2.) << endl;
	cout << "t1dl(2.5) = " << t1dl(2.5) << endl;
	cout << "t1dl(4.) = " << t1dl(4.) << endl;
	cout << "t1dl(5.) = " << t1dl(5.) << endl;
	cout << "t1dl(6.) = " << t1dl(6.) << endl;
	cout << "t1dl(8.) = " << t1dl(8.) << endl;
     }
     {
	cout << "Table_1D_linear(extrapolate)" << endl;
	Table_1D_linear t1dl(new_pointer(Data_1D(nodes_1, values_1, 4)),
			     Table_1D::extrapolate);
	cout << "t1dl(1.) = " << t1dl(1.) << endl;
	cout << "t1dl(2.) = " << t1dl(2.) << endl;
	cout << "t1dl(2.5) = " << t1dl(2.5) << endl;
	cout << "t1dl(4.) = " << t1dl(4.) << endl;
	cout << "t1dl(5.) = " << t1dl(5.) << endl;
	cout << "t1dl(6.) = " << t1dl(6.) << endl;
	cout << "t1dl(8.) = " << t1dl(8.) << endl;
 	cout << "First = 2 -> " << t1dl.first_node();
	cout << "\tLast = 6 -> " << t1dl.last_node() << endl;
    }
	 {

	 scalar *nodes_2=new scalar[4];
	 nodes_2[0]=2;
	 nodes_2[1]=3;
	 nodes_2[2]=5;
	 nodes_2[3]=6;

	 scalar *values_2=new scalar[4];
	 values_2[0]=1;
	 values_2[1]=3;
	 values_2[2]=4;
	 values_2[3]=2;

	cout << "Table_1D_copy_linear(limit)" << endl;
	Table_1D_linear t1dl(new_pointer(Data_1D_copy(nodes_2, values_2, 4)),
			     Table_1D::limit);


	 nodes_2[0]=1;
	 nodes_2[1]=2;
	 nodes_2[2]=3;
	 nodes_2[3]=4;

	 values_2[0]=6;
	 values_2[1]=7;
	 values_2[2]=8;
	 values_2[3]=9;


	cout << "t1dl(1.) = " << t1dl(1.) << endl;
	cout << "t1dl(2.) = " << t1dl(2.) << endl;
	cout << "t1dl(2.5) = " << t1dl(2.5) << endl;
	cout << "t1dl(4.) = " << t1dl(4.) << endl;
	cout << "t1dl(5.) = " << t1dl(5.) << endl;
	cout << "t1dl(6.) = " << t1dl(6.) << endl;
	cout << "t1dl(8.) = " << t1dl(8.) << endl;

	delete[] nodes_2;
	delete[] values_2;
     }
     {

	scalar *nodes_2=new scalar[4];
	 nodes_2[0]=2;
	 nodes_2[1]=3;
	 nodes_2[2]=5;
	 nodes_2[3]=6;

	 scalar *values_2=new scalar[4];
	 values_2[0]=1;
	 values_2[1]=3;
	 values_2[2]=4;
	 values_2[3]=2;

	cout << "Table_1D_copy_linear(extrapolate)" << endl;
	Table_1D_linear t1dl(new_pointer(Data_1D_copy(nodes_1, values_1, 4)),
			     Table_1D::extrapolate);

	 nodes_2[0]=1;
	 nodes_2[1]=2;
	 nodes_2[2]=3;
	 nodes_2[3]=4;

	 values_2[0]=6;
	 values_2[1]=7;
	 values_2[2]=8;
	 values_2[3]=9;


	cout << "t1dl(1.) = " << t1dl(1.) << endl;
	cout << "t1dl(2.) = " << t1dl(2.) << endl;
	cout << "t1dl(2.5) = " << t1dl(2.5) << endl;
	cout << "t1dl(4.) = " << t1dl(4.) << endl;
	cout << "t1dl(5.) = " << t1dl(5.) << endl;
	cout << "t1dl(6.) = " << t1dl(6.) << endl;
	cout << "t1dl(8.) = " << t1dl(8.) << endl;
 	cout << "First = 2 -> " << t1dl.first_node();
	cout << "\tLast = 6 -> " << t1dl.last_node() << endl;
	delete[] nodes_2;
	delete[] values_2;

    }
   scalar nodes_x[]= { 2, 3, 5, 6 };
   scalar nodes_y[]= { 4, 6, 7 };
   scalar values[]= { 1, 6, 8, 0,
                       3, 0, 1, 6,
                       1, 2, 2, 5 };
     {
	cout << "Table_2D_linear(limit, limit)" << endl;
	Table_2D_linear t2dl(new_pointer(Data_2D(nodes_x, nodes_y, values,
                                                 4, 3)),
			     Table_2D::limit, Table_2D::limit);
	cout << "t2dl(2., 4.) = " << t2dl(2., 4.) << endl;
	cout << "t2dl(4., 4.) = " << t2dl(4., 4.) << endl;
	cout << "t2dl(7., 4.) = " << t2dl(7., 4.) << endl;
	cout << "t2dl(2., 5.) = " << t2dl(2., 5.) << endl;
	cout << "t2dl(2., 8.) = " << t2dl(2., 8.) << endl;
	cout << "t2dl(4., 5.) = " << t2dl(4., 5.) << endl;
	cout << "t2dl(3.5, 5.) = " << t2dl(3.5, 5.) << endl;
	cout << "t2dl(4., 4.5) = " << t2dl(4., 4.5) << endl;
	cout << "t2dl(8., 8.) = " << t2dl(8., 8.) << endl;
     }
     {
	cout << "Table_2D_linear(extrapolate, extrapolate)" << endl;
	Table_2D_linear t2dl(new_pointer(Data_2D(nodes_x, nodes_y, values,
                                                 4, 3)),
			     Table_2D::extrapolate, Table_2D::extrapolate);
	cout << "t2dl(2., 4.) = " << t2dl(2., 4.) << endl;
	cout << "t2dl(4., 4.) = " << t2dl(4., 4.) << endl;
	cout << "t2dl(7., 4.) = " << t2dl(7., 4.) << endl;
	cout << "t2dl(2., 5.) = " << t2dl(2., 5.) << endl;
	cout << "t2dl(2., 8.) = " << t2dl(2., 8.) << endl;
	cout << "t2dl(4., 5.) = " << t2dl(4., 5.) << endl;
	cout << "t2dl(3.5, 5.) = " << t2dl(3.5, 5.) << endl;
	cout << "t2dl(4., 4.5) = " << t2dl(4., 4.5) << endl;
	cout << "t2dl(8., 8.) = " << t2dl(8., 8.) << endl;
	cout << "First_x = 2 -> " << t2dl.first_node_x();
	cout << "\tLast_x = 6 -> " << t2dl.last_node_x() << endl;
	cout << "First_y = 4 -> " << t2dl.first_node_y();
	cout << "\tLast_y = 7 -> " << t2dl.last_node_y() << endl;
     }
     {
	cout << endl << "Tests with files" << endl << endl;
	cout << "File table_test.1D.txt" << endl;
	cout << "Table_1D_linear(limit)" << endl;
	Table_1D_linear t1dl(new_pointer(Data_1D_file("table_test.1D.txt")),
			     Table_1D::limit);
	cout << "t1dl(1.) = " << t1dl(1.) << endl;
	cout << "t1dl(2.) = " << t1dl(2.) << endl;
	cout << "t1dl(2.5) = " << t1dl(2.5) << endl;
	cout << "t1dl(4.) = " << t1dl(4.) << endl;
	cout << "t1dl(5.) = " << t1dl(5.) << endl;
	cout << "t1dl(6.) = " << t1dl(6.) << endl;
	cout << "t1dl(8.) = " << t1dl(8.) << endl;
  	cout << "First = 2 -> " << t1dl.first_node();
	cout << "\tLast = 6 -> " << t1dl.last_node() << endl;
    }
     {
	cout << "File table_test.2D.txt" << endl;
	cout << "Table_2D_linear(extrapolate, extrapolate)" << endl;
	Table_2D_linear t2dl(new_pointer(Data_2D_file("table_test.2D.txt")),
			     Table_2D::extrapolate, Table_2D::extrapolate);
	cout << "t2dl(2., 4.) = " << t2dl(2., 4.) << endl;
	cout << "t2dl(4., 4.) = " << t2dl(4., 4.) << endl;
	cout << "t2dl(7., 4.) = " << t2dl(7., 4.) << endl;
	cout << "t2dl(2., 5.) = " << t2dl(2., 5.) << endl;
	cout << "t2dl(2., 8.) = " << t2dl(2., 8.) << endl;
	cout << "t2dl(4., 5.) = " << t2dl(4., 5.) << endl;
	cout << "t2dl(3.5, 5.) = " << t2dl(3.5, 5.) << endl;
	cout << "t2dl(4., 4.5) = " << t2dl(4., 4.5) << endl;
	cout << "t2dl(8., 8.) = " << t2dl(8., 8.) << endl;
	cout << "First_x = 2 -> " << t2dl.first_node_x();
	cout << "\tLast_x = 6 -> " << t2dl.last_node_x() << endl;
	cout << "First_y = 4 -> " << t2dl.first_node_y();
	cout << "\tLast_y = 7 -> " << t2dl.last_node_y() << endl;
     }
     {
	cout << endl << "Tests with files" << endl << endl;
	cout << "File table_test.TimeHistory.txt" << endl;
	cout << "Table_TimeHistory_linear(limit)" << endl;

	DataTimeHistoryFile data_time("table_identifier.txt", new_pointer(HeaderReaderDefault));
        DataTimeHistoryFile data_time_2("table_identifier.txt", new_pointer(HeaderReaderDefault));

        data_time.append(data_time_2,"TIME");

	scalar const * nodes = data_time.get("TIME");
	scalar const * values = data_time.get("COLUMN1");
	unsigned int data_size = data_time.get_lenght("TIME");

	Table_1D_linear t1dl(new_pointer(Data_1D(nodes, values, data_size)),
			     Table_1D::limit);

	cout << "t1dl(1.) = " << t1dl(15.) << endl;
	cout << "t1dl(2.) = " << t1dl(2.) << endl;
	cout << "t1dl(2.5) = " << t1dl(2.5) << endl;
	cout << "t1dl(4.) = " << t1dl(4.) << endl;
	cout << "t1dl(5.) = " << t1dl(5.) << endl;
	cout << "t1dl(6.) = " << t1dl(6.) << endl;
	cout << "t1dl(8.) = " << t1dl(8.) << endl;
  	cout << "First = 0 -> " << t1dl.first_node();
	cout << "\tLast = 10 -> " << t1dl.last_node() << endl;
        cout << "Append two datatimehistory (same input file)" << endl;
	cout << "t1dl(15.) = " << t1dl(15.) << endl;
	cout << "t1dl(16.) = " << t1dl(16.) << endl;
    }
}
