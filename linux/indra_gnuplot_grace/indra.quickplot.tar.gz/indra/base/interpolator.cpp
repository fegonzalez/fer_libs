
#include "interpolator.h"

using std::vector;

scalar polLagrange(vector <scalar> const &xi, vector <scalar> const &yi,
                                                                      scalar x)
{   
   const int dimension=xi.size();
   scalar sum= 0.0;
   scalar product= 1.0;
   
   for(int j=0; j<dimension; j++)
   {
      for(int k=0; k<dimension;k++ )
      {
         if(k!=j)
	 {
            product= product*(x-xi[k])/(xi[j]-xi[k]);
	 }
      }   
      sum= sum + yi[j]*product;      
      product= 1.0;
   }	 
   return sum;
}
