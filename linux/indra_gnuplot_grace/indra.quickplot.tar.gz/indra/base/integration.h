#ifndef INTEGRATION_HEADER_
#define INTEGRATION_HEADER_

#include "base.h"

/* Indirect definition of derivative type.  Types to be integrated must have
 * either a "DerivativeType" typedef, or a specialisation of "Derivative" (like
 * double, float). */
template <typename Type>
struct Derivative {
  typedef typename Type::DerivativeType Result;
};

template <> struct Derivative<double> { typedef double Result; };
template <> struct Derivative<float> { typedef float Result; };

/* The parametrizable abstract Integrator type integrates a function
 * in time, with a constant time step (given to the constructor: dt).
 * The integrand and integral types parameterize Integrator.
 * The integrator is initialised providing integrand and integral values,
 * by means of the initialise method. The values of the integrand throughout
 * time are provided to Integrator by means  of its integrate() method.
 * The integral value can be obtained from the return integrate() value,
 * or by converting Integrator into the integral type. The integral value
 * can be forced by means of the forced() method.
 * A large part of the implementation of Integrator is empty. The subclasses
 * which implement the interface have to provide code for at least initialise()
 * and integrate(). The subclasses which implement Integrator involve
 * different integration schemes. */

template <class Type, class Integrand=typename Derivative<Type>::Result>
class Integrator {
 public:
   Integrator(scalar dt) : Dt(dt), integral() { }; // dt is the t step
   virtual ~Integrator() { };
   virtual void initialise(Integrand x, Type y)=0;
   virtual Type forced(Type y) { return integral=y; };
   virtual operator Type() const { return integral; };
   virtual Type integrate(Integrand x)=0;
 protected:
   scalar const Dt;
   Type integral;
};

// Rectangular integrator
template <class Type, class Integrand=typename Derivative<Type>::Result>
class RectangularIntegrator : public Integrator<Type, Integrand>
{
 public:
   RectangularIntegrator(scalar dt) : Integrator<Type, Integrand>(dt) { };
   void initialise(Integrand x, Type y) { (void)x; this->integral=y; };
   Type integrate(Integrand x) { this->integral+=this->Dt*x; return *this; };
};

// Trapezial integrator
template <class Type, class Integrand=typename Derivative<Type>::Result>
class TrapezialIntegrator : public Integrator<Type, Integrand>
{
 public:
  TrapezialIntegrator(scalar dt) : Integrator<Type, Integrand>(dt),past() { };
   void initialise(Integrand x, Type y) { past=x; this->integral=y; };
   Type integrate(Integrand x) {
      this->integral+=this->Dt*(past+x)/2.;
      past=x;
      return *this;
   };
 private:
   Integrand past;
};

// Open first-order Adams-Bashforth integrator
template <class Type, class Integrand=typename Derivative<Type>::Result>
class OpenAB1Integrator : public Integrator<Type, Integrand>
{
 public:
   OpenAB1Integrator(scalar dt) : Integrator<Type, Integrand>(dt),past() { };
   void initialise(Integrand x, Type y) { past=x; this->integral=y; };
   Type integrate(Integrand x) {
      this->integral+=this->Dt*(3*x-past)/2.;
      past=x;
      return *this;
   };
 private:
   Integrand past;
};

// Closed first-order Adams-Bashforth integrator
template <class Type, class Integrand=typename Derivative<Type>::Result>
class ClosedAB1Integrator : public Integrator<Type, Integrand>
{
 public:
   ClosedAB1Integrator(scalar dt) : Integrator<Type, Integrand>(dt),past() { };
   void initialise(Integrand x, Type y) { past=x; this->integral=y; };
   Type integrate(Integrand x) {
      this->integral+=this->Dt*(x+past)/2.;
      past=x;
      return *this;
   };
 private:
   Integrand past;
};

// Open second-order Adams-Bashforth integrator
template <class Type, class Integrand=typename Derivative<Type>::Result>
class OpenAB2Integrator : public Integrator<Type, Integrand>
{
 public:
   OpenAB2Integrator(scalar dt) : Integrator<Type, Integrand>(dt),
				  past_1(),past_2() { };
   void initialise(Integrand x, Type y) { past_2=past_1=x; this->integral=y; };
   Type integrate(Integrand x) {
      this->integral+=this->Dt*(23*x-16*past_1+5*past_2)/12.;
      past_2=past_1;
      past_1=x;
      return *this;
   };
 private:
   Integrand past_1, past_2;
};

// Closed second-order Adams-Bashforth integrator
template <class Type, class Integrand=typename Derivative<Type>::Result>
class ClosedAB2Integrator : public Integrator<Type, Integrand>
{
 public:
  ClosedAB2Integrator(scalar dt) : Integrator<Type, Integrand>(dt),
				   past_1(),past_2(){ };
   void initialise(Integrand x, Type y) { past_2=past_1=x; this->integral=y; };
   Type integrate(Integrand x) {
      this->integral+=this->Dt*(5*x+8*past_1-past_2)/12.;
      past_2=past_1;
      past_1=x;
      return *this;
   };
 private:
   Integrand past_1, past_2;
};

/* Makes an Integrator to integrate over integration steps multiple of dt */
template <class Type, class Integrand=typename Derivative<Type>::Result>
class MultipleRateIntegrator : public Integrator <Type, Integrand>
{
 public:
   MultipleRateIntegrator(scalar dt, Integrator<Type, Integrand> * integrator,
                          int const *multiple)
      : Integrator<Type, Integrand>(dt), integrator(integrator),
        multiple(multiple) { } 
    void initialise(Integrand x, Type y) { integrator->initialise(x, y); }
    Type integrate(Integrand x) {
      for (int i=0; i<*multiple; i++)
        integrator->integrate(x);
      return *integrator;
    }
 private:
   Integrator<Type, Integrand> *const integrator;
   int const *const multiple;
};

#endif
