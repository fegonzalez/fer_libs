#include "solid.h"
#include "functor.h"
#include <cassert>
#include <iostream>

using namespace std;


/* SolidMass *****************************************************************/

SolidMass SolidMass::relative_to(Vector r) const
{

   return SolidMass(m_,
		 Mx_-r.x()*m_,
		 My_-r.y()*m_,
		 Mz_-r.z()*m_,
		 Jxx_-2*r.x()*Mx_+r.x()*r.x()*m_,
		 Jyy_-2*r.y()*My_+r.y()*r.y()*m_,
		 Jzz_-2*r.z()*Mz_+r.z()*r.z()*m_,
		 Jyz_-r.y()*Mz_-r.z()*My_+r.y()*r.z()*m_,
		 Jzx_-r.z()*Mx_-r.x()*Mz_+r.z()*r.x()*m_,
		 Jxy_-r.x()*My_-r.y()*Mx_+r.x()*r.y()*m_);
}

SolidMass SolidMass::placed_at(Vector r) const
{
   return relative_to(-r);
}

Matrix SolidMass::cginertia() const
{
   return relative_to(cg()).absinertia();
}

Matrix SolidMass::invcginertia() const
{
   return relative_to(cg()).invabsinertia();
}

Matrix SolidMass::absinertia() const
{
   return Matrix(Jyy_+Jzz_, -Jxy_, -Jzx_,
		 -Jxy_, Jzz_+Jxx_, -Jyz_,
		 -Jzx_, -Jyz_, Jxx_+Jyy_);
}

Matrix SolidMass::invabsinertia() const
{
   scalar Ix=Jyy_+Jzz_;
   scalar Iy=Jzz_+Jxx_;
   scalar Iz=Jxx_+Jyy_;
   scalar determinant=
     Ix*Iy*Iz-Ix*Jyz_*Jyz_-Iy*Jzx_*Jzx_-Iz*Jxy_*Jxy_-2*Jyz_*Jzx_*Jxy_;
   scalar iIyz=Ix*Jyz_+Jzx_*Jxy_;
   scalar iIzx=Iy*Jzx_+Jxy_*Jyz_;
   scalar iIxy=Iz*Jxy_+Jyz_*Jzx_;
   return 1./determinant*Matrix(Iy*Iz-Jyz_*Jyz_, iIxy, iIzx,
				 iIxy, Iz*Ix-Jzx_*Jzx_, iIyz,
				 iIzx, iIyz, Ix*Iy-Jxy_*Jxy_);
}

SolidMass &SolidMass::operator+=(SolidMass const &a)
{
   m_+=a.m_;
   Mx_+=a.Mx_;
   My_+=a.My_;
   Mz_+=a.Mz_;
   Jxx_+=a.Jxx_;
   Jyy_+=a.Jyy_;
   Jzz_+=a.Jzz_;
   Jyz_+=a.Jyz_;
   Jzx_+=a.Jzx_;
   Jxy_+=a.Jxy_;
   return *this;
}

std::ostream &operator<<(std::ostream &os, SolidMass a)
{
   return os << "{ " << a.m_
     << " { " << a.Mx_ << " " << a.My_ << " " << a.Mz_ << " } "
     << "{ " << a.Jxx_ << " " << a.Jyy_ << " " << a.Jzz_
     << " " << a.Jyz_ << " " << a.Jzx_ << " " << a.Jxy_ << " } }";
}

std::istream &operator>>(std::istream &is, SolidMass &a) {
  std::string constructor;
  SolidMass result;

  is >> constructor;
  if (constructor=="SolidMass") {
    scalar m, Mx, My, Mz, Jxx, Jyy, Jzz, Jyz, Jzx, Jxy;
    is >> m >> Mx >> My >> Mz >> Jxx >> Jyy >> Jzz >> Jyz >> Jzx >> Jxy;
    result=SolidMass(m, Mx, My, Mz, Jxx, Jyy, Jzz, Jyz, Jzx, Jxy);
  }
  else if (constructor=="point_mass") {
    scalar m;
    is >> m;
    result=point_mass(m);
  }
  else if (constructor=="uniform_sphere_mass") {
    scalar m, radius;
    is >> m >> radius;
    result=uniform_sphere_mass(m, radius);
  }
  else if (constructor=="hollow_sphere_mass") {
    scalar m, radius;
    is >> m >> radius;
    result=hollow_sphere_mass(m, radius);
  }
  else
    throw "bad syntax reading SolidMass constructor";

  while (is and (is >> std::ws) and is.peek()==':') {
    std::string operation;
    is >> operation;
    if (operation==":placed_at") {
      Vector r;
      is >> r;
      result=result.placed_at(r);
    }
    else if (operation==":relative_to") {
      Vector r;
      is >> r;
      result=result.relative_to(r);
    }
    else
      throw "bad syntax reading SolidMass operation";
  }
  a=result;
  return is;
}

SolidMass operator+(SolidMass a, SolidMass b)
{
   SolidMass result=a;
   return result+=b;
}

SolidMass operator*(scalar k, SolidMass a)
{
   return SolidMass(k*a.m_,
		 k*a.Mx_, k*a.My_, k*a.Mz_,
		 k*a.Jxx_, k*a.Jyy_, k*a.Jzz_,
		 k*a.Jyz_, k*a.Jzx_, k*a.Jxy_);
}

SolidMass operator*(SolidMass a, scalar k)
{
   return k*a;
}

SolidMass operator/(SolidMass a, scalar k)
{
   return (1./k)*a;
}

SolidMass point_mass(scalar m)
{
   return SolidMass(m, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}

SolidMass inertia_mass(scalar m,
                       scalar Ix, scalar Iy, scalar Iz,
                       scalar Iyz, scalar Izx, scalar Ixy)
{
   return SolidMass(m, 0, 0, 0,
		 (Iy+Iz-Ix)/2., (Iz+Ix-Iy)/2., (Ix+Iy-Iz)/2.,
		 -Iyz, -Izx, -Ixy);
}

SolidMass uniform_sphere_mass(scalar m,scalar radius)
{
   scalar I=2./5.*m*square(radius);
   return inertia_mass(m, I, I, I, 0., 0., 0.);
}

SolidMass hollow_sphere_mass(scalar m,scalar radius)
{
   scalar I=2./3.*m*square(radius);
   return inertia_mass(m, I, I, I, 0., 0., 0.);
}

SolidMass instant_solid_mass(scalar mass,Vector cg,SolidMass basic) {

 Matrix cg_in = basic.cginertia();
 scalar previous_mass = basic.mass();

 scalar Ix = mass/previous_mass * cg_in.x().x();
 scalar Iy = mass/previous_mass * cg_in.y().y();
 scalar Iz = mass/previous_mass * cg_in.z().z();
 scalar Iyz = mass/previous_mass * cg_in.y().z();
 scalar Izx = mass/previous_mass * cg_in.z().x();
 scalar Ixy = mass/previous_mass * cg_in.x().y();

 return inertia_mass(mass,Ix,Iy,Iz,Iyz,Izx,Ixy).placed_at(cg);

//must be friend class
/* return SolidMass(mass,cg.x()*mass,cg.y()*mass,cg.z()*mass,
                  basic.Jxx_, basic.Jyy_, basic.Jzz_,
                  basic.Jyz_, basic.Jzx_, basic.Jxy_);
*/
}


/* SolidAction ***************************************************************/

SolidAction SolidAction::relative_to(Vector r) const
{
   return placed_at(-r);
}

SolidAction SolidAction::placed_at(Vector r) const
{
   return SolidAction(F_, M_+r*F_);
}

std::ostream &operator<<(std::ostream &os, SolidAction a)
{
   return os << "( " << a.force() << " " << a.moment() << " )";
}

SolidAction operator+(SolidAction a, SolidAction b)
{
   return SolidAction(a.force()+b.force(), a.moment()+b.moment());
}

SolidAction operator-(SolidAction a, SolidAction b)
{
   return SolidAction(a.force()-b.force(), a.moment()-b.moment());
}

SolidAction operator*(scalar k, SolidAction a)
{
   return SolidAction(k*a.force(), k*a.moment());
}

SolidAction operator*(SolidAction a, scalar k)
{
   return k*a;
}

SolidAction operator/(SolidAction a, scalar k)
{
   return (1./k)*a;
}

SolidAction force(Vector F)
{
   return SolidAction(F, Vector());
}

SolidAction moment(Vector M)
{
   return SolidAction(Vector(), M);
}

SolidAction from_relative_to__zombie (pointer_type (SolidAction) solid_action,
                                                            pointer_type (Reference_0) from,
                                                            pointer_type (Reference_0) to) {
  Vector F = from->vector_rel_to_abs (solid_action->force(), to);
  Vector M = from->vector_rel_to_abs (solid_action->moment(), to);
  return SolidAction (F, M);
}

SolidAction from_reduced_to (pointer_type (SolidAction) solid_action,
                                               pointer_type (Reference_0) from,
                                               pointer_type (Reference_0) to) {
  SolidAction a = from_relative_to__zombie (solid_action, from, to);
  return a.placed_at (from->origin_abs(to));
}

/* SolidAcceleration ********************************************************/

SolidAcceleration operator+(SolidAcceleration a, SolidAcceleration b)
{
   return SolidAcceleration(a.linear()+b.linear(), a.angular()+b.angular());
}

/* SolidVelocity ************************************************************/

SolidVelocity operator+(SolidVelocity a, SolidVelocity b)
{
   return SolidVelocity(a.linear()+b.linear(), a.angular()+b.angular());
}

/* Reference_0 *************************************************************/

Reference_0::Reference_0(Reference_0 *parent_)
: parent(parent_), origin(), attitude(), tick_cache_0(-1)
{
}

void Reference_0::set_parent(Vector origin_parent, Quaternion attitude_parent)
{
   assert(tick_cache_0<tick);
   origin=origin_parent;
   attitude=attitude_parent;
}

void Reference_0::set_abs(Vector origin_abs, Quaternion attitude_abs,
			   Reference_0 *ref_abs)
{
   if (parent==ref_abs)
     set_parent(origin_abs, attitude_abs);
   else
     set_parent(parent->point_abs_to_rel(origin_abs, ref_abs),
	       parent->quaternion_abs_to_rel(attitude_abs, ref_abs));
}


Vector Reference_0::origin_parent() const
{
   return origin;
}

Vector Reference_0::origin_abs(Reference_0 *ref_abs) const
{
   check_abs_0();

   if (parent==ref_abs)
     return origin;

   if (ref_abs)
     return ref_abs->point_abs_to_rel(origin_abs_cache);
   else
     return origin_abs_cache;
}

Quaternion Reference_0::attitude_parent() const
{
   return attitude;
}

Quaternion Reference_0::attitude_abs(Reference_0 *ref_abs) const
{
   check_abs_0();

   if (parent==ref_abs)
     return attitude;

   if (ref_abs)
     return ref_abs->quaternion_abs_to_rel(attitude_abs_cache);
   else
     return attitude_abs_cache;
}


Vector Reference_0::point_rel_to_parent(Vector point_rel) const
{
   return origin+attitude*point_rel;
}

Vector Reference_0::point_parent_to_rel(Vector point_parent) const
{
   return inv(attitude)*(point_parent-origin);
}

Vector Reference_0::point_rel_to_abs(Vector point_rel,
				     Reference_0 *ref_abs) const
{
   check_abs_0();
   if (parent==ref_abs)
     return point_rel_to_parent(point_rel);
   else {
      Vector point_abs=origin_abs_cache+attitude_abs_cache*point_rel;
      if (ref_abs)
	return ref_abs->point_abs_to_rel(point_abs);
      else
	return point_abs;
   }
}

Vector Reference_0::point_abs_to_rel(Vector point_abs,
				     Reference_0 *ref_abs) const
{
   check_abs_0();
   if (parent==ref_abs)
     return point_parent_to_rel(point_abs);
   else {
      Vector point_abs_abs;
      if (ref_abs)
	point_abs_abs=ref_abs->point_rel_to_abs(point_abs);
      else
	point_abs_abs=point_abs;
      return inv(attitude_abs_cache)*(point_abs_abs-origin_abs_cache);
   }
}


Vector Reference_0::vector_rel_to_parent(Vector vector_rel) const
{
   return attitude*vector_rel;
}

Vector Reference_0::vector_parent_to_rel(Vector vector_parent) const
{
   return inv(attitude)*vector_parent;
}

Vector Reference_0::vector_rel_to_abs(Vector vector_rel,
				      Reference_0 *ref_abs) const
{
   check_abs_0();
   if (parent==ref_abs)
     return vector_rel_to_parent(vector_rel);
   else {
      Vector vector_abs=attitude_abs_cache*vector_rel;
      if (ref_abs)
	return ref_abs->vector_abs_to_rel(vector_abs);
      else
	return vector_abs;
   }
}

Vector Reference_0::vector_abs_to_rel(Vector vector_abs,
				      Reference_0 *ref_abs) const
{
   check_abs_0();
   if (parent==ref_abs)
     return vector_parent_to_rel(vector_abs);
   else {
      Vector vector_abs_abs;
      if (ref_abs)
	vector_abs_abs=ref_abs->vector_rel_to_abs(vector_abs);
      else
	vector_abs_abs=vector_abs;
      return inv(attitude_abs_cache)*vector_abs_abs;
   }
}


Quaternion
Reference_0::quaternion_rel_to_parent(Quaternion quaternion_rel) const
{
   return attitude*quaternion_rel;
}

Quaternion
Reference_0::quaternion_parent_to_rel(Quaternion quaternion_parent) const
{
   return inv(attitude)*quaternion_parent;
}

Quaternion Reference_0::quaternion_rel_to_abs(Quaternion quaternion_rel,
					      Reference_0 *ref_abs) const
{
   check_abs_0();
   if (parent==ref_abs)
     return quaternion_rel_to_parent(quaternion_rel);
   else {
      Quaternion quaternion_abs=attitude_abs_cache*quaternion_rel;
      if (ref_abs)
	return ref_abs->quaternion_abs_to_rel(quaternion_abs);
      else
	return quaternion_abs;
   }
}

Quaternion Reference_0::quaternion_abs_to_rel(Quaternion quaternion_abs,
					      Reference_0 *ref_abs) const
{
   check_abs_0();
   if (parent==ref_abs)
     return quaternion_parent_to_rel(quaternion_abs);
   else {
      Quaternion quaternion_abs_abs;
      if (ref_abs)
	quaternion_abs_abs=ref_abs->quaternion_rel_to_abs(quaternion_abs);
      else
	quaternion_abs_abs=quaternion_abs;
      return inv(attitude_abs_cache)*quaternion_abs_abs;
   }
}

void Reference_0::check_abs_0() const
{
   if (tick_cache_0==tick)
     return;
   if (parent)
     parent->check_abs_0();
   calculate_abs_0();
}

void Reference_0::calculate_abs_0() const
{
   if (parent)
     origin_abs_cache=parent->point_rel_to_abs(origin);
   else
     origin_abs_cache=origin;

   if (parent)
     attitude_abs_cache=parent->quaternion_rel_to_abs(attitude);
   else
     attitude_abs_cache=attitude;

   tick_cache_0=tick;
}

void Reference_0::erase_cache_0() const
{
   tick_cache_0=-1;
}

void Reference_0::initializeReference_0()
{
   origin=Vector(0.0 , 0.0 , 0.0);
   attitude=Quaternion(Vector(1.0 , 0.0 , 0.0) , 0.0);
   tick_cache_0=-1;
   origin_abs_cache=origin;
   attitude_abs_cache=attitude;
}

/* Reference_1 **************************************************************/

Reference_1::Reference_1(Reference_1 *parent_)
: Reference_0(parent_), parent(parent_), velocity_origin(), velocity_angular(),
  tick_cache_1(-1)
{
}

void Reference_1::set_parent(Vector origin_parent, Quaternion attitude_parent,
			     Vector velocity_parent,
			     Vector velocity_angular_parent)
{
   assert(tick_cache_1<tick);
   Reference_0::set_parent(origin_parent, attitude_parent);
   velocity_origin=velocity_parent;
   velocity_angular=velocity_angular_parent;
}

void Reference_1::set_abs(Vector origin_abs, Quaternion attitude_abs,
			   Vector velocity_abs, Vector velocity_angular_abs,
			   Reference_1 *ref_abs)
{
   if (parent==ref_abs)
     set_parent(origin_abs, attitude_abs,
	       velocity_abs, velocity_angular_abs);
   else {
      Vector origin_parent=parent->point_abs_to_rel(origin_abs, ref_abs);
      set_parent(origin_parent,
		parent->quaternion_abs_to_rel(attitude_abs, ref_abs),
		parent->velocity_abs_to_rel(origin_parent,
					   velocity_abs, ref_abs),
		parent->vector_abs_to_rel(velocity_angular_abs
					-parent->velocity_angular_abs(),
					ref_abs));
   }
}


Vector Reference_1::velocity_origin_parent() const
{
   return velocity_origin;
}

Vector Reference_1::velocity_origin_abs(Reference_1 *ref_abs) const
{
   check_abs_1();

   if (parent==ref_abs)
     return velocity_origin;

   if (ref_abs)
     return ref_abs->velocity_abs_to_rel(origin_abs(ref_abs),
					 velocity_origin_abs_cache);
   else
     return velocity_origin_abs_cache;
}

Vector Reference_1::velocity_angular_parent() const
{
   return velocity_angular;
}

Vector Reference_1::velocity_angular_abs(Reference_1 *ref_abs) const
{
   check_abs_1();

   if (parent==ref_abs)
     return velocity_angular;

   if (ref_abs)
     return ref_abs->vector_abs_to_rel(velocity_angular_abs_cache
				      -ref_abs->velocity_angular_abs());
   else
     return velocity_angular_abs_cache;
}


Vector Reference_1::velocity_rel_to_parent(Vector point_rel,
					   Vector velocity_rel) const
{
   return velocity_origin
          +vector_rel_to_parent(vector_parent_to_rel(velocity_angular)*point_rel)
          +vector_rel_to_parent(velocity_rel);
   // the second term is vector_rel_to_parent instead of point_rel_to_parent
   // because it is about the reference point vector and not the point vector
   // itself
}

Vector Reference_1::velocity_parent_to_rel(Vector point_rel,
					   Vector velocity_parent) const
{
   return vector_parent_to_rel(velocity_parent
			     -velocity_origin)
          -vector_parent_to_rel(velocity_angular)*point_rel;
}

Vector Reference_1::velocity_rel_to_abs(Vector point_rel,
					 Vector velocity_rel,
					 Reference_1 *ref_abs) const
{
   check_abs_1();
   if (parent==ref_abs)
     return velocity_rel_to_parent(point_rel, velocity_rel);
   else {
      Vector velocity_abs=
	velocity_origin_abs_cache
	+vector_rel_to_abs(vector_abs_to_rel(velocity_angular_abs_cache)
			  *point_rel)
        +vector_rel_to_abs(velocity_rel);
      if (ref_abs)
	return
	  ref_abs->velocity_abs_to_rel(point_rel_to_abs(point_rel, ref_abs),
				       velocity_abs);
      else
	return velocity_abs;
   }
}

Vector Reference_1::velocity_abs_to_rel(Vector point_rel,
					 Vector velocity_abs,
					 Reference_1 *ref_abs) const
{
   check_abs_1();
   if (parent==ref_abs)
     return velocity_parent_to_rel(point_rel, velocity_abs);
   else {
      Vector velocity_abs_abs;
      if (ref_abs)
	velocity_abs_abs=
	  ref_abs->velocity_rel_to_abs(point_rel_to_abs(point_rel, ref_abs),
				       velocity_abs);
      else
	velocity_abs_abs=velocity_abs;
      return vector_abs_to_rel(velocity_abs_abs
			      -velocity_origin_abs_cache)
	     -vector_abs_to_rel(velocity_angular_abs_cache)*point_rel;
   }
}

void Reference_1::check_abs_1() const
{
   if (tick_cache_1==tick)
     return;
   if (parent)
     parent->check_abs_1();
   calculate_abs_1();
}

void Reference_1::calculate_abs_1() const
{
   if (parent)
     velocity_origin_abs_cache=parent->velocity_rel_to_abs(origin_parent(),
							   velocity_origin);
   else
     velocity_origin_abs_cache=velocity_origin;

   if (parent)
     velocity_angular_abs_cache=parent->velocity_angular_abs()
                                 +parent->vector_rel_to_abs(velocity_angular);
   else
     velocity_angular_abs_cache=velocity_angular;

   tick_cache_1=tick;
}

void Reference_1::erase_cache_1() const
{
   erase_cache_0();
   tick_cache_1=-1;
}

void Reference_1::initializeReference_1()
{
   // reference initialization
   initializeReference_0();

   // class atributes initialization
   velocity_origin=Vector(0.0 , 0.0 , 0.0);
   velocity_angular=Vector(0.0 , 0.0 , 0.0);
   tick_cache_1=-1;
   velocity_origin_abs_cache=velocity_origin;
   velocity_angular_abs_cache=velocity_angular;
}

/* Solid ********************************************************************/

Solid::Solid(pointer_type(Integrator<Vector>) ace_vel,
             pointer_type(Integrator<Vector>) vel_pos,
             pointer_type(Integrator<Vector>) aceang_velang,
             pointer_type(Integrator<Quaternion>) velang_att,
             Reference_1 *reference,
             bool fixed)
: Reference_1(reference),
  ace_vel_(ace_vel), vel_pos_(vel_pos),
  aceang_velang_(aceang_velang), velang_att_(velang_att),
  Fixed(fixed)
{
//   export("massic", &totalSolidMass_);
//   export("mass", &totalSolidMass_mass_);
//   export("cg", &totalSolidMass_cg_);
//   export("cg_pos_abs", &cg_pos_abs);
//   export("cg_vel_abs", &cg_vel_abs);
//   export("cg_vel_rel", &cg_vel_rel);
//   export("att_abs", &att_abs);
//   export("velang_rel", &velang_rel);
}

void Solid::set_ace_limit(cppfunct::Function<LimVector (Vector)> const &f) {
  ace_lim=f;
}

void Solid::set_vel_limit(cppfunct::Function<LimVector (Vector)> const &f) {
  vel_lim=f;
}

void Solid::set_aceang_limit(cppfunct::Function<LimVector (Vector)> const &f) {
  aceang_lim=f;
}

void Solid::set_velang_limit(cppfunct::Function<LimVector (Vector)> const &f) {
  velang_lim=f;
}


void Solid::initialize(Vector pos_abs_0, Vector vel_abs_0,
		     Quaternion att_abs_0, Vector velang_rel_0)
{

 if(Fixed)  cg_initialize(pos_abs_0, vel_abs_0,att_abs_0, velang_rel_0);
 else
   cg_initialize(pos_abs_0+att_abs_0*cg_rel(),
                 vel_abs_0+att_abs_0*(velang_rel_0*cg_rel()),
                 att_abs_0, velang_rel_0);
}

void Solid::cg_initialize(Vector cg_pos_abs_0, Vector cg_vel_abs_0,
			Quaternion cg_att_abs_0, Vector cg_velang_rel_0)
{
   velang_rel=cg_velang_rel_0;
   att_abs=cg_att_abs_0;
   cg_pos_abs=cg_pos_abs_0;
   cg_vel_abs=cg_vel_abs_0;

   cg_vel_rel=vector_to_rel(cg_vel_abs);

   if(!Fixed) calculate_accelerations();

   ace_vel_->initialise(cg_ace_abs, cg_vel_abs);
   vel_pos_->initialise(cg_vel_abs, cg_pos_abs);
   aceang_velang_->initialise(aceang_rel, velang_rel);
   velang_att_->initialise(velang_rel, att_abs);

   if(!Fixed) calculate_orig();
}

void Solid::calculate_accelerations()
{

  Vector new_cg_ace_abs;
  Vector new_aceang_rel;

  if (is_any_SolidAction_subscribed()) {

   // action referenced to cog
   SolidAction action_cg=
     total_SolidAction().relative_to(total_SolidMass().cg());

   // forces and moments referenced to cog
   Vector force_abs=att_abs*action_cg.force();
   Vector moment_rel=action_cg.moment();

   // accelerations calculated and then integrated to yield velocities and
   // positions (linear and rotational)
   new_cg_ace_abs=force_abs/total_SolidMass().mass();
   new_aceang_rel=
     total_SolidMass().invcginertia()
     *(moment_rel-velang_rel*(total_SolidMass().cginertia()*velang_rel));

  }

   accel_but_SolidAcceleration_abs = new_cg_ace_abs;
   accel_but_SolidAcceleration_rel = vector_to_rel(new_cg_ace_abs);

   SolidAcceleration acceleration_cg=total_SolidAcceleration();
   new_cg_ace_abs+=acceleration_cg.linear();
   new_aceang_rel+=acceleration_cg.angular();

   cg_ace_abs=new_cg_ace_abs;
   aceang_rel=new_aceang_rel;

   if (Fixed) {
      cg_ace_abs=Vector();
      aceang_rel=Vector();
   }
}

namespace {

  bool limit_by_function(Vector &v,
                         cppfunct::Function<Solid::LimVector (Vector)> f) {
    if (f.is_set()) {
      Solid::LimVector lv=f(v);
      if (lv.first) {
        v=lv.second;
        return true;
      }
    }
    return false;
  }

}

void Solid::model()
{
   calculate_accelerations();

   limit_by_function(cg_ace_abs, ace_lim);
   limit_by_function(aceang_rel, aceang_lim);

   aceang_abs=vector_to_abs(aceang_rel);
   if(!Fixed)
   {
   /* "Synthetic" velocity, added to the "Real" velocity in order to reach
      a commanded altitude, to perform a correction in coordinates and so on */
      SolidVelocity added_velocity = total_SolidAddedVelocity();

      cg_vel_abs=ace_vel_->integrate(cg_ace_abs);
      if (limit_by_function(cg_vel_abs, vel_lim))
        ace_vel_->initialise(cg_ace_abs, cg_vel_abs);

      cg_pos_abs=vel_pos_->integrate(cg_vel_abs+added_velocity.linear());

      velang_rel=aceang_velang_->integrate(aceang_rel);
      if (limit_by_function(velang_rel, velang_lim))
        aceang_velang_->initialise(aceang_rel, velang_rel);

      att_abs=velang_att_->integrate(velang_rel+added_velocity.angular());
   }
   calculate_orig();
   cg_vel_rel=vector_to_rel(cg_vel_abs);
   cg_ace_rel=vector_to_rel(cg_ace_abs);
}

SolidMass Solid::total_SolidMass() const {
  SolidMass result;
  for (SubscriptableSolidMass::const_iterator scan=
         SubscriptableSolidMass::begin();
       scan!=SubscriptableSolidMass::end();
       ++scan)
    result+=(*scan)->solid_mass();
  return result;
}

SolidAction Solid::total_SolidAction() const {
  SolidAction result;
  for (SubscriptableSolidAction::const_iterator scan=
         SubscriptableSolidAction::begin();
       scan!=SubscriptableSolidAction::end();
       ++scan)
    result+=(*scan)->solid_action();
  return result;
}

bool Solid::is_any_SolidAction_subscribed() const {
  return (SubscriptableSolidAction::begin()!=SubscriptableSolidAction::end());
}

SolidAcceleration Solid::total_SolidAcceleration() const {
  SolidAcceleration result;
  for (SubscriptableSolidAcceleration::const_iterator scan=
         SubscriptableSolidAcceleration::begin();
       scan!=SubscriptableSolidAcceleration::end();
       ++scan)
    result+=(*scan)->solid_acceleration();
  return result;
}

SolidVelocity Solid::total_SolidAddedVelocity() const {
  SolidVelocity result;
  for (SubscriptableSolidAddedVelocity::const_iterator scan=
         SubscriptableSolidAddedVelocity::begin();
       scan!=SubscriptableSolidAddedVelocity::end();
       ++scan)
    result+=(*scan)->solid_added_velocity();
  return result;
}

Vector Solid::point_to_rel(Vector point_abs) const
{
//   return inv(att_abs)*(point_abs-orig_pos_abs);
   return point_abs_to_rel(point_abs);
}

Vector Solid::point_to_abs(Vector point_rel) const
{
//   return att_abs*point_rel+orig_pos_abs;
   return point_rel_to_abs(point_rel);
}

Vector Solid::vector_to_rel(Vector vector_abs) const
{
//   return inv(att_abs)*vector_abs;
   return vector_abs_to_rel(vector_abs);
}

Vector Solid::vector_to_abs(Vector vector_rel) const
{
//   return att_abs*vector_rel;
   return vector_rel_to_abs(vector_rel);
}

Quaternion Solid::quaternion_to_rel(Quaternion quaternion_abs) const
{
//   return inv(att_abs)*quaternion_abs;
   return quaternion_abs_to_rel(quaternion_abs);
}

Quaternion Solid::quaternion_to_abs(Quaternion quaternion_rel) const
{
//   return att_abs*quaternion_rel;
   return quaternion_rel_to_abs(quaternion_rel);
}

Vector Solid::vel_abs(Vector point_rel) const
{
//   return orig_vel_abs+vector_to_abs(velang_rel*point_rel);
   Vector solid_vel_abs(orig_vel_abs+vector_to_abs(velang_rel*point_rel));
   (void) solid_vel_abs;
   Vector reference_1vel_abs_(velocity_rel_to_abs(point_rel));
   (void) reference_1vel_abs_;
   return velocity_rel_to_abs(point_rel);
}

Vector Solid::cg_rel() const
{
   return total_SolidMass().cg();
}


void Solid::calculate_orig()
{
   orig_pos_abs=cg_pos_abs-att_abs*cg_rel();
   orig_vel_abs=cg_vel_abs-att_abs*(velang_rel*cg_rel());
   velang_abs=att_abs*velang_rel; // cannot be vector_abs because of
                                  // set_abs() not yet done
   erase_cache_1();
   set_abs(orig_pos_abs, att_abs, orig_vel_abs, velang_abs);
}

void Solid::initializeSolid()
{
   // reference initialization
   initializeReference_1();

   // class atributes initialization
   cg_pos_abs=Vector(0.0 , 0.0 , 0.0);
   cg_vel_abs=Vector(0.0 , 0.0 , 0.0);
   cg_vel_rel=Vector(0.0 , 0.0 , 0.0);
   cg_ace_abs=Vector(0.0 , 0.0 , 0.0);
   cg_ace_rel=Vector(0.0 , 0.0 , 0.0);
   att_abs=Quaternion(Vector(1.0 , 0.0 , 0.0) , 0.0);
   velang_rel=Vector(0.0 , 0.0 , 0.0);
   velang_abs=Vector(0.0 , 0.0 , 0.0);
   aceang_rel=Vector(0.0 , 0.0 , 0.0);
   aceang_abs=Vector(0.0 , 0.0 , 0.0);
   orig_pos_abs=Vector(0.0 , 0.0 , 0.0);
   orig_vel_abs=Vector(0.0 , 0.0 , 0.0);
}


void Solid::fix_solid(bool fixed)
{
   Fixed = fixed;
}

/* misc **********************************************************************/

ModelSolidMassFunctor_0::ModelSolidMassFunctor_0(
  pointer_type(Functor_0<SolidMass> const ) sm)
  : sm(sm)
{ }

SolidMass ModelSolidMassFunctor_0::solid_mass() const {
  return sm->function();
}

Solid::LimVector norm_limit_vector(Vector v,
                                          scalar max_norm) {
  if (norm(v)>max_norm)
    return std::make_pair(true, max_norm*normalise(v));
  else
    return std::make_pair(false, v);
}

cppfunct::Function<Solid::LimVector (Vector)>
function_norm_limit_vector(scalar max_norm) {
  return cppfunct::bind_arg<2>(cppfunct::function(norm_limit_vector), 
                               max_norm);
}
