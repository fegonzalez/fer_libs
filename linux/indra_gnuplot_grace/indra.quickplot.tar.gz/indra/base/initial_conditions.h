#ifndef INITIAL_CONDITIONS_HEADER_
#define INITIAL_CONDITIONS_HEADER_

#include <fstream>
#include <map>
#include <string>

#include "base.h"

class InitialConditions {
 public:
   InitialConditions(std::string file);
   scalar operator[](std::string name) const;
 private:
   std::string file;
   std::map<std::string, scalar> map_name_value;
};

#endif
