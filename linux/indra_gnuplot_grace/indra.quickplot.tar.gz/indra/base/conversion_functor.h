#ifndef CONVERSION_FUNCTOR_HEADER_
#define CONVERSION_FUNCTOR_HEADER_

#include "functor.h"
#include "pointer_policy.h"
namespace Units {

template <typename Ret,typename UnitType>
class ConversionFunctor_0 : public Functor_0<Ret>{
 public :
 ConversionFunctor_0(pointer_type(Functor_0<Ret> const) func,UnitType unit_origin, UnitType unit_destination) :
                               func(func),
                               unit_origin(unit_origin),
                               unit_destination(unit_destination) {}

 Ret operator()(void) const { return convert(func->function(),unit_origin,unit_destination);}

private :
 pointer_type (Functor_0<Ret> const) const func;
 UnitType const unit_origin;
 UnitType const unit_destination;
};

template<typename Ret, typename UnitType>
pointer_type(Functor_0<Ret>) convert(pointer_type(Functor_0<Ret> const) f, UnitType unit_origin, UnitType unit_destination) {
  return new_pointer(ConversionFunctor_0<Ret,UnitType>(f,unit_origin,unit_destination));
} 

}
#endif




