#ifndef TIMER_HEADER_
#define TIMER_HEADER_

#include <sys/time.h>
#include <unistd.h>
#include "base.h"

namespace RealTime
{



  struct TimerTime {
    TimerTime() : seconds(0), microseconds(0) { }
    long long int seconds;
    long long int microseconds;
  };

  inline double operator-(TimerTime a, TimerTime b) {
    return
      double(a.seconds-b.seconds)+double(a.microseconds-b.microseconds)/1.e6;
  }

  struct GetTimeOfDayClock {

    static TimerTime get_time()
    {
      timeval result;
      gettimeofday(&result,NULL);

      TimerTime result_time;
      result_time.seconds=result.tv_sec;
      result_time.microseconds=result.tv_usec;

      return result_time;
    }

  };

  struct TestClock {

    static TimerTime get_time();
    static TimerTime current_time;
  };

  template <typename Clock=GetTimeOfDayClock>
  class Timer {
  public:

    Timer() { reset(); }

    ~Timer(){};

    void reset() { start_time=Clock::get_time(); }
    double read() const { return Clock::get_time()-start_time; }

  private:
    TimerTime start_time;
  };


  template <typename Clock=GetTimeOfDayClock>
  class StatisticTimer {

  public:

    StatisticTimer();

    ~StatisticTimer(){};

    void start_timer();
    void stop_timer();

  private:

    Timer<Clock> timer;

  public:

    double total;
    double average;
    double min_value;
    double max_value;
    double last_value;
    long long int cycles;


  };


};

/* implementation ************************************************************/

namespace RealTime {

  template <typename Clock>
  StatisticTimer<Clock>::StatisticTimer():
    timer(),

    total(0.0),
    average(0.0),
    min_value(1e6),
    max_value(-1),
    last_value(0.0),
    cycles(0)
    {
      timer.read();
    };

  template <typename Clock>
  void StatisticTimer<Clock>::start_timer()
  {
    timer.reset();
  };

  template <typename Clock>
  void StatisticTimer<Clock>::stop_timer()
  {
    last_value=timer.read();
    min_value=minimum(last_value,min_value);
    max_value=maximum(last_value,max_value);
    total+= last_value;
    cycles++;
    average = total / double(cycles);

  };


}

#endif
