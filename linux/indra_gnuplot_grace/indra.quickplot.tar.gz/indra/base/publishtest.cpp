#include "publish.h"
#include "inspector.h"
#include <iostream>

using namespace std;

// all this "BaseValueMonitor" implementation does is report what is published
// to it
class ReportingNullValueMonitor
  : public BaseValueMonitor {
public:
  void publish(std::string value_name,
               BaseValueInspector *value_inspector) {
    cout << "published variable \"" << value_name
         << "\" with _current_ value ";
    value_inspector->output_value(cout);
    cout << endl;
  }
};

// a "Model" implementation that accepts a publishing message
class NodeModel
  : public Model {
public:
  NodeModel()
    : foo(1492), bar(10.12) { }
  void accept_message(Message const &message) {
    // is this a publishing message?
    if (concrete_message_is<PublishMessage>(message)) {
      // if it is a publishing message, extract the value monitor...
      BaseValueMonitor *const vm=
        concrete_message<PublishMessage>(message).value_monitor;
      // ... and publish to it our member variables
      vm->publish("foo", new_variable_inspector(&foo));
      vm->publish("bar", new_variable_inspector(&bar));
    }
  }
private:
  int foo;
  scalar bar;
};

int main() {
  pointer_type(Model) root=new_pointer(Model);
  pointer_type(Model) node=new_pointer(NodeModel);
  node->subscribe_to(root);

  ReportingNullValueMonitor vm;

  // pass the root model a publishing message, requesting to publish to the
  // specified value monitor (in this case, the reporting null value monitor
  // "vm")
  root->pass_message(PublishMessage(pointer_to(vm)));
}
