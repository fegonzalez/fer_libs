#include "HmeodsParameters.h"
#include <indra/base/paramfile.h>


//==========================
namespace eods_wildcat {
//==========================

 EodsModuleConfig load_params_from_file(std::string file_name)
 {
   file_name = here_pathname(file_name);
   ParameterFile params_file(file_name); //cargado el fichero de parámetros como un mapa

    return EodsModuleConfig(params_file.parameter<bool>("load_data"),
			    params_file.parameter<bool>("save_data"),

//Insertion points for publications made with "add_config_param.sh script"
//_DO_NOT_REMOVEME_change_point_param_101
 , params_file.parameter<float>("EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST")
 , params_file.parameter<float>("EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST")

			    );
  }


//==========================
}//end of namespace eods_wildcat
//==========================

//EOFILE

