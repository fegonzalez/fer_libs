


void cl_Eods::updateTurretPosition()
{

}


//============================================

void cl_Eods::public_vars() 
{
  publica("eods.cl_eods.config_params.load_data",& the_config_params.load_data);
  publica("eods.cl_eods.config_params.save_data",& the_config_params.save_data);

//_DO_NOT_REMOVEME_change_point_publish_1
 publica ("eods.cl_eods.config_params.EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST", &the_config_params.EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST);
 publica ("eods.cl_eods.config_params.EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST", &the_config_params.EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST);
