#ifndef WILDCAT_SIMULADOR_SISTEMAS_EODS_HMEODSPARAMETERS_H
#define WILDCAT_SIMULADOR_SISTEMAS_EODS_HMEODSPARAMETERS_H

//indra lib
#include <indra/base/here_pathname.h>
#include <indra/base/scalar.h>

//stl
#include <string>


//==========================
namespace eods_wildcat {
//==========================

  namespace{
 const int ENTERO_DOS = 2;
 const int ENTERO_UNO = 1;

//Insertion points for publications made with "add_config_param.sh script"
//_DO_NOT_REMOVEME_change_point_param_1
 const float DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST = 0.0;
 const float DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST = 100.0;

  }

//=========================================================
// data
//=========================================================

struct EodsModuleConfig 
 {
 int ENTERO_DOS;
 int ENTERO_UNO;


//Insertion points for publications made with "add_config_param.sh script"
//_DO_NOT_REMOVEME_change_point_param_2
 float EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST;
 float EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST;

   //functions
   EodsModuleConfig(bool load_data=false, 
		    int ENTERO_DOS = DEFAULT_ENTERO_DOS,
		    int ENTERO_UNO = DEFAULT_ENTERO_UNO

//Insertion points for publications made with "add_config_param.sh script"
//_DO_NOT_REMOVEME_change_point_param_3
 , float EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST = DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST
 , float EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST = DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST
		    )
  

 :load_data(load_data), 
  save_data(save_data)
 , ENTERO_DOS(DEFAULT_ENTERO_DOS)
 , ENTERO_UNO(DEFAULT_ENTERO_UNO)

//Insertion points for publications made with "add_config_param.sh script"
//_DO_NOT_REMOVEME_change_point_param_4
 , EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST(DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST)
 , EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST(DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST)

        { }

   void initialise()
   {
 ENTERO_DOS = DEFAULT_ENTERO_DOS;
 ENTERO_UNO = DEFAULT_ENTERO_UNO;


//Insertion points for publications made with "add_config_param.sh script"
//_DO_NOT_REMOVEME_change_point_param_5
 EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST = DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_LOWEST;
 EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST = DEFAULT_EON_SENSOR_DYNAMIC_RANGE_GAIN_HIGHEST;

   }//end of initialise

};


//=========================================================
// functions
//=========================================================

  /*!\fn  EodsModuleConfig load_params_from_file(std::string file_name);
    \param file_name: path of the configuration file. Must be a path with a common root
    directory to the path of the executable (xexec0), that is "$IPATH/executive/exec/bin"
    i.e. "$IPATH/aw159_models/ ...
    i.e. "$IPATH/wildcat/ ...
    \warning Default parameter file = the file for the release version of
    the simulator.
   */
 EodsModuleConfig load_params_from_file(std::string file_name = here_pathname(DEFAULT_EODS_CONFIG_FILE_PATH));

//==========================
}//end of namespace eods_wildcat
//==========================

#endif
