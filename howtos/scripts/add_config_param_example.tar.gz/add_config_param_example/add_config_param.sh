#!/bin/bash

##########################################################################
# Ejemplo de uso en ficheros testParam.h y testParam.cpp
#
# $0 PARAM_MODULE_NAME PARAM_DATA_TYPE   PARAM_VAR_NAME   PARAM_DEFAULT_VALUE  expected."
#
# FLOAT
#./add_config_param.sh float YAW_TURRET  77.7
#
# STRING
#./add_config_param.sh string NEW_CADENA \"valor_cadena\"
#
# CHAR
#./add_config_param.sh char caracter_a  \'A\'
#
# VECTOR y valores múltiples
# No soportado: hacerlo con valor inicial unico para tenerlo todo excepto 
# la inicialización, y hacer esta a mano
#
#########################################################################


NumParams=4
change_point_param_1="_DO_NOT_REMOVEME_change_point_param_1"
change_point_param_2="_DO_NOT_REMOVEME_change_point_param_2"
change_point_param_3="_DO_NOT_REMOVEME_change_point_param_3"
change_point_param_4="_DO_NOT_REMOVEME_change_point_param_4"
change_point_param_5="_DO_NOT_REMOVEME_change_point_param_5"
change_point_param_101="_DO_NOT_REMOVEME_change_point_param_101"
change_point_publish_1="_DO_NOT_REMOVEME_change_point_publish_1"
change_point_config_1="_DO_NOT_REMOVEME_change_point_config_1"


if [ $# -ne $NumParams ] ; then
echo "ERROR (BAD FORMAT): $0  MODULE_NAME  DATA_TYPE  VAR_NAME  DEFAULT_VALUE  expected."
exit 1
fi


PARAM_MODULE_NAME=$1
PARAM_DATA_TYPE=$2
PARAM_VAR_NAME=$3
PARAM_DEFAULT_VALUE=$4
PARAM_FILE_NAME="Hm"$PARAM_MODULE_NAME"Parameters"
PARAM_PUBLISH_FILE_NAME="Hm"$PARAM_MODULE_NAME".cpp"
PARAM_CONFIG_FILE_NAME=$PARAM_MODULE_NAME"_config.dat"


# echo $PARAM_MODULE_NAME=$1
# echo $PARAM_DATA_TYPE=$2
# echo $PARAM_VAR_NAME=$3
# echo $PARAM_DEFAULT_VALUE=$4
# echo $PARAM_FILE_NAME".h"
# echo $PARAM_FILE_NAME".cpp"
# echo $PARAM_CONFIG_FILE_NAME
# echo $PARAM_PUBLISH_FILE_NAME

# echo $change_point_param_1
# echo $change_point_param_2
# echo $change_point_param_3
# echo $change_point_param_4
# echo $change_point_param_5
# echo $change_point_param_101 
# echo $change_point_publish_1
# echo $change_point_config_1


for file in $(ls $PARAM_FILE_NAME.h); 
do 
sed -i "s/$change_point_param_1/$change_point_param_1\n const $PARAM_DATA_TYPE DEFAULT_$PARAM_VAR_NAME = $PARAM_DEFAULT_VALUE;/g" $file;
sed -i "s/$change_point_param_2/$change_point_param_2\n $PARAM_DATA_TYPE $PARAM_VAR_NAME;/g" $file;
sed -i "s/$change_point_param_3/$change_point_param_3\n , $PARAM_DATA_TYPE $PARAM_VAR_NAME = DEFAULT_$PARAM_VAR_NAME/g" $file;
sed -i "s/$change_point_param_4/$change_point_param_4\n , $PARAM_VAR_NAME(DEFAULT_$PARAM_VAR_NAME)/g" $file;
sed -i "s/$change_point_param_5/$change_point_param_5\n $PARAM_VAR_NAME = DEFAULT_$PARAM_VAR_NAME;/g" $file;
done

for file in $(ls $PARAM_FILE_NAME.cpp); 
do
sed -i "s/$change_point_param_101/$change_point_param_101\n , params_file.parameter<$PARAM_DATA_TYPE>(\"$PARAM_VAR_NAME\")/g" $file;
done


for file in $(ls $PARAM_CONFIG_FILE_NAME); 
do
sed -i "s/$change_point_config_1/$change_point_config_1\n $PARAM_VAR_NAME  $PARAM_DEFAULT_VALUE/g" $file;
done



for file in $(ls $PARAM_PUBLISH_FILE_NAME); 
do
sed  -i "s/$change_point_publish_1/$change_point_publish_1\n publica \(\"$PARAM_MODULE_NAME.cl_$PARAM_MODULE_NAME.config_params.$PARAM_VAR_NAME\", \&the_config_params.$PARAM_VAR_NAME);/g" $file;
done
