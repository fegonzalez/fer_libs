#!/bin/bash


for file in $(grep -l "# cycle" *.rtdm)
do
 cp $file $file.report_input
 sed -i 's/# cycle/cycle/g' $file.report_input
done


# for file in $(grep -l "#DATA_FILE" *.rtdm.report_input)
# do
#  sed -i 's/#DATA_FILE\ncycle/cycle/g' $file
# done


# for file in $(grep -L "vessel1_veloc_inercialX" *.rtdm.report_input)
# do
#  sed -i 's/vessel1_veloc_inercial/vessel1_veloc_inercialX vessel1_veloc_inercialY vessel1_veloc_inercialZ/g' $file
# done

# for file in $(grep -L "vessel1_veloc_nedX" *.rtdm.report_input)
# do
#  sed -i 's/vessel1_veloc_ned/vessel1_veloc_nedX vessel1_veloc_nedY vessel1_veloc_nedZ/g' $file
# done

# for file in $(grep -L "vessel1_veloc_rotacionalX" *.rtdm.report_input)
# do
#  sed -i 's/vessel1_veloc_rotacional/vessel1_veloc_rotacionalX vessel1_veloc_rotacionalY vessel1_veloc_rotacionalZ/g' $file
# done

for file in $(ls  *.rtdm.report_input)
do
./generate_rtdm_report $file
#echo $file
done

