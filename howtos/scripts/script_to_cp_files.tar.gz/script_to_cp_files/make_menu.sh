#!/bin/bash

##########################################################################
# Creates the schema needde for a new hums menu.
#
# $0  SRC_MENU_FILE  SRC_MENU_NAME  NEW_MENU_FILE  NEW_MENU_NAME
#
# i.e. Make a new 'abc'  menu from an existing 'old' menu.
#
#
# ./make_menush  abc old
#
# 
#
#########################################################################


NumParams=2


change_point_include="DO_NOT_REMOVEME_change_point_menu_include_1"
change_point_create_screens="DO_NOT_REMOVEME_change_point_create_screens"
change_point_screen_init="DO_NOT_REMOVEME_change_point_screen_init"
change_point_create_commands="DO_NOT_REMOVEME_change_point_create_commands"

if [ $# -ne $NumParams ] ; then
echo "ERROR (BAD FORMAT): $0  SRC_MENU_NAME  NEW_MENU_NAME expected."
exit 1
fi

#set input to lower case
SRC_MENU_NAME="$(echo $1 | tr 'A-Z' 'a-z')"
NEW_MENU_NAME="$(echo $2 | tr 'A-Z' 'a-z')"
#set new menu name different cases (to use sed to replace)
SRC_MENU_NAME_UPPER="$(echo $SRC_MENU_NAME | tr 'a-z' 'A-Z')"
SRC_MENU_NAME_CAPITAL="$(echo ${SRC_MENU_NAME:0:1} | tr 'a-z' 'A-Z')"
SRC_MENU_NAME_CAPITAL+="$(echo ${SRC_MENU_NAME:1})"
NEW_MENU_NAME_UPPER="$(echo $NEW_MENU_NAME | tr 'a-z' 'A-Z')"
NEW_MENU_NAME_CAPITAL="$(echo ${NEW_MENU_NAME:0:1} | tr 'a-z' 'A-Z')"
NEW_MENU_NAME_CAPITAL+="$(echo ${NEW_MENU_NAME:1})"
#aux parameters (class names sufix)
screen_class_suffix="MenuScreen"
command_class_suffix="Command"
#Edit the next paths to access to the correct files
SRC_SCREEN_HEADER="screen_$SRC_MENU_NAME.h"
SRC_SCREEN_CPP="screen_$SRC_MENU_NAME.cpp"
SRC_COMMAND_HEADER="command_$SRC_MENU_NAME.h"
SRC_COMMAND_CPP="command_$SRC_MENU_NAME.cpp"
NEW_SCREEN_HEADER="screen_$NEW_MENU_NAME.h"
NEW_SCREEN_CPP="screen_$NEW_MENU_NAME.cpp"
NEW_COMMAND_HEADER="command_$NEW_MENU_NAME.h"
NEW_COMMAND_CPP="command_$NEW_MENU_NAME.cpp"
SYSTEM_FILE_CPP="hums_system.cpp"


if [ ! -f $SYSTEM_FILE_CPP ]; then
    echo -e "\n $SRC_SCREEN_HEADER not found \n"
    exit 11
fi


if [ ! -f $SRC_SCREEN_HEADER ]; then
    echo -e "\n $SRC_SCREEN_HEADER not found \n"
    exit 11
fi

if [ ! -f $SRC_SCREEN_CPP ]; then
    echo -e "\n $SRC_SCREEN_CPP not found \n"
    exit 11
fi

if [ ! -f $SRC_COMMAND_HEADER ]; then
    echo -e "\n $SRC_COMMAND_HEADER not found \n"
    exit 11
fi

if [ ! -f $SRC_COMMAND_CPP ]; then
    echo -e "\n $SRC_COMMAND_CPP not found \n"
    exit 11
fi



if [ -f $NEW_SCREEN_HEADER ]; then
    echo -e "\n $NEW_SCREEN_HEADER already exists \n"
    exit 11
fi

if [ -f $NEW_SCREEN_CPP ]; then
    echo -e "\n $NEW_SCREEN_CPP already exists \n"
    exit 11
fi

if [ -f $NEW_COMMAND_HEADER ]; then
    echo -e "\n $NEW_COMMAND_HEADER already exists \n"
    exit 11
fi

if [ -f $NEW_COMMAND_CPP ]; then
    echo -e "\n $NEW_COMMAND_CPP already exists \n"
    exit 11
fi



###########################################################################
### checking sintax
###########################################################################

echo $change_point_include
echo $change_point_create_screens
echo $change_point_screen_init
echo $change_point_create_commands

# echo SYSTEM_FILE_CPP=$SYSTEM_FILE_CPP
# echo SRC_SCREEN_HEADER=$SRC_SCREEN_HEADER
# echo SRC_SCREEN_CPP=$SRC_SCREEN_CPP
# echo SRC_COMMAND_HEADER=$SRC_COMMAND_HEADER
# echo SRC_COMMAND_CPP=$SRC_COMMAND_CPP
# echo NEW_SCREEN_HEADER=$NEW_SCREEN_HEADER
# echo NEW_SCREEN_CPP=$NEW_SCREEN_CPP
# echo NEW_COMMAND_HEADER=$NEW_COMMAND_HEADER
# echo NEW_COMMAND_CPP=$NEW_COMMAND_CPP
# echo SRC_MENU_NAME=$SRC_MENU_NAME
# echo SRC_MENU_NAME_UPPER=$SRC_MENU_NAME_UPPER
# echo SRC_MENU_NAME_CAPITAL=$SRC_MENU_NAME_CAPITAL
# echo NEW_MENU_NAME=$NEW_MENU_NAME
# echo NEW_MENU_NAME_UPPER=$NEW_MENU_NAME_UPPER
# echo NEW_MENU_NAME_CAPITAL=$NEW_MENU_NAME_CAPITAL


#
# ACTIONS
#

cp $SRC_SCREEN_HEADER $NEW_SCREEN_HEADER
if [ ! -f $NEW_SCREEN_HEADER ]; then
    echo -e "\n $NEW_SCREEN_HEADER not found \n"
    exit 11
fi


cp $SRC_SCREEN_CPP $NEW_SCREEN_CPP
if [ ! -f $NEW_SCREEN_CPP ]; then
    echo -e "\n $NEW_SCREEN_CPP not found \n"
    exit 11
fi


cp $SRC_COMMAND_HEADER $NEW_COMMAND_HEADER
if [ ! -f $NEW_COMMAND_HEADER ]; then
    echo -e "\n $NEW_COMMAND_HEADER not found \n"
    exit 11
fi

cp $SRC_COMMAND_CPP $NEW_COMMAND_CPP
if [ ! -f $NEW_COMMAND_CPP ]; then
    echo -e "\n $NEW_COMMAND_CPP not found \n"
    exit 11
fi



sed -i "s/$SRC_MENU_NAME_UPPER/$NEW_MENU_NAME_UPPER/g" $NEW_SCREEN_HEADER
sed -i "s/$SRC_MENU_NAME_CAPITAL/$NEW_MENU_NAME_CAPITAL/g" $NEW_SCREEN_HEADER
sed -i "s/$SRC_MENU_NAME/$NEW_MENU_NAME/g" $NEW_SCREEN_HEADER
sed -i "s/$SRC_MENU_NAME_UPPER/$NEW_MENU_NAME_UPPER/g" $NEW_SCREEN_CPP
sed -i "s/$SRC_MENU_NAME_CAPITAL/$NEW_MENU_NAME_CAPITAL/g" $NEW_SCREEN_CPP
sed -i "s/$SRC_MENU_NAME/$NEW_MENU_NAME/g" $NEW_SCREEN_CPP
sed -i "s/$SRC_MENU_NAME_UPPER/$NEW_MENU_NAME_UPPER/g" $NEW_COMMAND_HEADER
sed -i "s/$SRC_MENU_NAME_CAPITAL/$NEW_MENU_NAME_CAPITAL/g" $NEW_COMMAND_HEADER
sed -i "s/$SRC_MENU_NAME/$NEW_MENU_NAME/g" $NEW_COMMAND_HEADER
sed -i "s/$SRC_MENU_NAME_UPPER/$NEW_MENU_NAME_UPPER/g" $NEW_COMMAND_CPP
sed -i "s/$SRC_MENU_NAME_CAPITAL/$NEW_MENU_NAME_CAPITAL/g" $NEW_COMMAND_CPP
sed -i "s/$SRC_MENU_NAME/$NEW_MENU_NAME/g" $NEW_COMMAND_CPP




sed -i "s/$change_point_include/$change_point_include\n#include <aw159_models\/systems\/hums\/$NEW_SCREEN_HEADER>\n#include <aw159_models\/systems\/hums\/$NEW_COMMAND_HEADER>/g" $SYSTEM_FILE_CPP


sed -i "s/$change_point_create_screens/$change_point_create_screens\n$NEW_MENU_NAME_CAPITAL$screen_class_suffix::getScreen(the_menu);/g" $SYSTEM_FILE_CPP


sed -i "s/$change_point_screen_init/$change_point_screen_init\n$NEW_MENU_NAME_CAPITAL$screen_class_suffix::getScreen(the_menu)->initialise();/g" $SYSTEM_FILE_CPP


sed -i "s/$change_point_create_commands/$change_point_create_commands\n\nthe_client.the_menu.$NEW_MENU_NAME.setCommand\n($NEW_MENU_NAME_CAPITAL$command_class_suffix::getCommand\n(\&the_client,\n$NEW_MENU_NAME_CAPITAL$screen_class_suffix::getScreen(\&(the_client.the_menu))));/g" $SYSTEM_FILE_CPP



echo 
echo 
echo "unexpected failures ???..."
echo 


grep  -i $SRC_MENU_NAME $NEW_SCREEN_HEADER
grep  -i $SRC_MENU_NAME $NEW_SCREEN_CPP
grep  -i $SRC_MENU_NAME $NEW_COMMAND_HEADER
grep  -i $SRC_MENU_NAME $NEW_COMMAND_CPP

echo 
echo "...make_menu.sh finished."
echo 
echo 
