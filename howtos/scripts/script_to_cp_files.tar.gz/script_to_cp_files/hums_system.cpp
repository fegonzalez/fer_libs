
#include <aw159_models/systems/hums/command_maint_dpd_acft.h>

//DO_NOT_REMOVEME_change_point_menu_include_1



//------------------------------------------------------------------------

//Create all the ConcreteScreen objects.
void ScreenStateManager::createScreens()
{

  MaintDpdAcftMenuScreen::getScreen(the_menu);

//DO_NOT_REMOVEME_change_point_create_screens


}

//------------------------------------------------------------------------

void ScreenStateManager::initialise()
{

  MaintDpdAcftMenuScreen::getScreen(the_menu)->initialise();

//DO_NOT_REMOVEME_change_point_screen_init

}

//---------------------------------------------------------

//!\warning do not repeat setCommand() done at construction
void CommandManager::createCommands()
{

  the_client.the_menu.acft_parm.setCommand
    (MaintDpdAcftCommand::getCommand
     (&the_client,
      MaintDpdAcftMenuScreen::getScreen(&(the_client.the_menu))));


//DO_NOT_REMOVEME_change_point_create_commands

}

//EOFILE
