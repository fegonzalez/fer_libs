
#2. Explicit loading/linking of shared objects
#2.2. TEST 2 : Building of shared lib with "gcc"

#--> Make the shared library :
g++ -c base_shared.cc
g++ -shared base_shared.o -o libbase_shared.so

#--> Make the main program
g++ base1.cc -l dl

#--> Run the program
./a.out

#We can see that the static constructor and destructor of the shared library 
#are run automatically at loading/unloading time (i.e. During the call to "dlopen()").

