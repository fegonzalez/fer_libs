#include <stdio.h>
#include <iostream>


using namespace std;



class toto
{
public:
toto() { cout << "Constructor of toto\n"; var = 18; };
~toto() { cout << "Destructor of toto\n"; var = 0; }
int var;
};


toto glob_class;


extern "C"
{

void base_initialize(void)
{

printf("Shared lib entry point, toto's var = %d\n", glob_class.var);

}

}
