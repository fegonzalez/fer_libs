#ifndef TOTO_H
#define TOTO_H

#include <iostream>

class toto
{
public:
  toto() { std::cout << "Constructor of toto\n"; var = 18; };
  ~toto() { std::cout << "Destructor toto\n"; var = 0; }
  int getVar(){return var;}

private:
int var;
};

#endif
