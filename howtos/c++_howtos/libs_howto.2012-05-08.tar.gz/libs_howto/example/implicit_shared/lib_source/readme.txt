Creating a dynamic (shared) library.
