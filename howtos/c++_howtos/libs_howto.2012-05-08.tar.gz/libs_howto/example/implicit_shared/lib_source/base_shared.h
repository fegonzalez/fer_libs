#ifndef BASE_SHARED_H
#define BASE_SHARED_H

void base_initialize();
#endif
