#ifndef TOTO2_H
#define TOTO2_H

#include <iostream>

class toto2
{
public:
  toto2() { std::cout << "Constructor of toto2\n"; var = 36.6; };
  ~toto2() { std::cout << "Destructor of toto2\n"; var = 0; }
  int getVar(){return var;}
private:
int var;
};

#endif
