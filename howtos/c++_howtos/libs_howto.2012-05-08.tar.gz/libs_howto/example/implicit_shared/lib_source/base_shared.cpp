/*
Libray is a set of functionalities that may be made
from several sources, classes or whatever.

In this library example, there is only one functionality (base_initialize)
that depends of two header files.h

 */
#include "toto.h"
#include "toto2.h"
#include <iostream>

void base_initialize(void)
{
 toto toto_class;
 toto2 toto_class_2;
 std::cout<< "Shared lib entry point, toto's var = " << toto_class.getVar() << std::endl;
 std::cout<< "Shared lib entry point 2, toto2's var = " << toto_class_2.getVar() << std::endl;
}


