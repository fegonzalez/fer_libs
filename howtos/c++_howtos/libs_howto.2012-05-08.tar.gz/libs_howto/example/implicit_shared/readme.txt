
#1.2. TEST 2 : Building of shared lib with "gcc"
#--> Location of the shared libs at program startup :

#> export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:`pwd`


################################
#--> Make the shared library :
################################

g++ -c base_shared.cc                            #"base_shared.o" created

g++ -shared base_shared.o -o libbase_shared.so   # "libbase_shared.so" created


################################
#--> Make the main program
################################
#g++ base.cc -L`pwd` -lbase_shared

# g++ -c base.cc # "base.o" created. This one can be skipped


# g++ -o base.cc -L. -lbase_shared -r .

 
# -L path de compilación
# -lNOMBRE_LIBRERIA:  NOMBRE_LIBRERIA sin el prefijo "lib" y sin el sufijo ".so"
# -Wl,-R,'$ORIGIN/path_libreria': así evitamos tener que añadir dicho path a la variable de entrono PATH
#                                 -Wl: llamar al preprocesador
#                                 -R: comando que se le pasa al preprocesador 
#                                 $ORIGIN: opción del comando origen del direccionamiento relativo.
#                                 -R, '$ORIGIN/path relativo hasta la libreria (libbase_shared.so)
# -I path de inclusión de librerias
# base.cc: source test file que usa la librería
# base.cc: executable test file

g++ -L. -lbase_shared -Wl,-R,'$ORIGIN/.'  base.cc  -o test_1_2_2
#
#Lo mismo t.q. la librería está en "./lib", y se incluye un header que está en "./include"
#g++ -Llib -Iinclude -lbase_shared -Wl,-R,'$ORIGIN/.'  base.cc  -o test_1_2_2

################################
#--> Run the program
################################
./test_1_2_2


#
#Hacer /lib/.so
#      /test/test_1_2_2

