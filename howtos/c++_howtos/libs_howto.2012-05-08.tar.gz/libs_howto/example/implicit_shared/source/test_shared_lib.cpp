
//shared library
#include <base_shared.h> // base_initialize()

//stl
#include <iostream>

int main(void)
{
  std::cout << " (libbase_shared.so throught base_shared.h ..." << std::endl;
  base_initialize();

  return 0;
} 
