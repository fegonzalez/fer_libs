Tue May  8 12:07:10 CEST 2012

Shared_libraries_under_linux.pdf : tutorial breve y útil resumen de creación y uso de librerias bajo linux
				   RECOMENDADO

SharedLibraries.howto.pdf:  doc formal explicando que son y como crear librerías en linux
			    \notice Hay un enlace a este doc. desde "Shared_libraries_under_linux.pd"


librerias_ejemplo.tar.gz: ejemplo de creación y uso de librerías estáticas y dinámicas
                           \warning Hecho en Windows bajo eclipse


Ejemplo completo y detallado: ./example/implicit_shared/


